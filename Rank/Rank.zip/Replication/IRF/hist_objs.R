library(ggplot2)
library(cowplot)
library(reshape)

setwd("D:/academic/RA_jj/Innovation") #change it to your personal environment

data = read.csv('objvalues.csv')
colnames(data) = c('Gauss-Newton','BFGS','Nelder-Mead','Simulated-Annealing','Simulated-Annealing + Nelder-Mead','csminwel')
data[ which( data[ ,1] == 1e20 ) ,1] = NA # crashes were hard coded to 1e20 for GN
m = melt(data)
m$value[which(m$value>150)] = 150

p1 <- ggplot(m,aes(x=value)) + geom_histogram() + 
    facet_grid(.~variable) +
    xlab('Minimized Objective Value') +
    ylab('# of replications') +
    ylim(c(0,50)) +
    scale_x_continuous(breaks=c(4,25,50,75,100,125,150))+
    theme(axis.text=element_text(size=22),
          axis.title=element_text(size=22,face="bold"),
          plot.title = element_text(size =22))

data = read.csv('objvalues_re.csv')
data[ which( data[ ,1] == 1e20 ) ,1] = NA # crashes were hard coded to 1e20 for GN
colnames(data) = c('Gauss-Newton','BFGS','Nelder-Mead','Simulated-Annealing','Simulated-Annealing + Nelder-Mead','csminwel')
m = melt(data)
m$value[which(m$value>150)] = 150

p2 <- ggplot(m,aes(x=value)) + geom_histogram() + 
    facet_grid(.~variable) +
    xlab('Minimized Objective Value') +
    ylab('# of replications') +
    ylim(c(0,50)) +
    scale_x_continuous(breaks=c(4,25,50,75,100,125,150))+
    theme(axis.text=element_text(size=22),
          axis.title=element_text(size=22,face="bold"),
          plot.title = element_text(size =22))

library(latex2exp)

p01 <- ggplot() + theme_void() + 
    ggtitle(  TeX('Panel a) without reparameterization') ) +
    theme(plot.title = element_text(size =22,hjust = 0.5, face='bold'))

p02 <- ggplot() + theme_void() + 
    ggtitle( TeX('Panel b) with reparameterization') ) +
    theme(plot.title = element_text(size =22,hjust = 0.5, face='bold'))

pp = plot_grid(p01,p1,p02,p2,ncol=1,rel_heights = c(0.1,1,0.1,1))

ggsave("Hist_Objs_IRF.png", plot = pp, dpi = 300,width=13, height=5.0)