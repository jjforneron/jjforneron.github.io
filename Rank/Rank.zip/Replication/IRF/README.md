The following code can be used to run the Innovation, Productivity, and Monetary Policy example in Sec 4.2 and APPENDIX C.3

(1) Figure: distribution of minimized objective values
    Input: objvalues.xls; objvalues_re.xls 
    Code: hist_objs
    Output: Hist_Objs_IRF

(2) Table: Impulse Response Matching: performance comparison
codes:
    estim_bfgs.m: BFGS method without reparameterization
    estim_bfgs_re.m: BFGS method with reparameterization
    estim_nm.m: NM method without reparameterization
    estim_nm_re.m: NM method with reparameterization
    estim_sanm.m: SA+NM/SA method without reparameterization
    estim_sanm_re.m: SA+NM/SA method with reparameterization
    estim_sims.m: csminwel method without reparameterization
    estim_sims_re.m: csminwel method with reparameterization
    estim_gn_10.m: GN method without reparameterization
    estim_gn_re_10.m: GN method with reparameterization

(3) Figure: Gauss-Newton iterations for 5 starting values & Transform table results from excel to latex
    Input: Excel files created above
    Code: output_plot
    Output: Iterations_GN_impulse_both

(4) Appendix C.3
codes:
    estim_ggn.m: with global step, without reparameterization
    estim_ggn_re:with global step, with reparameterization
    estim_gns.m: no global step, without reparameterization
    estim_gns_re: no global step, with reparameterization


