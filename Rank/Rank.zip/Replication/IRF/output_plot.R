#---------------------------------------------------
#      Plots for the empirical part
#      BLP+Impluse Response
#---------------------------------------------------
#-----------------------------------------------------------------------------

# Load packages
#-----------------------------------------------------------------------------
# Libraries

library(ggplot2)
library(ggpubr)

# Use these for data manipulation, and plots
library(tidyverse)
library(ggplot2)
library(scales)
library(ggrepel)
library(dplyr)
#---------------------------------------------------------------------------------------
# Set ggplot theme
theme_set(
  #theme_clean() + 
  theme_classic() +
    theme(
      panel.background = element_rect(fill = "transparent"), # bg of the panel
      plot.background = element_rect(fill = "transparent", color = NA), # bg of the plot
      legend.background = element_rect(color = "white"),
      legend.box.background = element_rect(fill = "transparent"), # get rid of legend panel bg
      panel.grid.major = element_blank(), 
      panel.grid.minor = element_blank(),
      panel.spacing = unit(10, "lines"))
)
#---------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------
setwd("D:/academic/RA_jj/Innovation") # change it to your own environment
#1,No transformation
# Load data
rm(list=ls())
bfgs <- data.frame(read.csv("BFGS_data.csv"))
bfgs <- bfgs[,2:6] %>% 
  mutate(
    method = "BFGS"
  )

GN <- data.frame(read.csv("gn_data_10.csv"))
GN <- GN[,2:6] %>% 
  mutate(
    method = "GN"
  )

SA <- data.frame(read.csv("sa_data.csv"))
SA <- SA[,2:6] %>% 
  mutate( 
    method = "SA"
  )

SA_NM <- data.frame(read.csv("sanm_data.csv"))
SA_NM <- SA_NM[,2:6] %>% 
  mutate(
    method = "SA+NM"
  )

NM <- data.frame(read.csv("NM_data.csv"))
NM <- NM[,2:6] %>% 
  mutate(
    method = "NM"
  )

sims <- data.frame(read.csv("sims_data.csv"))
sims <- sims[,2:6] %>% 
  mutate(
    method = "sims"
  )
colnames(SA_NM)<- colnames(NM)
colnames(SA)<- colnames(NM)
colnames(GN)<- colnames(NM)
output<- rbind(bfgs, GN,NM, sims, SA_NM, SA)
output<- output%>% filter(output$obj<1e8)
optimal_obj = min(output$obj, na.rm=TRUE)
#truncate_obj = quantile(output$obj_fun, probs=0.75, na.rm=TRUE)
#output<- output%>% filter(output$obj_fun<truncate_obj)


# Construct latex Table
library(xtable)
options(xtable.floating = FALSE)
options(xtable.timestamp = "")
options(width = 60)


meanvalues <- aggregate(output[,1:5], by=list(output$method), mean)
stdvalues <- aggregate(output[,1:5], by=list(output$method), sd)
countvalues <- output %>% group_by(method)%>% count(method)

mean_count<-cbind(meanvalues, countvalues) %>% mutate(name = paste(Group.1,"mean"))
std_count<-cbind(stdvalues, countvalues) %>% mutate(name = paste(Group.1,"std"))

tableoutput <- rbind(mean_count, std_count)

tablelist <- split(tableoutput, f= tableoutput$method)

attr(tablelist, "subheadings") <- paste0("Method ",
                                         names(tablelist))
#attr(mtcarsList, "message") <- c("Line 1 of Message",
#                                 "Line 2 of Message")
#str(mtcarsList)
xList <- xtableList(tablelist)

#-----------------------------------------------------------------------------
#2, with transformation
# Load data
rm(list=ls())
bfgs <- data.frame(read.csv("BFGS_re_data.csv"))
bfgs <- bfgs[,2:6] %>% 
  mutate(
    method = "BFGS"
  )

GN <- data.frame(read.csv("gn_re_data_10.csv"))
GN <- GN[,2:6] %>% 
  mutate(
    method = "GN"
  )

SA <- data.frame(read.csv("sa_re_data.csv"))
SA <- SA[,2:6] %>% 
  mutate( 
    method = "SA"
  )

SA_NM <- data.frame(read.csv("sanm_re_data.csv"))
SA_NM <- SA_NM[,2:6] %>% 
  mutate(
    method = "SA+NM"
  )

NM <- data.frame(read.csv("NM_re_data.csv"))
NM <- NM[,2:6] %>% 
  mutate(
    method = "NM"
  )

sims <- data.frame(read.csv("sims_re_data.csv"))
sims <- sims[,2:6] %>% 
  mutate(
    method = "sims"
  )
colnames(SA_NM)<- colnames(NM)
colnames(SA)<- colnames(NM)
colnames(GN)<- colnames(NM)
output<- rbind(bfgs, GN,NM, sims, SA_NM, SA)
output<- output%>% filter(output$obj<1e8)
optimal_obj = min(output$obj, na.rm=TRUE)
#truncate_obj = quantile(output$obj_fun, probs=0.75, na.rm=TRUE)
#output<- output%>% filter(output$obj_fun<truncate_obj)

# construct latex table
library(xtable)
options(xtable.floating = FALSE)
options(xtable.timestamp = "")
options(width = 60)


meanvalues <- aggregate(output[,1:5], by=list(output$method), mean)
stdvalues <- aggregate(output[,1:5], by=list(output$method), sd)
countvalues <- output %>% group_by(method)%>% count(method)

mean_count<-cbind(meanvalues, countvalues) %>% mutate(name = paste(Group.1,"mean"))
std_count<-cbind(stdvalues, countvalues) %>% mutate(name = paste(Group.1,"std"))

tableoutput <- rbind(mean_count, std_count)

tablelist <- split(tableoutput, f= tableoutput$method)

attr(tablelist, "subheadings") <- paste0("Method ",
                                         names(tablelist))
#attr(mtcarsList, "message") <- c("Line 1 of Message",
#                                 "Line 2 of Message")
#str(mtcarsList)
xList <- xtableList(tablelist)


# Figure: Searching path
library(ggplot2)
library(reshape)

rm(list=ls())
# no reparameterization
#objs
objs <- data.frame(read.csv("obj_data_10.csv"))

plot_data = as.data.frame(objs)
m= melt(plot_data)

B=50
Iterations = length(objs$obj_.1)
m$index = rep(seq(1:Iterations),B)
m1=subset(m, m$variable %in% c('obj_21', 'obj_22', 'obj_23', 'obj_24', 'obj_25'))

m1$variable = as.factor(kronecker(1:5,rep(1,Iterations)))


library(latex2exp)
library(cowplot)

pp1 <- ggplot(m1, aes(x=index, y=value, linetype=variable, color=variable))+
  geom_line()+
  theme( legend.position = "bottom" ) +
  xlab("Iteration k") +
  ylab(TeX('$Q_n(\\theta_k)$ '))+
  scale_y_continuous (trans='log10') +
  scale_color_manual( values = c("#E69F00", "#56B4E9", "#009E73",
                                 "#0072B2", "#293352", "#D55E00", "#CC79A7") ) + 
  scale_linetype_manual(values=c(1,2,3,4,5,6)) + 
  labs(linetype='Starting Value #',color='Starting Value #')+
  theme(axis.text=element_text(size=22),
        axis.title=element_text(size=22),
        plot.title = element_text(size =22))

# alpha_N: \nu; R&D spillover to adoption

alphan <- data.frame(read.csv("alpha_data_10.csv"))

plot_data2 = as.data.frame(alphan)

colnames(plot_data2) = colnames(plot_data)
m= melt(plot_data2)
m$index = rep(seq(1:Iterations),B)
m2=subset(m, m$variable %in% c('obj_21', 'obj_22', 'obj_23', 'obj_24', 'obj_25'))

m2$variable = as.factor(kronecker(1:5,rep(1,Iterations)))

pp2 <- ggplot(m2, aes(x=index, y=value, linetype=variable, color=variable))+
  geom_line()+
  theme( legend.position = "bottom" ) +
  xlab("Iteration k") +
  ylab(TeX('Coefficient \\nu '))+
  scale_color_manual( values = c("#E69F00", "#56B4E9", "#009E73",
                                 "#0072B2", "#293352", "#D55E00", "#CC79A7") ) + 
  scale_linetype_manual(values=c(1,2,3,4,5,6)) + 
  labs(linetype='Starting Value #',color='Starting Value #') +
  geom_hline(yintercept = 0.29, colour="red", size = 1, linetype = "dotted")+
  theme(axis.text=element_text(size=22),
        axis.title=element_text(size=22),
        plot.title = element_text(size =22))

p01 <- ggplot() + theme_void() + 
  ggtitle( TeX( 'Panel a) Objective Function (log scale, no reparameterization)$' ) ) +
  theme(plot.title = element_text(size =22,hjust = 0.5, face='bold'))

p02 <- ggplot() + theme_void() + 
  ggtitle( TeX( 'Panel b) Coefficient \\nu of R&D spillover to adoption rate (no reparameterization)$ ' ) ) +
  theme(plot.title = element_text(size =22,hjust = 0.5, face='bold'))

pp11 <- plot_grid(pp1,pp2,ncol=2)

#pp = plot_grid(p01,p02,pp1,pp2,ncol=2,rel_heights = c(0.1,1))

#ggsave("Iterations_GN_impluse.png", plot = pp, dpi = 300,width=13, height=5.0)


# with reparameterization
#objs
objs_re <- data.frame(read.csv("obj_re_data_10.csv"))

plot_data_re = as.data.frame(objs_re)
m_re= melt(plot_data_re)

B=50
Iterations_re = length(objs_re$obj_.1)
m_re$index = rep(seq(1:Iterations_re),B)
m1_re=subset(m_re, m_re$variable %in% c('obj_21', 'obj_22', 'obj_23', 'obj_24', 'obj_25'))

m1_re$variable = as.factor(kronecker(1:5,rep(1,Iterations_re)))


library(latex2exp)
library(cowplot)

pp1_re <- ggplot(m1_re, aes(x=index, y=value, linetype=variable, color=variable))+
  geom_line()+
  theme( legend.position = "bottom" ) +
  xlab("Iteration k") +
  ylab(TeX('$Q_n(\\theta_k)$ '))+
  scale_y_continuous (trans='log10') +
  scale_color_manual( values = c("#E69F00", "#56B4E9", "#009E73",
                                 "#0072B2", "#293352", "#D55E00", "#CC79A7") ) + 
  scale_linetype_manual(values=c(1,2,3,4,5,6)) + 
  labs(linetype='Starting Value #',color='Starting Value #')+
  theme(axis.text=element_text(size=22),
        axis.title=element_text(size=22),
        plot.title = element_text(size =22))

# alpha_N: \nu; R&D spillover to adoption

alphan_re <- data.frame(read.csv("alpha_re_data_10.csv"))

plot_data2_re = as.data.frame(alphan_re)

colnames(plot_data2_re) = colnames(plot_data_re)
m_re= melt(plot_data2_re)
m_re$index = rep(seq(1:Iterations_re),B)
m2_re=subset(m_re, m_re$variable %in% c('obj_21', 'obj_22', 'obj_23', 'obj_24', 'obj_25'))

m2_re$variable = as.factor(kronecker(1:5,rep(1,Iterations_re)))

pp2_re <- ggplot(m2_re, aes(x=index, y=value, linetype=variable, color=variable))+
  geom_line()+
  theme( legend.position = "bottom" ) +
  xlab("Iteration k") +
  ylab(TeX('Coefficient \\nu '))+
  scale_color_manual( values = c("#E69F00", "#56B4E9", "#009E73",
                                 "#0072B2", "#293352", "#D55E00", "#CC79A7") ) + 
  scale_linetype_manual(values=c(1,2,3,4,5,6)) + 
  labs(linetype='Starting Value #',color='Starting Value #') +
  geom_hline(yintercept = 0.29, colour="red", size = 1, linetype = "dotted")+
  theme(axis.text=element_text(size=22),
        axis.title=element_text(size=22),
        plot.title = element_text(size =22))

pp12 <- plot_grid(pp1_re,pp2_re,ncol=2)

p01_re <- ggplot() + theme_void() + 
  ggtitle( TeX( 'Panel c) Objective Function (log scale, with reparameterization)$' ) ) +
  theme(plot.title = element_text(size =22,hjust = 0.5, face='bold'))

p02_re <- ggplot() + theme_void() + 
  ggtitle( TeX( 'Panel d) Coefficient \\nu of R&D spillover to adoption rate (with reparameterization)$' ) ) +
  theme(plot.title = element_text(size =22,hjust = 0.5, face='bold'))

p01_s <- ggplot() + theme_void() + 
  ggtitle(  TeX('Panel a) without reparameterization') ) +
  theme(plot.title = element_text(size =22,hjust = 0.5, face='bold'))

p02_s <- ggplot() + theme_void() + 
  ggtitle( TeX('Panel b) with reparameterization') ) +
  theme(plot.title = element_text(size =22,hjust = 0.5, face='bold'))

#pp = plot_grid(p01,p02,pp1,pp2,p01_re,p02_re,pp1_re,pp2_re,ncol=2,rel_heights = c(0.1,1))

pp = plot_grid(p01_s,pp11,p02_s,pp12,ncol=1,rel_heights = c(0.1,1,0.1,1))

ggsave("Iterations_GN_impulse_both.png", plot = pp, dpi = 300,width=13, height=10)




