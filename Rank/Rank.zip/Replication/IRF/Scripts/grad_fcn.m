function [ G ] = grad_fcn( params_unbounded )
    p = length(params_unbounded);
    eps = 1e-4;
    f0 = difference_fcn(params_unbounded);
    k = length(f0);

    I = eye(p);
    G = zeros(p,k);
    for i =1:p
        G(i,:) = ( difference_fcn(params_unbounded + eps*I(:,i)) - difference_fcn(params_unbounded - eps*I(:,i)) )/(2*eps);
    end

end