function [ G ] = grad_re_fcn( params_unbounded )
    p = length(params_unbounded);
    eps = 1e-6;
    f0 = diffmom_fcn(params_unbounded);
    k = length(f0);

    I = eye(p);
    G = zeros(p,k);
    for i =1:p
        G(i,:) = ( diffmom_fcn(params_unbounded + eps*I(:,i)) - diffmom_fcn(params_unbounded - eps*I(:,i)) )/(2*eps);
    end

end