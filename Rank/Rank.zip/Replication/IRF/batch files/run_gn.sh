#!/bin/bash -l
module load matlab/2013b
module load hdf5/1.10.4
module load zlib/1.2.11
module load matio/1.5.15
module load dynare/4.5.6

#$ -l h_rt=100:00:00 
#$ -pe omp 8

cd /usr3/graduate/samzl/Innovation

matlab -nodisplay -nosplash - nodesktop -r "estim_gn;exit;" > /usr3/graduate/samzl/Innovation/output/gn.out

