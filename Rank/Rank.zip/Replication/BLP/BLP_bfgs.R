library(BLPestimatoR)
library(pracma)

library(randtoolbox)
rm(list=ls())

set.seed(123) # set the seed
setwd('/home/jj/Dropbox/jjlz/Code/BLP') # !!! adjust to match personal environment !!!

nevos_model <- as.formula("share ~  price + productdummy |
    0+ productdummy |
    price + sugar + mushy |
    0+ IV1 + IV2 + IV3 + IV4 + IV5 + IV6 + IV7 + IV8 + IV9 + IV10 + 
    IV11 + IV12 + IV13 + IV14 + IV15 + IV16 + IV17 + IV18 + IV19 + IV20")

# include orig. draws in the product data
productData_cereal$startingGuessesDelta <- c(log(w_guesses_cereal)) 

# renaming constants:
names(originalDraws_cereal)[1] <- "(Intercept)"

# set-up the data for estimation
cereal_data <- BLP_data(
  model = nevos_model,
  market_identifier = "cdid",
  par_delta = "startingGuessesDelta",
  product_identifier = "product_id",
  productData = productData_cereal,
  demographic_draws = demographicData_cereal,
  blp_inner_tol = 1e-12, blp_inner_maxit = 20000,
  integration_draws = originalDraws_cereal,
  integration_weights = rep(1 / 20, 20)
)


# Initial guess for the non-linear coefficients:
theta_guesses_cereal

# We focus on a specific set of coefficients
theta_guesses_cereal[2,3] = NA
theta_guesses_cereal[2,5] = NA
theta_guesses_cereal[,4] = NA


theta_guesses_cereal[theta_guesses_cereal == 0] <- NA
colnames(theta_guesses_cereal) <- c("unobs_sd", "income", "incomesq", "age", "child")
rownames(theta_guesses_cereal) <- c("(Intercept)", "price", "sugar", "mushy")

# correctly named:
theta_guesses_cereal

# BLP estimation
cereal_est <- estimateBLP(
  blp_data = cereal_data,
  par_theta2 = theta_guesses_cereal,
  solver_method = "BFGS", solver_maxit = 5000, solver_reltol = 1e-6,
  standardError = "heteroskedastic",
  extremumCheck = FALSE,
  printLevel = 1
)

# Print results
summary(cereal_est)

gmm <- gmm_obj_wrap(
  blp_data = cereal_data,
  par_theta2 = theta_guesses_cereal,
  printLevel = 0
)

theta_mat = theta_guesses_cereal
loc = which(!is.na(theta_guesses_cereal))
theta2 = cereal_est$theta_rc
theta_mat[loc] = theta2

theta0 = theta_guesses_cereal[loc] # initial value for optimizers

X = cereal_data$data$X_lin # Linear regressors
Z = cereal_data$data$Z     # Instruments

n = dim(X)[1] # number of observations

W = solve(t(Z)%*%Z/n)

k = dim(Z)[2]

# Part I: 
# Estimate only non-linear parameters, concentrate out the linear ones

moments <- function(theta) {
  
  theta_mat[loc] = theta
  dede = getDelta_wrap(
    blp_data = cereal_data,
    par_theta2 = theta_mat,
    printLevel = 0
  )
  
  y = dede$delta
  beta_hat = solve( t(X)%*%Z%*%W%*%t(Z)%*%X, t(X)%*%Z%*%W%*%t(Z)%*%y)
  
  res = y - X%*%beta_hat
  return( t(Z)%*%res/n )
  
}

objective <- function(theta,safe = FALSE) {
  if ( safe == TRUE ) {
    # Without error handling, BFGS crashes because it goes too far off track
    mom = try( moments(theta) ,silent = TRUE) 
    if ( class(mom)[1] == "try-error" )  { 
      return(Inf)
    } else {
      return( n*t(mom)%*%W%*%mom )
    }
  } else {
    mom = moments(theta)
    return( n*t(mom)%*%W%*%mom )
  }   
  
}

# est1 = optim(theta0,objective,method = "BFGS")
# est2 = optim(theta0,objective,method = "Nelder-Mead") # does not converge

de =  abs(theta0)
lb = -10*rep(1,length(theta0))#abs(theta0)
ub =  10*rep(1,length(theta0))#*abs(theta0)


set.seed(123)
B = 50 # number of bootstrap draws
p = sobol(1000, length(theta0), scrambling = 1, seed = 123) # randomize the sequence

#Part II
# Table -- performance comparison: BFGS

Iterations = 100

thetas  = array(NA, dim = c(Iterations,length(theta0),B) )

estBFGS = matrix(NA,B,length(theta0))
objBFGS = matrix(NA,B,1)
times_bfgs = matrix(0,B,1) # store computation times
initial_bfgs = matrix(0,B,1) # store index of initial value
bb = 1
cc = 1


while (bb <= B) {
  thetas[1,,bb] = lb + (ub-lb)*p[cc,]
  
  
    print(paste('Starting value #',cc))
    print(thetas[1,,bb])
    
    mom = try( moments(thetas[1,,bb]), silent = TRUE )
    
    if ( class(mom)[1] == "try-error" | is.nan(mom[1])==TRUE )  { 
      cc=cc+1
      print('Infinite or NaN at Starting Value')
    } else {
      times_bfgs[bb,]= system.time({
      est1 = try( optim(thetas[1,,bb], objective, safe = FALSE, method = "BFGS", control = list( trace = TRUE ) ) )
      if ( class(est1)[1] == "try-error" )  { 
        objBFGS[bb]  = Inf # Has crashed
        estBFGS[bb,] = NA
      } else {
        objBFGS[bb]  = est1$value
        estBFGS[bb,] = est1$par
      }
    
    
    print(c( objBFGS[bb,], estBFGS[bb,] ))
  })[3] 
      initial_bfgs[bb,]  = cc
      
      bb=bb+1
      cc=cc+1   
      
    }    
  print('**********************************')
}

# stack results into exportable format
df_bfgs<-as.data.frame(cbind(estBFGS, objBFGS, times_bfgs, initial_bfgs))
colnames(df_bfgs) <- c('x1','x2','x3','x4','x5','x6','x7','x8',
                       'obj_fun','time', 'initial index')

write.csv(df_bfgs, "BFGS.csv", row.names = FALSE)