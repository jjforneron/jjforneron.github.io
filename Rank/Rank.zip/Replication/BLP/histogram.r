library(ggplot2)
library(cowplot)
library(reshape)

data = read.csv('objs.csv')
colnames(data) = c('Gauss-Newton','BFGS','Nelder-Mead','Simulated-Annealing','Simulated-Annealing + Nelder-Mead')
m = melt(data)
m$value[which(m$value>150)] = 150

p1 <- ggplot(m,aes(x=value)) + geom_histogram() + 
    facet_grid(.~variable) +
    xlab('Minimized Objective Value') +
    ylab('# of replications') +
    scale_x_continuous(breaks=c(33, 50,75,100,125,150))

ggsave("Hist_Objs.png", plot = p1, dpi = 300,width=13, height=2.5)