#---------------------------------------------------
#      Table for the empirical part: BLP
#---------------------------------------------------
#-----------------------------------------------------------------------------

# Load packages
#-----------------------------------------------------------------------------
# Libraries

library(ggplot2)
library(ggpubr)

# Use these for data manipulation, and plots
library(tidyverse)
library(ggplot2)
library(scales)
library(ggrepel)
library(dplyr)

#---------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------
#1,BLP cereal data
# Load data
setwd('/home/jj/Dropbox/jjlz/Code/BLP') # !!! adjust to match personal environment !!!
rm(list=ls())
bfgs <- data.frame(read.csv("BFGS.csv"))
bfgs <- bfgs %>% 
  mutate(
    method = "BFGS"
  )

GN <- data.frame(read.csv("Gauss_newton.csv"))
GN <- GN %>% 
  mutate(
    method = "GN"
  )

SA <- data.frame(read.csv("SA.csv"))
SA <- SA %>% 
  mutate( 
    method = "SA"
  )

SA_NM <- data.frame(read.csv("SANM.csv"))
SA_NM <- SA_NM %>% 
  mutate(
    method = "SA+NM"
  )

NM <- data.frame(read.csv("NM.csv"))
NM <- NM %>% 
  mutate(
    method = "NM"
  )

output<- rbind(bfgs, GN, SA_NM, NM, SA)
output<- output%>% filter(output$obj_fun!=Inf)
optimal_obj = min(output$obj_fun, na.rm=TRUE)
#truncate_obj = quantile(output$obj_fun, probs=0.75, na.rm=TRUE)
#output<- output%>% filter(output$obj_fun<truncate_obj)

# Aggregate to table:
library(xtable)
options(xtable.floating = FALSE)
options(xtable.timestamp = "")
options(width = 60)


meanvalues <- aggregate(output[,1:9], by=list(output$method), mean)
stdvalues <- aggregate(output[,1:9], by=list(output$method), sd)
countvalues <- output %>% group_by(method)%>% count(method)

mean_count<-cbind(meanvalues, countvalues) %>% mutate(name = paste(Group.1,"mean"))
std_count<-cbind(stdvalues, countvalues) %>% mutate(name = paste(Group.1,"std"))

tableoutput <- rbind(mean_count, std_count)

tablelist <- split(tableoutput, f= tableoutput$method)

attr(tablelist, "subheadings") <- paste0("Method ",
                                         names(tablelist))
#attr(mtcarsList, "message") <- c("Line 1 of Message",
#                                 "Line 2 of Message")
#str(mtcarsList)
xList <- xtableList(tablelist)

