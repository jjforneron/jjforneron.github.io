library(BLPestimatoR)
library(pracma)
library(randtoolbox)

rm(list=ls())

set.seed(123) # set the seed
setwd('/home/jj/Dropbox/jjlz/Code/BLP') # !!! adjust to match personal environment !!!
nevos_model <- as.formula("share ~  price + productdummy |
    0+ productdummy |
    price + sugar + mushy |
    0+ IV1 + IV2 + IV3 + IV4 + IV5 + IV6 + IV7 + IV8 + IV9 + IV10 + 
    IV11 + IV12 + IV13 + IV14 + IV15 + IV16 + IV17 + IV18 + IV19 + IV20")

# include orig. draws in the product data
productData_cereal$startingGuessesDelta <- c(log(w_guesses_cereal)) 

# renaming constants:
names(originalDraws_cereal)[1] <- "(Intercept)"

# set-up the data for estimation
cereal_data <- BLP_data(
  model = nevos_model,
  market_identifier = "cdid",
  par_delta = "startingGuessesDelta",
  product_identifier = "product_id",
  productData = productData_cereal,
  demographic_draws = demographicData_cereal,
  blp_inner_tol = 1e-12, blp_inner_maxit = 20000,
  integration_draws = originalDraws_cereal,
  integration_weights = rep(1 / 20, 20)
)


# Initial guess for the non-linear coefficients:
theta_guesses_cereal

# We focus on a specific set of coefficients
theta_guesses_cereal[2,3] = NA
theta_guesses_cereal[2,5] = NA
theta_guesses_cereal[,4] = NA


theta_guesses_cereal[theta_guesses_cereal == 0] <- NA
colnames(theta_guesses_cereal) <- c("unobs_sd", "income", "incomesq", "age", "child")
rownames(theta_guesses_cereal) <- c("(Intercept)", "price", "sugar", "mushy")

# correctly named:
theta_guesses_cereal

# BLP estimation
cereal_est <- estimateBLP(
  blp_data = cereal_data,
  par_theta2 = theta_guesses_cereal,
  solver_method = "BFGS", solver_maxit = 5000, solver_reltol = 1e-6,
  standardError = "heteroskedastic",
  extremumCheck = FALSE,
  printLevel = 1
)

# Print results
summary(cereal_est)

gmm <- gmm_obj_wrap(
  blp_data = cereal_data,
  par_theta2 = theta_guesses_cereal,
  printLevel = 0
)

theta_mat = theta_guesses_cereal
loc = which(!is.na(theta_guesses_cereal))
theta2 = cereal_est$theta_rc
theta_mat[loc] = theta2

theta0 = theta_guesses_cereal[loc] # initial value for optimizers

X = cereal_data$data$X_lin # Linear regressors
Z = cereal_data$data$Z     # Instruments

n = dim(X)[1] # number of observations

W = solve(t(Z)%*%Z/n)

k = dim(Z)[2]

# Part I: 
# Estimate only non-linear parameters, concentrate out the linear ones

moments <- function(theta) {

    theta_mat[loc] = theta
    dede = getDelta_wrap(
        blp_data = cereal_data,
        par_theta2 = theta_mat,
        printLevel = 0
    )

    y = dede$delta
    beta_hat = solve( t(X)%*%Z%*%W%*%t(Z)%*%X, t(X)%*%Z%*%W%*%t(Z)%*%y)

    res = y - X%*%beta_hat
    return( t(Z)%*%res/n )

}

objective <- function(theta,safe = FALSE) {
    if ( safe == TRUE ) {
        # Without error handling, BFGS crashes because it goes too far off track
        mom = try( moments(theta) ,silent = TRUE) 
        if ( class(mom)[1] == "try-error" )  { 
            return(Inf)
        } else {
            return( n*t(mom)%*%W%*%mom )
        }
    } else {
        mom = moments(theta)
        return( n*t(mom)%*%W%*%mom )
    }   
    
}

# est1 = optim(theta0,objective,method = "BFGS")
# est2 = optim(theta0,objective,method = "Nelder-Mead") # does not converge

de =  abs(theta0)
lb = -10*rep(1,length(theta0))#abs(theta0)
ub =  10*rep(1,length(theta0))#*abs(theta0)


set.seed(123)
B = 50 # number of bootstrap draws
p = sobol(1000, length(theta0), scrambling = 1, seed = 123) # randomize the sequence

#Part II
# Table -- performance comparison: Gauss Newton

Iterations = 150

thetas  = array(NA, dim = c(Iterations,length(theta0),B) )
objs    = matrix(NA,Iterations,B)
times_gn = matrix(0,B,1) # store computation times
initial_gn = matrix(0,B,1) # store index of initial value
bb = 1
cc = 1

while (bb <= B) {
  
    thetas[1,,bb] = lb + (ub-lb)*p[cc,]
  
    
    print(paste('Starting value #',cc))
    print(thetas[1,,bb])

    mom = try( moments(thetas[1,,bb]), silent = TRUE )

    if ( class(mom)[1] == "try-error" | is.nan(mom[1])==TRUE )  { 
        cc=cc+1
        print('Infinite or NaN at Starting Value')
    }else {
        times_gn[bb,]= system.time({
        objs[1,bb] = n*t(mom)%*%W%*%mom
        Gn  = jacobian(moments,thetas[1,,bb])
        gamma = 0.1

        for (b in 2:Iterations) {
            thetas[b,,bb] = thetas[b-1,,bb] - gamma*solve( t(Gn)%*%W%*%Gn, t(Gn)%*%W%*%mom )
            mom = try(moments(thetas[b,,bb]), silent =TRUE)
            if ( class(mom)[1] == "try-error" )  { 
              objs[b,bb] = Inf # Has crashed
              break
            } else {
                  objs[b,bb] = n*t(mom)%*%W%*%mom
                  Gn  = jacobian(moments,thetas[b,,bb])
                  if (b %% 2 == 0) {
                   print( c(b,objs[b,bb]) )
                   }
            }
            
        }
        print(paste('Estimate #',bb))
        print(thetas[b,,bb])
      })[3] 
        
      initial_gn[bb,]  = cc
        
      bb=bb+1
      cc=cc+1
      }

    

    print('**********************************')
}


# stack results into exportable format
df_gn<-as.data.frame(cbind(t(thetas[Iterations,,]), objs[Iterations,], times_gn, initial_gn))
colnames(df_gn) <- c('x1','x2','x3','x4','x5','x6','x7','x8',
                     'obj_fun','time', 'initial index')

write.csv(df_gn, "Gauss_newton.csv", row.names = FALSE)

save.image() 


# Figure -- Iteration: Plot the search path
library(ggplot2)
library(reshape)

# For objective function:
plot_data = as.data.frame(objs)
m= melt(plot_data)
m$index = rep(seq(1:Iterations),B)

# Choose the first 5 starting values
m1=subset(m, m$variable %in% c('V1', 'V2', 'V3', 'V4', 'V5'))

m1$variable = as.factor(kronecker(1:5,rep(1,Iterations)))


library(latex2exp)
library(cowplot)

pp1 <- ggplot(m1, aes(x=index, y=value, linetype=variable, color=variable))+
  geom_line()+
  theme( legend.position = "bottom" ) +
  xlab("Iteration k") +
  ylab(TeX('$Q_n(\\theta_k)$ '))+
  scale_y_continuous (trans='log10') +
  scale_color_manual( values = c("#E69F00", "#56B4E9", "#009E73",
           "#0072B2", "#293352", "#D55E00", "#CC79A7") ) + 
  scale_linetype_manual(values=c(1,2,3,4,5,6)) + 
  labs(linetype='Starting Value #',color='Starting Value #')

# For random coefficient of price: 
plot_data2 = as.data.frame(thetas[,2,])
colnames(plot_data2) = colnames(plot_data)
m= melt(plot_data2)
m$index = rep(seq(1:Iterations),B)
m2=subset(m, m$variable %in% c('V1', 'V2', 'V3', 'V4', 'V5'))

m2$variable = as.factor(kronecker(1:5,rep(1,Iterations)))

pp2 <- ggplot(m2, aes(x=index, y=value, linetype=variable, color=variable))+
  geom_line()+
  theme( legend.position = "bottom" ) +
  xlab("Iteration k") +
  ylab(TeX('Price \\times Stdev: $\\theta_bk '))+
  scale_color_manual( values = c("#E69F00", "#56B4E9", "#009E73",
           "#0072B2", "#293352", "#D55E00", "#CC79A7") ) + 
  scale_linetype_manual(values=c(1,2,3,4,5,6)) + 
  labs(linetype='Starting Value #',color='Starting Value #') +
  geom_hline( yintercept = cereal_est$theta_rc[2], linetype = 1, alpha = 0.2 )

p01 <- ggplot() + theme_void() + 
    ggtitle( TeX( 'Panel a) Objective Function (log scale)$' ) ) +
    theme(plot.title = element_text(size =12,hjust = 0.5, face='bold'))

p02 <- ggplot() + theme_void() + 
    ggtitle( TeX( 'Panel b) Random Coefficient for Price$' ) ) +
    theme(plot.title = element_text(size =12,hjust = 0.5, face='bold'))

pp = plot_grid(p01,p02,pp1,pp2,ncol=2,rel_heights = c(0.1,1))

ggsave("Iterations_GN.png", plot = pp, dpi = 300,width=13, height=5.0)


