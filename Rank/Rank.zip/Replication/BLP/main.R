# The following replicates BLP example in 
# "Convexity Not Required: Estimation of Smooth Moment Condition Models"
# by Jean-Jacques Forneron and Liang Zhong

# Disclaimer: There is no error handling, if the moments return Inf, NA, etc., the code will most likely crash

# the following code is adapted from the BLPestimatoR vignette. 
# See https://cran.r-project.org/web/packages/BLPestimatoR/vignettes/blp_intro.html
# for more details on the package and the example.
library(BLPestimatoR) 
library(pracma)
library(randtoolbox) # Used to generate the covering sequence

rm(list=ls())

set.seed(123) # set the seed
setwd('/home/jj/Dropbox/jjlz/Code/BLP') # !!! adjust to match personal environment !!!

# Figure: 5 staring values
#gn
source("BLP_gn.R")

# Table: performance comparison 

#bfgs
source("BLP_bfgs.R")
#nm
source("blp_nm.R")
#sa; sa+nm
source("blp_sann.R")

#transfer excel to tex file
source("output.R")

# Histgram of objs
source("histogram.r")

# Appendix with different learning rates
source("blp_rep")



