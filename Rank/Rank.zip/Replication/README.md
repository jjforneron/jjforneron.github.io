# Convexity Not Required: Estimation of Smooth Moment Condition Models

Replication materials for "Convexity Not Required: Estimation of Smooth Moment Condition Models" by Jean-Jacques Forneron and Liang Zhong

The replication package consists of 3 folders:

### (1) Illustration of conditions : Section 3, Appendix C.1 (R)

	** Pen & Pencil Example (Section 3, Appendix C.1) **
		-- IllustrationConditions.R: used to construct Figure 1, Table 2 (p=1)		
		-- IllustrationConditions_Continued.R: used to construct Figures C7, C8, C9, C10, and Table 2 (p=12)

	** Misspecified Models (Section 3.2) **
		-- Misspecified_case.R: produces Figure 2


### (2) BLP : Section 4.1 (R)
	
	** Main Files **
		-- main.R : calls Auxiliary Files to produce the outputs
		-- output.R : loads outputs to construct Table 3
		-- histogram.R : loads outputs to construct Figure 3

	** Auxiliary Files **
		-- BLP_gn.R : Gauss-Newton and codes for Figure 4
		-- BLP_bfgs.R : BFGS
		-- BLP_nm.R : Nelder-Mead (Simplex)
		-- BLP_sa.R : Simulated-Annealing
		-- BLP_sann.R : Simulated-Annealing + Nelder-Mead
		-- BLP_rep.R : True value + Standard Errors


### (3) IRF : Section 4.2 (Matlab/Dynare + R)

	** Main Files **

		++ Without Reparameterization

		-- estim_gn_10.m : Gauss-Newton
		-- estim_bfgs.m : BFGS
		-- estim_sims.m : CSMINWELL
		-- estim_nm.m : Nelder-Mead (Simplex)
		-- estim_sa.m : Simulated-Annealing
		-- estim_san.m : Simulated-Annealing + Nelder-Mead
		
		-- estim_ggn.m : with global step (Appendix C.3)
		-- estim_gns_re : without global step (Appendix C.3)

		++ With Reparameterization

		-- estim_gn_re_10.m : Gauss-Newton
		-- estim_bfgs_re.m : BFGS
		-- estim_sims_re.m : CSMINWELL
		-- estim_nm_re.m : Nelder-Mead (Simplex)
		-- estim_sa_re.m : Simulated-Annealing
		-- estim_san_re.m : Simulated-Annealing + Nelder-Mead

		-- estim_ggn_re : with global step (Appendix C.3)
		-- estim_gns.m : without global step (Appendix C.3)

		++ R codes for Figures/Tables

		-- hist_objs.R : produces Figure 5
		-- output_plot.R : produces Figure 6 and Table 4

                ++ Folder -- batch files: .sh files for cluster


	** Auxiliary Files **

		-- see documentation for the replication package of "Innovation, Productivity, and Monetary Policy" by [Patrick Moran and Albert Queralto (2018)](https://www.sciencedirect.com/science/article/pii/S0304393217301216)


If you have questions (?), suggestions (!), improvements (!!), let me know at jjmf@bu.edu
