# Illustration for the sufficient conditions:

# MA(1) model: y_{t} = e_{t} - theta*e_{t-1}, e_{t} ~ (0,1)
# the example is taken from:
# Gourieroux & Monfort (2002, Simulation-based Econometric Methods), Ch4.3

library(stats)  # fit an AR(p) model
library(pracma) # compute jacobian

n = 200        # sample size
theta = -1/2   # MA(1) coefficient

set.seed(123)

e = rnorm( n + 1 )
y = e[2:(n+1)] - theta*e[1:n]

# Estimation: fit an AR(p) model, p >= 1, and match the sample AR coefficients
# with their predicted value 

# p = 1, Minimum-Distance Estimator:

# Fit the AR(1) auxiliary model:
ols_1 = c(ar.ols( y, aic = FALSE, order.max = 1, demean = FALSE, intercept = FALSE )$ar)

historique <<- c()

binding <- function( theta ) {
    # Binding function (see Gourieroux & Monfort p72)
    return( -theta/(1+theta^2) ) 
}

moments <- function( theta ) {
    # Sample moment function: 
    return( ols_1 - binding(theta) )
}

objective <- function( theta, silent = TRUE ) {
    # Sample objective function: 
    if (silent == FALSE) {
        print(theta)
        historique <<- c(historique,theta)
    }
    return( moments(theta)^2 )
}

Fn <- function( theta, silent = TRUE ) {
    # Sample objective function: 
    if (silent == FALSE) {
        print(theta)
        historique <<- c(historique,theta)
    }
    return( ols_1*theta + 0.5*log(1+theta^2) )
}

hess <- function( theta ) {
    # 2nd derivative of the sample objective function
    return( hessian(objective,theta) )
}

jac <- function( theta ) {
    # 1st derivative of the sample moments
    return( jacobian(moments,theta) )
}
    


thetas = seq(-1,1,1e-3)
output = data.frame( theta = thetas, 
    moments   = moments(thetas), 
    objective = sapply(thetas,objective),
    hessian   = sapply(thetas,hess),
    jacobian  = sapply(thetas,jac))

library(ggplot2)
library(cowplot)
library(latex2exp)

p1 <- ggplot( output, aes( x = theta, y = objective ) ) + 
        geom_line() + ggtitle(TeX( 'Objective $Q_n = |\\bar{g}_n|^2$ (non-convex)' )) +
        xlab(TeX('$\\theta$')) + ylab(TeX('$Q_n(\\theta)$'))

p2 <- ggplot( output, aes( x = theta, y = hessian ) ) + 
        geom_line() + ggtitle(TeX( 'Hessian $\\partial^2_{\\theta} Q_n' )) +
        geom_hline( yintercept = 0, alpha = 0.2 ) +
        xlab(TeX('$\\theta$')) + ylab(TeX('$\\partial^2_{\\theta} Q_n(\\theta)$'))

p3 <- ggplot( output, aes( x = theta, y = moments ) ) + 
        geom_line() + ggtitle(TeX( 'Moments $\\bar{g}_n$ (monotone)' )) +
        xlab(TeX('$\\theta$')) + ylab(TeX('$\\bar{g}_n(\\theta)$')) +
        geom_hline( yintercept = 0, alpha = 0.2 )

p4 <- ggplot( output, aes( x = theta, y = jacobian ) ) + 
        geom_line() + ggtitle(TeX( 'Jacobian $G_n$' )) +
        xlab(TeX('$\\theta$')) + ylab(TeX('$G_n(\\theta)$')) +
        geom_hline( yintercept = 0, alpha = 0.2 )

p01 <- ggplot() + theme_void() + 
    ggtitle( TeX( 'Panel a) Sample Objective$' ) ) +
    theme(plot.title = element_text(size =12,hjust = 0.5, face='bold'))

pp11 <- plot_grid(p1,p2,ncol=2)

p02 <- ggplot() + theme_void() + 
    ggtitle( TeX( 'Panel b) Sample Moments$' ) ) +
    theme(plot.title = element_text(size =12,hjust = 0.5, face='bold'))

pp12 <- plot_grid(p3,p4,ncol=2)

pp1 = plot_grid(p01,pp11,p02,pp12,ncol=1,rel_heights = c(0.2,1,0.2,1))

setwd("/home/jj/Dropbox/jjlz/Write/")

ggsave(paste("MA1_p1.png",sep=""),plot = pp1, dpi = 300,width=13, height=5.0)

# Comparison of estimations, p = 1:
gamma = 0.1

coefsNR = rep(0,100)
coefsNR[1] = - 0.60 # very close to the solution, and yet...
for (b in 2:100) {
    coefsNR[b] =  coefsNR[b-1] - gamma*grad(objective,coefsNR[b-1])/hessian(objective,coefsNR[b-1]) # the optimizer diverges
}

coefsGN = rep(0,100)
coefsGN[1] = - 0.60 # very close to the solution
for (b in 2:100) {
    coefsGN[b] =  coefsGN[b-1] - gamma*moments(coefsGN[b-1])/jacobian(moments,coefsGN[b-1]) # this one converges
}

gammas = c(0.1,0.2,0.4,0.6,0.8,1)

cocos <- matrix(0,150,length(gammas))
cocos[1,] = - 0.60
for (j in 1:length(gammas)) {
    try(
    for (b in 2:150) {
        Gn = jac(cocos[b-1,j])
        cocos[b,j] = cocos[b-1,j] - gammas[j]*moments(cocos[b-1,j])/jacobian(moments,cocos[b-1,j])
    }
    )
}

cocosQ <- matrix(0,150,length(gammas))
for (j in 1:length(gammas)) {
    cocosQ[,j] = sapply(cocos[,j],objective)
}

library(ggplot2)
library(reshape)


colnames(cocosQ) = gammas
plot_data = as.data.frame(n*cocosQ)
m= melt(plot_data)

iter = 150

m$index = rep(seq(1:iter),length(gammas))

pp1 <- ggplot(m, aes(x=index, y=value, linetype=variable, color=variable))+
  geom_line()+
  theme( legend.position = "bottom" ) +
  xlab("Iteration k") +
  ylab(TeX('$Q_n(\\theta_k)$ '))+
  scale_y_continuous (trans='log10') +
  scale_color_manual( values = c("#E69F00", "#56B4E9", "#009E73",
                                 "#0072B2", "#293352", "#D55E00", "#CC79A7") ) + 
  scale_linetype_manual(values=c(1,2,3,4,5,6)) + 
  guides(colour = guide_legend(nrow = 1)) +
  labs(linetype=TeX('Learning Rate $\\gamma$') ,color=TeX('Learning Rate $\\gamma$'))


colnames(cocos) = gammas
plot_data = as.data.frame(cocos)
m= melt(plot_data)

iter = 150

m$index = rep(seq(1:iter),length(gammas))

pp2 <- ggplot(m, aes(x=index, y=value, linetype=variable, color=variable))+
  geom_line()+
  theme( legend.position = "bottom" ) +
  xlab("Iteration k") +
  ylim(c(-0.7,0)) +
  ylab(TeX('Coefficient $\\theta$ '))+
  scale_color_manual( values = c("#E69F00", "#56B4E9", "#009E73",
                                 "#0072B2", "#293352", "#D55E00", "#CC79A7") ) + 
  scale_linetype_manual(values=c(1,2,3,4,5,6)) + 
  geom_hline(yintercept = -0.3383797, alpha = 0.2) +
  guides(colour = guide_legend(nrow = 1)) +
  labs(linetype=TeX('Learning Rate $\\gamma$') ,color=TeX('Learning Rate $\\gamma$'))


p01 <- ggplot() + theme_void() + 
  ggtitle( TeX( 'Panel a) Objective Function (log scale, $p=1$)' ) ) +
  theme(plot.title = element_text(size =12,hjust = 0.5, face='bold'))

p02 <- ggplot() + theme_void() + 
  ggtitle( TeX( 'Panel b) Coefficient $\\theta$ ($p=1$) ' ) ) +
  theme(plot.title = element_text(size =12,hjust = 0.5, face='bold'))

pp = plot_grid(p01,p02,pp1,pp2,ncol=2,rel_heights = c(0.1,1))

ggsave("Illustration_GN_MA1gammas.png", plot = pp, dpi = 300,width=13, height=2.5)

p <- ggplot(m, aes(  ))

historique <<- c()
optim(-0.6,objective,method = "BFGS",silent = FALSE)
histBFGS = historique

historique <<- c()
optim(-0.6,objective,method = "L-BFGS-B",lower=c(-1),upper=c(1),silent = FALSE)
histLBFGSB = historique

historique <<- c()
optim(-0.6,Fn,method = "BFGS",silent = FALSE)
histBFGSfn = historique

historique <<- c()
optim(-0.6,Fn,method = "L-BFGS-B",lower=c(-1),upper=c(1),silent = FALSE)
histLBFGSBfn = historique

print(cbind(coefsNR,coefsGN))
print( cbind( sapply(coefsNR,objective), sapply(coefsGN,objective) ) )

library(xtable)
xtable( t(cbind(coefsNR,coefsGN,
    c(histBFGS[seq(1,46,3)],rep(NA,4)),
    c(histLBFGSB[seq(1,33,3)],rep(NA,9)),
    c(histBFGSfn[seq(1,34,3)],rep(NA,9)),
    c(histLBFGSBfn[seq(1,34,3)],rep(NA,9)))[c(1:9,100),]), digits =3 )

animNR <- list()
for (k in 1:20) {
    animNR[[k]] <- ggplot( output, aes( x = theta, y = objective ) ) + 
                    geom_line() + 
                    ggtitle(TeX( paste('Newton-Raphson: k = ',k,sep='') )) +
                    xlab(TeX('$\\theta$')) + ylab(TeX('$Q_n(\\theta)$')) +
                    geom_point( x = coefsNR[k], y = objective(coefsNR[k]), color = 'red', size = 4, alpha = 1 )
                    if (k > 1) {
                        for (j in 1:(k-1)) {
                            animNR[[k]] <- animNR[[k]] + geom_point( x = coefsNR[j], y = objective(coefsNR[j]), color = 'red', size = 2, alpha = 0.1 )
                        }
                    }
}

animGN <- list()
for (k in 1:20) {
    animGN[[k]] <- ggplot( output, aes( x = theta, y = objective ) ) + 
                    geom_line() + 
                    ggtitle(TeX( paste('Gauss-Newton: k = ',k,sep='') )) +
                    xlab(TeX('$\\theta$')) + ylab(TeX('$Q_n(\\theta)$')) +
                    geom_point( x = coefsGN[k], y = objective(coefsGN[k]), color = 'blue', size = 4, alpha = 1 )
                    if (k > 1) {
                        for (j in 1:(k-1)) {
                            animGN[[k]] <- animGN[[k]] + geom_point( x = coefsGN[j], y = objective(coefsGN[j]), color = 'blue', size = 2, alpha = 0.1 )
                        }
                    }
}

anim <- list()
for (k in 1:20) {
    anim[[k]] <- plot_grid(animNR[[k]],animGN[[k]],ncol=2)
}

# p arbitrary, use Indirect Inference
p = 12 # set number of lags

library(stats)  # fit AR model

# Fit an AR(p) model using OLS (no intercept)
ols_p = c(ar.ols( y, aic = FALSE, order.max = p, demean = FALSE, intercept = FALSE )$ar)

S = 5 # number of simulated samples

e_s = matrix(rnorm( (n+1)*S ),n+1,S)

sim_moments <- function( theta ) {
    # simulate MA(1) model with n*S observations, and then compute AR(p) estimates
    y_s      = e_s[2:(n + 1),] - theta*e_s[1:(n),]
    temp <- function( s ) { return(c(ar.ols( y_s[,s], aic = FALSE, order.max = p, demean = FALSE, intercept = FALSE )$ar)) }
    ols_p_s  = sapply(1:S,temp)
    if (S > 1){
        ols_p_s = apply(ols_p_s,1,mean)
    }
    return( c(ols_p - ols_p_s) )
}

sim_objective <- function( theta, silent = TRUE ) {
    # Sample objective function: 
    if (silent == FALSE) {
        print(theta)
        historique <<- c(historique,theta)
    }
    ms = sim_moments(theta)
    return( t(ms)%*%ms )
}

sim_hessian <- function( theta ) {
    # Hessian of the sample objective function: 
    return( hessian( sim_objective, theta ) )
}

sim_jac <- function( theta ) {
    # compute sample jacobian Gn
    return( jacobian(sim_moments,theta) ) 
}

sim_svd <- function( theta ) {
    # compute singular values of the sample jacobian Gn, used to check the rank
    return( svd(jacobian(sim_moments,theta) )$d )  
}

optim(0.99,sim_objective,method = "L-BFGS-B",lower = -1,upper=1,silent = FALSE)

plot(thetas, sapply(thetas,sim_objective),type='l')

output2 = data.frame( theta = thetas, 
            objective = sapply(thetas,sim_objective), 
            hessian   = sapply(thetas,sim_hessian), 
            singval   = sapply(thetas,sim_svd) )

library(ggplot2)
library(cowplot)
library(latex2exp)

p1 <- ggplot( output2, aes( x = theta, y = objective ) ) + 
        geom_line() + ggtitle(TeX( 'Objective $Q_n = |\\bar{g}_n|^2$ (non-convex)' )) +
        xlab(TeX('$\\theta$')) + ylab(TeX('$Q_n(\\theta)$'))

p2 <- ggplot( output2, aes( x = theta, y = hessian ) ) + 
        geom_line() + ggtitle(TeX( 'Hessian $\\partial^2_{\\theta} Q_n' )) +
        geom_hline( yintercept = 0, alpha = 0.2 ) +
        xlab(TeX('$\\theta$')) + ylab(TeX('$\\partial^2_{\\theta} Q_n(\\theta)$'))

p3 <- ggplot() + theme_void()

p4 <- ggplot( output2, aes( x = theta, y = singval ) ) + 
        geom_line() + ggtitle(TeX( 'Singular value of Jacobian $\\sigma_{min}(G_n)$' )) +
        xlab(TeX('$\\theta$')) + ylab(TeX('$\\sigma_{min}(G_{n}(\\theta)$')) +
        geom_hline( yintercept = 0, alpha = 0.2 )

pp2 <- plot_grid(p1,p2,p3,p4,ncol=2)




# Comparison of estimations, p > 1:
gamma = 0.1

coefsNR_p = rep(0,100)
coefsNR_p[1] = 0.95 # not as close to the solution, but still in an area with negative curvature, so again...
for (b in 2:100) {
    coefsNR_p[b] =  coefsNR_p[b-1] - gamma*grad(sim_objective,coefsNR_p[b-1])/hessian(sim_objective,coefsNR_p[b-1]) # the optimizer diverges, slowly
}

coefsGN_p = rep(0,100)
coefsGN_p[1] =  0.95 # closer to -1, where the rank condition fails
for (b in 2:100) {
    G = jacobian(sim_moments,coefsGN_p[b-1])
    coefsGN_p[b] =  coefsGN_p[b-1] - gamma*solve(t(G)%*%G + 1e-5/b,t(G)%*%sim_moments(coefsGN_p[b-1])) # this one converges
    # using the + 1e-2/b ensures the Pk is strictly positive definite
}

print(cbind(coefsNR_p,coefsGN_p))
print( cbind( sapply(coefsNR_p,sim_objective), sapply(coefsGN_p,sim_objective) ) )

historique <<- c()
optim(0.95, sim_objective,method="BFGS", silent = FALSE)
histBFGS = historique

historique <<- c()
optim(0.95, sim_objective,method="L-BFGS-B", lower=c(-1), upper = c(1), silent = FALSE)
histLBFGSB = historique

paths = cbind(coefsNR_p,coefsGN_p,histBFGS[seq(1,300,3)],histLBFGSB[seq(1,300,3)])

xtable( t(paths[c(1:9,100),]), digits = 3 )

optim(0.8,  sim_objective,method="BFGS")
optim(0.85, sim_objective,method="BFGS")
optim(0.9,  sim_objective,method="BFGS")


xx = coefsNR_p
yy = sapply(xx,sim_objective)
animNR <- list()
for (k in 1:50) {
    animNR[[k]] <- ggplot( output2, aes( x = theta, y = objective ) ) + 
                    geom_line() + 
                    ggtitle(TeX( paste('Newton-Raphson: k = ',k,sep='') )) +
                    xlab(TeX('$\\theta$')) + ylab(TeX('$Q_n(\\theta)$')) +
                    geom_point( x = xx[k], y = yy[k], color = 'red', size = 4, alpha = 1 )
                    if (k > 1) {
                        for (j in 1:(k-1)) {
                            animNR[[k]] <- animNR[[k]] + geom_point( x = coefsNR_p[j], y = yy[j], color = 'red', size = 2, alpha = 0.1 )
                        }
                    }
}

xx = coefsGN_p
yy = sapply(xx,sim_objective)
animGN <- list()
for (k in 1:50) {
    animGN[[k]] <- ggplot( output2, aes( x = theta, y = objective ) ) + 
                    geom_line() + 
                    ggtitle(TeX( paste('Gauss-Newton: k = ',k,sep='') )) +
                    xlab(TeX('$\\theta$')) + ylab(TeX('$Q_n(\\theta)$')) +
                    geom_point( x = xx[k], y = yy[k], color = 'blue', size = 4, alpha = 1 )
                    if (k > 1) {
                        for (j in 1:(k-1)) {
                            animGN[[k]] <- animGN[[k]] + geom_point( x = xx[j], y = yy[j], color = 'blue', size = 2, alpha = 0.1 )
                        }
                    }
}

anim2 <- list()
for (k in 1:50) {
    anim2[[k]] <- plot_grid(animNR[[k]],animGN[[k]],ncol=2)
}


for (k in 1:20) {
    print(anim[[k]])
    Sys.sleep(1)  
}

for (k in seq(1,50,5)) {
    print(anim2[[k]])
    Sys.sleep(1)  
}