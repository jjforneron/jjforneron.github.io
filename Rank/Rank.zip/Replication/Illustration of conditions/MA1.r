library(stats)  # fit an AR(p) model
library(pracma) # compute jacobian

n = 200        # sample size n
theta = -1/2   # MA(1) coefficient

set.seed(123)  # set the seed for random numbers
e = rnorm( n + 1 )              # draw innovations
y = e[2:(n+1)] - theta*e[1:n]   # generate MA(1) process
p = 12          # number of lags for the AR(p) models

beta <- function(theta) {   
    # computes the p-limit of the OLS estimates
    # V = covariance matrix of (y_{t-1},...,y_{t-p})
    V = diag(p+1)*(1+theta^2)   # variances on the diagonal
    diag(V[,-1]) = -theta       # autocovariance
    V = t(V)                    # transpose
    diag(V[,-1]) = -theta       # autocovariance
    return( 
        solve( V[2:(p+1),2:(p+1)], V[1,2:(p+1)] ) 
        # p-limit = inv(V)*( vector of autocovariances )
    )
}

# Fit the AR(p) auxiliary model:
ols_p = c(ar.ols( y, aic = FALSE, order.max = p, demean = FALSE, intercept = FALSE )$ar)

moments <- function(theta) { 
    # computes the sample moments gn
    return( ols_p - beta(theta) ) # gn = psi_n - psi(theta)
}

objective <- function(theta,disp = FALSE) { 
    # compute the sample objective Qn
    if (disp == TRUE) {
        print(round(theta,3))     # print to tack R's optimization paths
    }
    mm = moments(theta)           # compute sample moments gn
    return( t(mm)%*%mm )          # compute Qn = gn'*gn (W = Id)
}

dQ <- function(theta,disp=FALSE) { 
    # compute the derivative of Qn
    # gradient of Qn = -2*d psi(theta)/ d theta' * gn(theta)
    return(-2*t(jacobian(beta,theta))%*%moments(theta))
}

# L-BFGS-B: optimization with bound constraints, initialized at theta = 0.95
o1 = optim(0.95,objective,gr=dQ,method="L-BFGS-B",lower=c(-1),upper=c(1),disp=TRUE)

# BFGS: optimization without bound constraints, initialized at theta = 0.95
o2 = optim(0.95,objective,gr=dQ,method="BFGS",disp=TRUE)

# Gauss-Newton
gamma = 0.1 # learning rate

coefsGN = rep(0,150) # 150 iterations in total
coefsGN[1] = 0.95    # starting value: theta = 0.95

for (b in 2:150) { # main loop for Gauss-Newton
    Gn  = -jacobian(beta,coefsGN[b-1])  # 1. compute Jacobian
    mom =  moments(coefsGN[b-1])        # 2. compute moments
    coefsGN[b] = coefsGN[b-1] - gamma*solve(t(Gn)%*%Gn,t(Gn)%*%mom) # 3. update
}   # repeat for each b

# Put the results into a table:
results = matrix(NA,2,3)
colnames(results) = c('L-BFGS-B','BFGS','GN')
results[1,] = c(o1$par,o2$par,coefsGN[150])
results[2,] = sapply(results[1,],objective)
rownames(results) = c('theta','Qn(theta)')

print(results,digits=3)
# Output should look like this:

#           L-BFGS-B   BFGS     GN
# theta         -1.0 -6.979 -0.626
# Qn(theta)      1.7  0.397  0.101
