library(stats)  # fit an AR(p) model
library(pracma) # compute jacobian

n = 200        # sample size
theta = -1/2   # MA(1) coefficient

set.seed(123)

e = rnorm( n + 1 )
y = e[2:(n+1)] - theta*e[1:n]

p = 12

beta <- function(theta) {

    V = diag(p+1)*(1+theta^2)
    diag(V[,-1]) = -theta
    V = t(V)
    diag(V[,-1]) = -theta
    return( solve( V[2:(p+1),2:(p+1)], V[1,2:(p+1)] ) )

}

# Fit the AR(p) auxiliary model:
ols_p = c(ar.ols( y, aic = FALSE, order.max = p, demean = FALSE, intercept = FALSE )$ar)

moments <- function(theta) {

    return( ols_p - beta(theta) )

}

objective <- function(theta,disp = FALSE) {
    if (disp == TRUE) {
        print(round(theta,3))
    }
    mm = moments(theta)
    return( t(mm)%*%mm )
}

dQ <- function(theta,disp=FALSE) {
    return(-2*t(jacobian(beta,theta))%*%moments(theta))
}

optim(0.95,objective,gr=dQ,method="L-BFGS-B",lower=c(-1),upper=c(1),disp=TRUE)
optim(0.95,objective,gr=dQ,method="BFGS",disp=TRUE)

gamma = 0.1

coefsGN = rep(0,150)
coefsGN[1] = 0.95
for (b in 2:150) {
    Gn = -jacobian(beta,coefsGN[b-1])
    coefsGN[b] = coefsGN[b-1] - gamma*solve(t(Gn)%*%Gn,t(Gn)%*%moments(coefsGN[b-1]))
}


gammas = c(0.1,0.2,0.4,0.6,0.8,1)

cocos <- matrix(0,100,length(gammas))
cocos[1,] = 0.95
for (j in 1:length(gammas)) {
    try(
    for (b in 2:100) {
        Gn = -jacobian(beta,cocos[b-1,j])
        cocos[b,j] = cocos[b-1,j] - gammas[j]*solve(t(Gn)%*%Gn,t(Gn)%*%moments(cocos[b-1,j]))
    }
    )
}

coefsNR = rep(0,100)
coefsNR[1] = 0.95
for (b in 2:100) {
    Hn = hessian(objective,coefsNR[b-1])
    coefsNR[b] = coefsNR[b-1] - 0.1*solve(Hn,dQ(coefsNR[b-1]))
}

grid = seq(-1,1,1e-3)
M = matrix(NA,p,length(grid))
for (i in 1:length(grid)) {
    M[,i] = jacobian(beta,grid[i])
}

GG = as.matrix(t(M)%*%M)
colnames(GG) = grid
rownames(GG) = grid

library(reshape2)
library(ggplot2)
library(latex2exp)
library(cowplot)

mm = melt(GG)

breaks = quantile(GG,c(0,5*1e-3,1e-2,0.1,0.2,0.5,0.8,1))
breaks = round(breaks,3)

breaks[which(breaks>1)] = ceil(breaks[which(breaks>1)])

pp <- ggplot(mm, aes( Var1,Var2, z= value,fill = ..level.. )) +
        geom_contour_filled(breaks= breaks) +
        labs(fill=TeX('Range of values for $G_{n}(\\theta_{1})\' W_{n} G_{n}(\\theta_{2})$')) +
        theme(legend.position = "bottom") +
        guides(fill = guide_legend(nrow = 1)) +
        xlab(TeX('$\\theta_{1}$'))+
        ylab(TeX('$\\theta_{2}$'))
pp

H <- function(theta) { return( hessian(objective,theta) ) }

m1 = data.frame( x = grid, y = sapply( grid,objective ) )
m2 = data.frame( x = grid, y = sapply( grid,H ) )

p1 <- ggplot(m1,aes( x = x, y = y)) + 
        geom_line() + 
        ggtitle(TeX( 'Objective $Q_n =  \\bar{g}_n\'$ $\\bar{g}_n$ (non-convex)' )) +
        xlab(TeX('$\\theta$')) + ylab(TeX('$Q_n(\\theta)$'))
p2 <- ggplot(m2,aes( x = x, y = y)) + 
        geom_line() + 
        ggtitle(TeX( 'Hessian $\\partial^2_{\\theta} Q_n' )) +
        geom_hline( yintercept = 0, alpha = 0.2 ) +
        xlab(TeX('$\\theta$')) + ylab(TeX('$\\partial^2_{\\theta} Q_n(\\theta)$'))


p01 <- ggplot() + theme_void() + 
    ggtitle( TeX( 'Panel a) Sample Objective$' ) ) +
    theme(plot.title = element_text(size =12,hjust = 0.5, face='bold'))

pp11 <- plot_grid(p1,p2,ncol=2)

p02 <- ggplot() + theme_void() + 
    ggtitle( TeX( 'Panel b) Sample Moments$' ) ) +
    theme(plot.title = element_text(size =12,hjust = 0.5, face='bold'))


pp1 = plot_grid(p01,pp11,p02,pp,ncol=1,rel_heights = c(0.2,1,0.2,2))

setwd('/home/jj/Dropbox/jjlz/Write/Plots')

#ggsave(paste("MA1_p12.png",sep=""),plot = pp1, dpi = 300,width=13, height=7.0)


# Repeat all of the above with the optimal Weighting Matrix

library(sandwich)
StackLags <- function(p) {
    Y = matrix(0,n-p,p+1)
    for (l in 1:(p+1)) {
        Y[,l] = y[(p+2-l):(n-l+1)]
    }
    return(Y)
}
Y = StackLags(p)
reg <- lm(Y[,1]~Y[,2:(p+1)]-1)
V = n*vcovHAC(reg)

W = solve(V)

objective <- function(theta,disp = FALSE) {
    if (disp == TRUE) {
        print(theta)
    }
    mm = moments(theta)
    return( t(mm)%*%W%*%mm )
}

dQ <- function(theta,disp=FALSE) {
    return(-2*t(jacobian(beta,theta))%*%W%*%moments(theta))
}

optim(0.95,objective,gr=dQ,method="L-BFGS-B",lower=c(-1),upper=c(1),disp=TRUE)
optim(0.95,objective,gr=dQ,method="BFGS",disp=TRUE)


gamma = 0.1

start = seq(-0.99,0.99,1e-2)

coefsGN = matrix(0,100,length(start))
for (j in 1:length(start)) {
    coefsGN[1,j] = start[j]
    for (b in 2:100) {
        Gn = -jacobian(beta,coefsGN[b-1,j])
        coefsGN[b,j] = coefsGN[b-1,j] - gamma*solve(t(Gn)%*%W%*%Gn,t(Gn)%*%W%*%moments(coefsGN[b-1,j]))
    }
}

gammas = c(0.1,0.2,0.4,0.6,0.8,1)

cocos_Wn <- matrix(0,100,length(gammas))
cocos_Wn[1,] = 0.95
for (j in 1:length(gammas)) {
    try(
    for (b in 2:100) {
        Gn = -jacobian(beta,cocos_Wn[b-1,j])
        cocos_Wn[b,j] = cocos_Wn[b-1,j] - gammas[j]*solve(t(Gn)%*%W%*%Gn,t(Gn)%*%W%*%moments(cocos_Wn[b-1,j]))
    }
    )
}

coefsNR = rep(0,50)
coefsNR[1] = 0.95
for (b in 2:50) {
    Hn = hessian(objective,coefsNR[b-1])
    coefsNR[b] = coefsNR[b-1] - 0.1*solve(Hn,dQ(coefsNR[b-1]))
}

Whalf = sqrtm(V)$Binv

grid = seq(-1,1,1e-3)
M = matrix(NA,p,length(grid))
for (i in 1:length(grid)) {
    M[,i] = Whalf%*%jacobian(beta,grid[i])
}

GG = as.matrix(t(M)%*%M)
colnames(GG) = grid
rownames(GG) = grid

library(reshape2)
library(ggplot2)
library(latex2exp)
library(cowplot)

mm = melt(GG)

breaks = quantile(GG,c(0,5*1e-3,1e-2,0.1,0.2,0.5,0.8,1))
breaks = unique(sort(c(0,round(breaks,3))))

breaks[which(breaks>1)] = ceil(breaks[which(breaks>1)])

pp <- ggplot(mm, aes( Var1,Var2, z= value,fill = ..level.. )) +
        geom_contour_filled(breaks= breaks) +
        labs(fill=TeX('Range of values for $G_{n}(\\theta_{1})\' W_{n} G_{n}(\\theta_{2})$')) +
        theme(legend.position = "bottom") +
        guides(fill = guide_legend(nrow = 1)) +
        xlab(TeX('$\\theta_{1}$'))+
        ylab(TeX('$\\theta_{2}$'))
pp

H <- function(theta) { return( hessian(objective,theta) ) }

m1 = data.frame( x = grid, y = sapply( grid,objective ) )
m2 = data.frame( x = grid, y = sapply( grid,H ) )

p1 <- ggplot(m1,aes( x = x, y = y)) + 
        geom_line() + 
        ggtitle(TeX( 'Objective $Q_n =  \\bar{g}_n\' W_{n} \\bar{g}_n$ (non-convex)' )) +
        xlab(TeX('$\\theta$')) + ylab(TeX('$Q_n(\\theta)$'))
p2 <- ggplot(m2,aes( x = x, y = y)) + 
        geom_line() + 
        ggtitle(TeX( 'Hessian $\\partial^2_{\\theta} Q_n' )) +
        geom_hline( yintercept = 0, alpha = 0.2 ) +
        xlab(TeX('$\\theta$')) + ylab(TeX('$\\partial^2_{\\theta} Q_n(\\theta)$'))


p01 <- ggplot() + theme_void() + 
    ggtitle( TeX( 'Panel a) Sample Objective$' ) ) +
    theme(plot.title = element_text(size =12,hjust = 0.5, face='bold'))

pp11 <- plot_grid(p1,p2,ncol=2)

p02 <- ggplot() + theme_void() + 
    ggtitle( TeX( 'Panel b) Sample Moments$' ) ) +
    theme(plot.title = element_text(size =12,hjust = 0.5, face='bold'))


pp1 = plot_grid(p01,pp11,p02,pp,ncol=1,rel_heights = c(0.2,1,0.2,2))

setwd('/home/jj/Dropbox/jjlz/Write/Plots')

ggsave(paste("MA1_p12_optimalW.png",sep=""),plot = pp1, dpi = 300,width=13, height=7.0)