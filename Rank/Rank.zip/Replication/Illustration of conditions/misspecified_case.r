rm(list=ls())

library(ggplot2)
library(latex2exp)
library(cowplot)

setwd('/home/jj/Dropbox/jjlz/Code/BLP') # !!! adjust to match personal environment !!!

maker <- function(sigma_l, L, rho) {
  #sigma_l <- 1.0
  
  c1_l <- (2/3)*rho^2*sigma_l^4
  c_2 <- 1/(sigma_l)^4
  c3_u <- 2

  gamma_u <- c1_l/(2*c_2)
  phi_u <- sigma_l^2/(2*L)

  epsilon <- 0.0001

  f <- function(gamma,phi) { 
    a1 = ((1-epsilon)*sigma_l/L-phi/sigma_l)^2
    a2 = - phi^2/(sigma_l^2/2-phi*L)^2*((sigma_l^2/2-phi*L)*gamma^2*c_2+2*gamma*c3_u^2/c1_l)
    a3 = (gamma*c1_l/2-gamma^2*c_2)
    return( a1 + a2/a3 )
  }

  gammas = seq(0,gamma_u,1e-5)

  phis = seq(1e-6,phi_u,1e-3)
  gams = rep(0,length(phis))
  for (i in 1:length(phis)) {
    gg = sapply(gammas,f,phi=phis[i])
    gg[1] = Inf
    #ggm = min(gg^2)
    #if (ggm > 1e-3) {
     # gams[i] = NA
    #} else {
    #  gams[i] = gammas[max(which( gg^2 == min(gg^2) ))]
    #}
    #gams[i] = uniroot(f,c(1e-6,gamma_u),phi=phis[i])$root
    gams[i] = gammas[max(which( gg>=0 ))]
  }

  gams[which(gams == min(gammas))] = NA

  out = data.frame(gamma = gams,phi = phis, phi_u=phi_u, gamma_u=gamma_u)
  return(out)
}

out1 = maker(1,1,1)
out2 = maker(0.9,1,1)

out3 = maker(1,0.1,1)
out4 = maker(0.9,0.1,1)


out5 = maker(1,1,0.9)
out6 = maker(0.9,0.1,0.9)

p1 <- ggplot( out1, aes(x = phi, y = gamma, ymin = 0) ) +
  ylim(c(0,1)) + xlim(c(0,0.8)) +
  annotate("rect", xmin=0, xmax=0.8, ymin=0, ymax=1, alpha=0.3, fill="orange",color="gray") +
  annotate("rect", xmin=0, xmax=min(0.8,mean(out1$phi_u)), ymin=0, ymax=min(1,mean(out1$gamma_u)), alpha=0.3, fill="#4500ACFF",color="gray") +
  geom_area(position = "identity",alpha= 0.3,fill = "blue") +
  geom_line() +
  xlab(TeX('Degree of Misspecification: $\\phi$')) +
  ylab(TeX('Learning Rate: $\\gamma$ ')) +
  ggtitle(TeX('$\\underline{\\sigma}=1$, $L=1$, $\\rho=1$')) +
  geom_text(aes(x = 0.02,y=0.15,label="(A)"),size=3) +
  geom_text(aes(x = 0.25,y=0.15,label="(B)"),size=3)+
  geom_text(aes(x = 0.4,y=0.75,label="(C)"),size=3)

p2 <- ggplot( out2, aes(x = phi, y = gamma) ) +
  ylim(c(0,1)) + xlim(c(0,0.8)) +
  annotate("rect", xmin=0, xmax=0.8, ymin=0, ymax=1, alpha=0.3, fill="orange",color="gray") +
  annotate("rect", xmin=0, xmax=min(0.8,mean(out2$phi_u)), ymin=0, ymax=min(1,mean(out2$gamma_u)), alpha=0.3, fill="#4500ACFF",color="gray") +
  geom_area(position = "identity",alpha= 0.3,fill = "blue") +
  geom_line() +
  xlab(TeX('Degree of Misspecification: $\\phi$')) +
  ylab(TeX('Learning Rate: $\\gamma$ ')) +
  ggtitle(TeX('$\\underline{\\sigma}=0.9$, $L=1$, $\\rho=1$')) +
  geom_text(aes(x = 0.01,y=0.06,label="(A)"),size=3) +
  geom_text(aes(x = 0.2,y=0.075,label="(B)"),size=3)+
  geom_text(aes(x = 0.4,y=0.625,label="(C)"),size=3)


p3 <- ggplot( out3, aes(x = phi, y = gamma, ymin = 0) ) +
  ylim(c(0,1)) + xlim(c(0,0.8)) +
  annotate("rect", xmin=0, xmax=0.8, ymin=0, ymax=1, alpha=0.3, fill="orange",color="gray") +
  annotate("rect", xmin=0, xmax=min(0.8,mean(out3$phi_u)), ymin=0, ymax=min(1,mean(out3$gamma_u)), alpha=0.3, fill="#4500ACFF",color="gray") +
  geom_area(position = "identity",alpha= 0.3,fill = "blue") +
  geom_line() +
  xlab(TeX('Degree of Misspecification: $\\phi$')) +
  ylab(TeX('Learning Rate: $\\gamma$ ')) +
  ggtitle(TeX('$\\underline{\\sigma}=1$, $L=0.1$, $\\rho=1$')) +
  geom_text(aes(x = 0.3,y=0.15,label="(A)"),size=3) +
  geom_text(aes(x = 0.7,y=0.2,label="(B)"),size=3)+
  geom_text(aes(x = 0.4,y=0.75,label="(C)"),size=3)

p4 <- ggplot( out4, aes(x = phi, y = gamma) ) +
  ylim(c(0,1)) + xlim(c(0,0.8)) +
  annotate("rect", xmin=0, xmax=0.8, ymin=0, ymax=1, alpha=0.3, fill="orange",color="gray") +
  annotate("rect", xmin=0, xmax=min(0.8,mean(out4$phi_u)), ymin=0, ymax=min(1,mean(out4$gamma_u)), alpha=0.3, fill="#4500ACFF",color="gray") +
  geom_area(position = "identity",alpha= 0.3,fill = "blue") +
  geom_line() +
  xlab(TeX('Degree of Misspecification: $\\phi$')) +
  ylab(TeX('Learning Rate: $\\gamma$ ')) +
  ggtitle(TeX('$\\underline{\\sigma}=0.9$, $L=0.1$, $\\rho=1$')) +
  geom_text(aes(x = 0.15,y=0.06,label="(A)"),size=3) +
  geom_text(aes(x = 0.6,y=0.06,label="(B)"),size=3)+
  geom_text(aes(x = 0.4,y=0.625,label="(C)"),size=3)


p5 <- ggplot( out5, aes(x = phi, y = gamma, ymin = 0) ) +
  ylim(c(0,1)) + xlim(c(0,0.8)) +
  annotate("rect", xmin=0, xmax=0.8, ymin=0, ymax=1, alpha=0.3, fill="orange",color="gray") +
  annotate("rect", xmin=0, xmax=min(0.8,mean(out5$phi_u)), ymin=0, ymax=min(1,mean(out5$gamma_u)), alpha=0.3, fill="#4500ACFF",color="gray") +
  geom_area(position = "identity",alpha= 0.3,fill = "blue") +
  geom_line() +
  xlab(TeX('Degree of Misspecification: $\\phi$')) +
  ylab(TeX('Learning Rate: $\\gamma$ ')) +
  ggtitle(TeX('$\\underline{\\sigma}=1$, $L=1$, $\\rho=0.9$' )) +
  geom_text(aes(x = 0.02,y=0.15,label="(A)"),size=3) +
  geom_text(aes(x = 0.25,y=0.15,label="(B)"),size=3)+
  geom_text(aes(x = 0.4,y=0.75,label="(C)"),size=3)

p6 <- ggplot( out6, aes(x = phi, y = gamma) ) +
  ylim(c(0,1)) + xlim(c(0,0.8)) +
  annotate("rect", xmin=0, xmax=0.8, ymin=0, ymax=1, alpha=0.3, fill="orange",color="gray") +
  annotate("rect", xmin=0, xmax=min(0.8,mean(out6$phi_u)), ymin=0, ymax=min(1,mean(out6$gamma_u)), alpha=0.3, fill="#4500ACFF",color="gray") +
  geom_area(position = "identity",alpha= 0.3,fill = "blue") +
  geom_line() +
  xlab(TeX('Degree of Misspecification: $\\phi$')) +
  ylab(TeX('Learning Rate: $\\gamma$ ')) +
  ggtitle(TeX('$\\underline{\\sigma}=0.9$, $L=0.1$, $\\rho=0.9$')) +
  geom_text(aes(x = 0.1,y=0.06,label="(A)"),size=3) +
  geom_text(aes(x = 0.5,y=0.06,label="(B)"),size=3)+
  geom_text(aes(x = 0.4,y=0.625,label="(C)"),size=3)

pp <- plot_grid(p1,p2,p3,p4,p5,p6,ncol=2)
ggsave("TH3_plot.png", plot = pp, dpi = 300,width=13, height=9.0)
save.image()