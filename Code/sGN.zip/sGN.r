# Implements the sGN Algorithm in
# "Noisy, Non-Smooth, Non-Convex Estimation of Moment Condition Models"
#  by Jean-Jacques Forneron

# The implementation uses quasi Gauss-Newton Monte-Carlo and Acceleration
# (Extensions 1 and 2 of Algorithm 1)

# Disclaimer: There is no error handling, if the moments return Inf, NA, etc., the code will most likely crash

library(randtoolbox) # Used to generate the covering sequence

sGN <- function( mom, learn = 0.1, alpha = 0.47, maxit = 250, eps = 0.1,
                LM = TRUE, seed = NULL, L = NULL, init = NULL, W = NULL,      
                lb = NULL, ub = NULL, global = FALSE, verbose = FALSE ) {
    
    # mom: function which returns moments
    # learn = learning rate in (0,1)
    # alpha = momentum in [0,1)
    # maxit = maximum number of iterations (stopping criterion)
    # eps = smoothing parameter

    # LM = use Levenberg–Marquardt algorithm in the first few iterations
    # (yields more stable iterations away from the solution, in particular around values for which the Jacobian Gn is ill-conditioned)

    # seed : used for the Monte-Carlo draws used to compute G_{n,eps}

    # L = number of Monte-Carlo draws used to compute G_{n,eps}, 
    #     defaults to ceil( max(25,p*1.5 ) ), p = no. of parameters
    #     for very small values of eps, it is recommended to use a larger L
    #     to compensate the increase in variance
    #     this code only updates one direction at each iteration, in some cases 
    #     updating several in parallel can speed-up convergence

    # init = starting value, optional when global = TRUE, required if global = FALSE

    # lb, ub = lower/upper bounds for parameters, optional if global = FALSE
    # global = FALSE: local step only
    # global = TRUE:  local and global step

    # verbose = TRUE: print a few coefficients and objective value

    if (!is.null(seed)) {
        set.seed(seed) # locally set the seed (within the function)
    }
    pb = txtProgressBar(min=0,max=maxit)

    if (global == FALSE) {
        if (is.null(init)) {
            print("Error: local step only, starting value required")
            return();
        } else {
            p = length(init)
        }
    } else {
        if ( is.null(lb) || is.null(ub) ) {
            print("Error: global step, parameter bounds required")
            return()
        } else {
            p = length(lb)
            grid = sobol(maxit,p,scrambling = 1)

            for (j in 1:p) { 
                grid[,j] = lb[j] + (ub[j]-lb[j])*grid[,j] 
            }
            if (!is.null(init)) {
                grid = rbind(init,grid)
            } else {
                init = grid[1,]
            }
        }
    }

    if (is.null(L)) {
        L = max(25,ceiling(1.5*p) )
    } else if  (L < p) {
        print("Error: L is too small")
        return();
    }

    if (LM == TRUE) {
        lbd = 1e-2
    } else {
        lbd = 0
    }

    coefs = matrix(0,maxit,p) # matrix of coefficients
    objs  = rep(0,maxit)      # keep track of objective values

    coefs[1,] = init # starting value
    sb = rep(0,p) # momentum initialized at 0

    par = coefs[1,]
    mom0 = mom(par) # moments at starting value
    
    k = length(mom0)      # number of moments

    if (is.null(W)) {
        W = diag(k) # Identity weighting by default
    }

    objs[1] = t(mom0)%*%W%*%mom0

    # Initialize the Jacobian matrix G_{n,eps}:
    Zb = matrix(0,L,p)
    Yb = matrix(0,L,k)

    for (j in 1:L) {
            Zb[j,] = rnorm(p) # Z ~ N(0,1)
            Yb[j,] = (mom(par+eps*Zb[j,])-mom0)/eps
    }

    Gb = t(lm(Yb~Zb)$coef[2:(p+1),]) # Jacobian estimate
    I = diag(p)

    if (verbose == TRUE) {
        b = 1
        cat('=====================\n')
            cat(paste(
              " Iteration:", b,"\n",
              " // Objective value:", round(objs[b],4),"\n"))
    }

    # Main Loop:
    for (b in 2:maxit) {

        # Local Step
        Hb = t(Gb)%*%W%*%Gb
        

        coefs[b,] = coefs[b-1,] - learn*solve( Hb + lbd*mean(diag(Hb))*I/b, t(Gb)%*%W%*%mom0 ) + alpha*sb

        sb = coefs[b,] - coefs[b-1,] # update momentum

        mom0 = mom(coefs[b,])         # update moments
        objs[b] = t(mom0)%*%W%*%mom0  # update objective

        update = TRUE # update G_{n,eps}

        if (global == TRUE) { # Global step

            mom1 = mom(grid[b,])
            obj1 = t(mom1)%*%W%*%mom1

            if (obj1 < objs[b]) { 

                # The global step is binding
                print('Switch: global step strictly improves on local step')

                # Swap values:
                coefs[b,] = grid[b,]
                mom0 = mom1
                objs[b] = obj1

                sb = rep(0,p) # reset momentum to zero

                # Reset the jacobian
                par = grid[b,]
                for (j in 1:L) {
                    Zb[j,] = rnorm(p) # Z ~ N(0,1)
                    Yb[j,] = (mom(par+eps*Zb[j,])-mom0)/eps
                }

                update = FALSE # G_{n,eps} has already been updated

            }
        }

        if (update == TRUE) {
            par = coefs[b,]
            Zb = rbind( Zb[-1,], rnorm(p) )
            Yb = rbind( Yb[-1,], (mom(par+eps*Zb[L,])-mom0)/eps )
        }

        Gb = t(lm(Yb~Zb)$coef[2:(p+1),]) # New Jacobian estimate

        if ( (verbose == TRUE) && (b %% 50 == 0) ) {

            cat('=====================\n')
            cat(paste(
              " Iteration:", b,"\n",
              " // Objective value:", round(objs[b],4),"\n"))
        }

    }

    close(pb)

    return( list( par = coefs[which(objs==min(objs))[1],], objs = objs, coefs = coefs  ) )

}