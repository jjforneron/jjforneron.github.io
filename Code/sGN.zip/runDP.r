

# The following replicates Dynamic Probit example in 
# "Noisy, Non-Smooth, Non-Convex Estimation of Moment Condition Models"
# by Jean-Jacques Forneron

# The data generating process (DGP) is:
# y_{it} = 1{ x_{it}'beta + u_{it} > 0 }
# u_{it} = rho*u_{it-1} + e_{it}, with e_{it} iid N(0,1)

set.seed(123)
library(xtable)     # Export table to Latex format
library(ggplot2)    # Create plots
library(reshape)    # Data frame manipulation
library(latex2exp)  # Add latex code to plots

setwd('/home/jj/Dropbox/GNM/Replication Code/Dynamic Probit/')
source("sGN.r")

# Parameters for the DGP:
K   = 14  # number of regressors (x_{it})
rho = 0.7 # persistence of u_{it}

# Panel dimensions:
n = 250
T = 10

sim_data <- function(par,shocks,X,smooth = FALSE, bdw = 0.1) {
    # Simulate data from DGP with regressors X, shocks e 

    # X is an array of dimension (T x n x K)
    # par = (beta,rho)
    
    # smooth = TRUE --> Generalized Indirect Inference (GII), 
    # replaces 1{} with Gaussian CDF and bandwidth = bdw

    # Parameters
    beta = par[1:K] 
    rho  = tanh(par[K+1])

    # Panel dimensions
    T    = dim(shocks)[1]
    n    = dim(shocks)[2]

    # Compute u_{it} and x_{it}'beta
    e  = matrix(0,T+1,n)
    xb = matrix(0,T,n) 
    for (t in 2:(T+1)) {
        e[t,] = rho*e[t-1,] + shocks[t-1,]
        xb[t-1,] = X[t-1,,]%*%beta
    } 
    e = e[2:(T+1),]

    # Compute y_{it} using DGP (smooth = FALSE) or GII (smooth = TRUE)
    if (smooth == TRUE) {
        y = pnorm( (xb + e)/bdw  )
    } else {
        y = 1*( xb + e >= 0 )
    }
    
    return(y)
}

moments <- function(y,X) {
    # Computes the moments used for estimation:
    # OLS coefficients for the Linear Probability Model:
    # y_{it} = x_{it}'gamma1 + y_{it-1}gamma2 + error
    # moments = (gamma1,gamma2)
    
    # Matrix of regressors (x_{it},y_{it-1}):
    Z = array(0,dim=c(dim(X)[1],dim(X)[2],dim(X)[3]+1))
    Z[,,1:K]=X
    Z[,,K+1] = rbind(0, y[1:(T - 1), ])
    Zx = matrix(Z,n*T,K+1)
    Yx = c(y)

    # Estimate linear regression:
    mod = lm(Yx~Zx)

    # Return OLS coefficients:
    return(c(mod$coef))
}

obj <- function(par,mom,shocks,X,smooth = FALSE, bdw = 0.1) {
    # Objective function = gn'*gn (W = Id)
    # par = (beta,rho)
    # mom = sample moments (data)

    # Simulate data 
    ys   = sim_data(par,shocks,X,smooth,bdw)

    # Compute moments: moms (simulated data)
    moms = moments(ys,X)

    # Compute (mom-moms)'*(mom-moms)
    dist = sum( (mom-moms)^2 )
    
    # Return n*(mom-moms)'*(mom-moms)
    return(n*dist)
}

# Bandwiths used for smoothing:
epses = c(0.5,0.25,0.1,0.05,0.01,0.005)

# Number of Monte-Carlo replications:
MCrep = 100

# Arrays to store estimates
# out_coefs_s1  = BFGS distant starting value
# out_coefs_s2  = BFGS true starting value
# out_coefs_sgn = sGN (local step only) distant starting value
out_coefs_s1   = array(0,dim=c(K+2,length(epses),MCrep))
out_coefs_s2   = array(0,dim=c(K+2,length(epses),MCrep))
out_coefs_sgn  = array(0,dim=c(K+2,length(epses),MCrep))

for (kb in 1:MCrep) {

    X = array(rnorm(n*T*K),dim=c(T,n,K))
    beta = c(rep(1/sqrt(5),5),rep(0,K-5))

    shocks = matrix(rnorm(n*T),T,n)

    data = sim_data(c(beta,rho),shocks,X)
    mom = moments(data,X)
    print(mom)

    shocks_s = matrix(rnorm(n*T),T,n)

    #out1 = optim(c(rep(0,length(beta)),0),obj,shocks=shocks_s,X=X,mom=mom,control=list(abstol=1e-6,maxit=1e4))
    #out2 = optim(c(rep(0,length(beta)),0),obj,shocks=shocks_s,X=X,mom=mom,method="BFGS",control=list(abstol=1e-6,maxit=1e4))


    coefs_s1 = matrix(0,K+2,length(epses))
    for (j in 1:length(epses)) {
        out2s = optim(c(rep(0,length(beta)),0),obj,shocks=shocks_s,X=X,mom=mom,smooth=TRUE,bdw=epses[j],method="BFGS",control=list(abstol=1e-6,maxit=1e4))
        coefs_s1[,j] = c(out2s$par,obj(out2s$par,mom,shocks_s,X))
    }
    coefs_s1[K+1,] = tanh(coefs_s1[K+1,])

    coefs_s2 = matrix(0,K+2,length(epses))
    for (j in 1:length(epses)) {
        out2s = optim(c(beta,tanh(rho)),obj,shocks=shocks_s,X=X,mom=mom,smooth=TRUE,bdw=epses[j],method="BFGS",control=list(abstol=1e-6,maxit=1e4))
        coefs_s2[,j] = c(out2s$par,obj(out2s$par,mom,shocks_s,X))
    }
    coefs_s2[K+1,] = tanh(coefs_s2[K+1,])

    #out3 = optim(c(rep(0,length(beta)),0),obj,shocks=shocks_s,X=X,mom=mom,method="SANN",control=list(abstol=1e-6,maxit=1e3))
    #out4 = optim(out3$par,obj,shocks=shocks_s,X=X,mom=mom,method="Nelder-Mead",control=list(abstol=1e-6,maxit=1e4))

    coefs_sgn = matrix(0,K+2,length(epses))

    W = n*diag(length(mom))

    for (jiji in 1:length(epses)) {

        eps = epses[jiji]

        L = floor(25*(1+log(1+abs(log(eps))))) 
        # when using only the local step, this is more reliable for the very small eps = 0.005, this yields L = (38 46 54 59 68 71)
        # adding the global step makes the procedure more robust to tuning parameters, but do keep in mind that the moments are discontinuous, so epsilon should not be arbitrarily close to zero

        momt <- function(par) {datas = sim_data(par,shocks_s,X);return(mom-moments(datas,X))}
        zz = sGN(momt,init = rep(0,K+1),L=L,eps=eps,W=W,verbose = TRUE)
        coefs_sgn[,jiji] = c(zz$par,min(zz$objs))
    }
    coefs_sgn[K+1,] = tanh(coefs_sgn[K+1,])

    out_coefs_s1[,,kb] = coefs_s1
    out_coefs_s2[,,kb] = coefs_s2
    out_coefs_sgn[,,kb] = coefs_sgn
    print(rbind(coefs_s1[K+2,],coefs_s2[K+2,],coefs_sgn[K+2,]))
}


round(coefs_sgn,3)



#colnames(coefs_s) = epses
#colnames(coefs_sgn) = epses

#out = cbind(c(beta,rho,NA),coefs_sgn,coefs_s)

#xtable(t(out[c(1:6,15:16),]),digits=2)

#print(round(out[c(1:6,15:16),],2))


out1 = t(out_coefs_s1[K+2,,])
out2 = t(out_coefs_s2[K+2,,])
out3 = t(out_coefs_sgn[K+2,,])

colnames(out1) = epses
colnames(out2) = epses
colnames(out3) = epses

m1 = melt(out1)
m2 = melt(out2)
m3 = melt(out3)

colnames(m1) = c('Method','Eps','Qn')
colnames(m2) = c('Method','Eps','Qn')
colnames(m3) = c('Method','Eps','Qn')

m1$Method = 'BFGS (Distant Starting Value)'
m2$Method = 'BFGS (Starting Value = True Value)'
m3$Method = 'sGN (Distant Starting Value)'

mf = rbind(m1,m2,m3)
mf$Eps = as.factor(mf$Eps)

p <- ggplot(mf,aes(x = Eps, y = Qn,fill = Method)) + geom_boxplot(alpha=0.4) +
    facet_wrap(.~Method) + scale_y_continuous (trans='log10') + 
    scale_fill_manual(values=c("blue", "orange", "#999999")) +
    theme(legend.position = "none",
    strip.text = element_text(size=14)) +
    labs(y = TeX("Objective $Q_n$ (log-scale)"), x = TeX("Smoothing Parameter $\\epsilon"))


setwd('/home/jj/Dropbox/GNM/Write/Plots')
#ggsave('DynamicPanelQn.png',p,dpi = 300,width=12, height=2.5)

out_med1 = rbind( apply((t(out_coefs_sgn[1,,])-0.45),2,mean),
                  apply((t(out_coefs_s1[1,,])-0.45),2,mean),
                  apply((t(out_coefs_s2[1,,])-0.45),2,mean) )

out_mae1 = rbind( apply(abs(t(out_coefs_sgn[1,,])-0.45),2,mean),
                apply(abs(t(out_coefs_s1[1,,])-0.45),2,mean),
                apply(abs(t(out_coefs_s2[1,,])-0.45),2,mean) )


out_med2 = rbind( apply((t(out_coefs_sgn[K+1,,])-0.7),2,mean),
                  apply((t(out_coefs_s1[K+1,,])-0.7),2,mean),
                  apply((t(out_coefs_s2[K+1,,])-0.7),2,mean) )

out_mae2 = rbind( apply(abs(t(out_coefs_sgn[K+1,,])-0.7),2,mean),
                apply(abs(t(out_coefs_s1[K+1,,])-0.7),2,mean),
                apply(abs(t(out_coefs_s2[K+1,,])-0.7),2,mean) )

out_f1 = rbind(out_med1,out_mae1)
colnames(out_f1) = epses

out_f2 = rbind(out_med2,out_mae2)
colnames(out_f2) = epses

out_f1 = out_f1[,dim(out_f1)[2]:1]
out_f2 = out_f2[,dim(out_f2)[2]:1]

out_f = cbind(out_f1,out_f2)

xtable(out_f,digits=3)