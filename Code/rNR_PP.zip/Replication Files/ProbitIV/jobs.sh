#!/bin/bash -l 
module load R
#$ -l h_rt=160:00:00
#$ -pe omp 4 

# Submit an array job with 4 tasks 
#$ -t 1:20

echo "=========================================================="
echo "Starting on: $(date)"
echo "Running on)node: $(hostname)"
echo "Current directory: $(pwd)"
echo "Current job ID: $JOB_ID"
echo "Current job name: $JOB_NAME"
echo "Task index number: $SGE_TASK_ID"
echo "=========================================================="



# Use the SGE_TASK_ID environment variable to select the appropriate input file from bash array
# Bash array index starts from 0, so we need to subtract one from SGE_TASK_ID value
inputs=(1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20)
index=$(($SGE_TASK_ID-1))
taskinput=${inputs[$index]}

cd /usr2/faculty/jjmf/rNR/ProbitIV
Rscript /usr2/faculty/jjmf/rNR/ProbitIV/ProbitIV.R $taskinput > /usr2/faculty/jjmf/rNR/ProbitIV/Output/ProbitIV$SGE_TASK_ID.out
