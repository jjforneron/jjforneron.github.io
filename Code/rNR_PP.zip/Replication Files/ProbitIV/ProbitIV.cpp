// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>

#include <iostream>
#include <math.h>
#include <omp.h>

// [[Rcpp::plugins(openmp)]]

using namespace Rcpp;
using namespace arma;
using namespace std;


// [[Rcpp::export]]
mat moments(const colvec theta, const mat Y, const mat X, const mat Z) {
    // compute sample moments for the Probit IV model
    
    // declare useful variables:
    // sample size n, coefficients pi, xi, alpha, beta and rho
    const int n = Y.n_rows;
    const colvec pi    = theta(span(0,1));
    const double xi    = theta(2);
    const double alpha = theta(3);
    const colvec beta  = theta(span(4,5));
    const double rho   = theta(6);
    
    // compute residuals in first and then second stage regressions
    colvec r2 = Y.col(1) - ( X*pi + Z*xi );
    colvec r1 = Y.col(0) - normcdf( alpha*Y.col(1) + X*beta + rho*r2 );

    // compute moments as described in the paper
    mat R1 = join_rows(X,Z,r2);
    mat R2 = join_rows(X,Z);

    for (int i=0;i<R1.n_cols;i++) {
        R1.col(i) = R1.col(i) % r1;
    }

    for (int i=0;i<R2.n_cols;i++) {
        R2.col(i) = R2.col(i) % r2;
    }

    // return sample moments (before averaging)
    return(join_rows(R1,R2));
}

// [[Rcpp::export]]
colvec moms(const colvec theta, const mat Y, const mat X, const mat Z) {
    // compute sample moments for the Probit IV model
    
    const mat mom = moments(theta, Y, X, Z); // compute moments

    // return sample moments (after averaging)
    return(mean(mom,0).t());
}

// [[Rcpp::export]]
double objective(const colvec theta, const mat Y, const mat X, const mat Z) {
    // compute sample moments for the Probit IV model
    
    const colvec mom = moms(theta, Y, X, Z); // compute moments

    return( as_scalar(mom.t()*mom) ); // GMM objective function
}
