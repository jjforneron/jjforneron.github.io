setwd('/usr2/faculty/jjmf/rNR/ProbitIV') # set this to local environment

# the functions for Probit IV are in a ProbitIV package to be installed locally (R version 4.0.3, compiled in linux)
# in a cluster environment, run the following:

# install.packages('ProbitIV_1.0.tar.gz',lib='/usr2/faculty/jjmf/rNR/ProbitIV/Pack') 
# don't forget to set lib to local environment
# lib='Pack' points to the folder where the package will be installed.

# load Probit IV functions
library(ProbitIV,lib = '/usr2/faculty/jjmf/rNR/ProbitIV/Pack') # set lib to local environment

# the package loads the following functions:
#   moments: return a n*k matrix of moments g(xi,theta)
#   moms: returns a k*1 vector, with the sample average of moments above
#   objective: returns the GMM objective function Qn = moms'*moms 

# ************************************************
# Alternatively, the source code can be compiled 
# locally using the appropriate toolchain and
# Rcpp, RcppArmadillo with the commands:
#
# library(Rcpp)
# library(RcppArmadillo)
# sourceCpp('ProbitIV.cpp')
# ************************************************

library(pracma) # to compute numerical derivatives
# library(nloptr) alternative optimizers

m = 50

# see jobs.sh file
# the qsub environment passes an index to split into 20 independent jobs
# producing 50 Monte-Carlo replications each. To run locally, simply replacy with index = 1
# and comment out the args line below
args <- commandArgs(TRUE)
index = as.numeric(args[1])

# set the seed
seed = index*1000
set.seed(seed)

# output file to store results
file = paste('ProbitIV',m,'_',seed,'.RData',sep="")

get_CI <- function(x,adj,q=c(0.025,0.975)) {
    m = mean(x)
    q = m + quantile( (x-m)*adj, q )
    return(q)
}

init = rep(0,7) # starting value for the optimizers = (0,...,0)

n = 500
#m = 100

B  = 2e3 # number of rNR, rqN draws
Bb = 500 # number of bootstrap draws

# learning rate, change to 0.2 or 0.1 to get results in the table
learn = 0.2

reps = 50 # 50 MC replications for each process (see index, args above and jobs.sh)

# arrays to store estimates and inference results
reject    = array(NA,dim = c(reps,7,5))
estimates = array(NA,dim = c(reps,7,3)) 

# true coefficients theta
true = c(0,1,1,1,0,1,1)
true2 = rbind(true,true)

# run MC replications
for (i in 1:reps) {

    # simulate Probit IV data: shocks
    u = rnorm(n)
    v = rnorm(n)

    # controls, instrument
    x = rexp(n)
    z = rexp(n)

    #endogenous regressor
    y2 = x + z + u
    # outcome
    y1 = 1*( y2 + x + v + u > 0 )

    # stack in matrix form
    Y = cbind(y1,y2)
    X = cbind(1,x)
    Z = matrix(z,n,1)

    # estimation by BFGS
    est1 = optim(init,objective,method="BFGS",control = list(maxit = 2e3,abstol = 1e-8),Y=Y,X=X,Z=Z)

    # compute standard errors using the sandwich formula
    param = est1$par
    mom = moments(param,Y,X,Z)
    V = var(mom)
    G = jacobian(moms,param,Y=Y,X=X,Z=Z)
    ses = sqrt(diag(solve(t(G)%*%solve(V,G))/n))

    cbind(true,param,ses)

    # ***********************************************
    # ****************** Bootstrap ******************
    # ***********************************************

    # matrix to store bootstrap draws
    coefs = matrix(NA,Bb,length(param))

    for (b in 1:Bb) {
        ind = sample(1:n,m,replace=TRUE) # re-sample the data
        est_b = optim(param,objective,method="BFGS",Y=Y[ind,],X=X[ind,],Z=matrix(Z[ind],m,1),control=list(maxit=2e3)) # estimate on re-sampled data
        coefs[b,] = est_b$par # store estimates
    }

    # **************************************************************
    # ****************** Resampled Newton-Raphson ******************
    # **************************************************************

    # matrix to store rNR draws
    coefs_rNR = matrix(NA,B,length(param))

    # initialize at the same starting value as estimation
    coefs_rNR[1,] = init
    for (b in 2:B) {
        ind = sample(1:n,m,replace=TRUE) # re-sample the data

        mom_b  = moms(coefs_rNR[b-1,],Y[ind,],X[ind,],matrix(Z[ind],m,1)) # re-sampled moments
        G_b    = jacobian(moms,coefs_rNR[b-1,],Y=Y[ind,],X=X[ind,],Z=matrix(Z[ind],m,1)) # re-sampled gradient

        GG = t(G_b)%*%G_b # re-sampled hessian
        # this is faster than using the hessian function and still fairly accurate

        # compute the direction of update, the hessian is singular at (0,...,0) because
        # the predicted y2 are always 0, we regularize the hessian for the first few iterates and
        # then estimation goes on
        sk = -learn*solve(GG + 1e-3*diag(7)*sum(diag(GG))/b, t(G_b)%*%mom_b )

        # computed latest draw
        coefs_rNR[b,] = coefs_rNR[b-1,] + sk
    }

    # ************************************************************
    # ****************** Resampled quasi-Newton ******************
    # ************************************************************

    # matrix to store rqN draws
    coefs_rqN = matrix(NA,B,length(param))

    # initialize at the same starting value as estimation
    coefs_rqN[1,] = init

    # initialize at the least-squares interpolation of the jacobian of the moments
    # we use this to compute both the gradient and the hessian

    L = 20 # number of interpolation points
    k  = length(init) # number of parameters in theta
    Yb = matrix(NA,L,k) # Hessian-vector products
    Sb = matrix(NA,L,k) # directions

    # Compute the jacobian at the initial value
    Gb    = jacobian(moms,coefs_rNR[b-1,],Y=Y,X=X,Z=Z) 

    # compute random directions and hessian-vector products
    for (b in 1:L) {
        Sb[b,] = rnorm(k)
        Sb[b,] = Sb[b,]/sqrt(sum(Sb[b,]^2))
        Yb[b,] = Gb%*%Sb[b,]
    }

    # Least-Squares interpolation
    G1 = (t(Yb)%*%Sb%*%solve(t(Sb)%*%Sb))

    # re-sampled the data for the next iteration
    ind = sample(1:n,m,replace=TRUE)

    # keep track of the objective function to monitor convergence
    objs = rep(0,B)
    objs[1] = objective(coefs_rqN[1,],Y,X,Z)

    # rqN iterations:
    b = 2
    while (b <= B) {
        
        # compute re-sampled moments
        mb    = moms(coefs_rqN[b-1,],Y[ind,],X[ind,],matrix(Z[ind],m,1))

        # compute interpolated Hessian
        GG = t(G1)%*%G1

        # compute direction of update
        sk = -learn*solve(GG + 1e-3*diag(7)*sum(diag(GG))/b, t(G1)%*%mb )

        # compute the latest draw
        coefs_rqN[b,] = coefs_rqN[b-1,] + sk
        objs[b] = objective(coefs_rqN[b,],Y,X,Z) # keep track of the objective function

        # re-sample data for the next draw
        ind = sample(1:n,m,replace=TRUE)

        # if everything is going well, update the least-squares interpolation
        if ( objs[b] <= 50*objs[b-1] ) {
            sk = c(sk)/sqrt(sum(sk^2)) # direction
            Sb = rbind(Sb[-1,],sk)
            
            yk = (moms(coefs_rqN[b,]+sk*1e-8,Y[ind,],X[ind,],matrix(Z[ind],m,1)) - moms(coefs_rqN[b,]-sk*1e-8,Y[ind,],X[ind,],matrix(Z[ind],m,1)))/(2*1e-8) # hessian-vector product
            Yb = rbind(Yb[-1,],c(yk)/sqrt(sum(sk^2)))
            G1 = (t(Yb)%*%Sb%*%solve(t(Sb)%*%Sb)) # Least-Squares interpolation

            b = b + 1
        } else {
            # if something went wrong, re-initialize the Least-Squares interpolation and discard the draw
            print('reboot')
            G = jacobian(moms,coefs_rNR[b-1,],Y=Y[ind,],X=X[ind,],Z=matrix(Z[ind],m,1))

            for (b in 1:L) {
                Sb[b,] = rnorm(k)
                Sb[b,] = Sb[b,]/sqrt(sum(Sb[b,]^2))
                Yb[b,] = G%*%Sb[b,]
            }

            G1 = (t(Yb)%*%Sb%*%solve(t(Sb)%*%Sb))

        }
        
    }

    # compute confidence intervals

    CIs = rbind(param - 1.96*ses,param + 1.96*ses)

    coefs_ = kronecker(matrix(param,1),matrix(1,Bb,1)) + sqrt(m/n)*(coefs - kronecker(matrix(param,1),matrix(1,Bb,1)))

    CI1 = apply(coefs_,2,quantile,c(0.025,0.975))
    
    CI2 = apply(coefs_[1:200,],2,quantile,c(0.025,0.975))

    CI3 = apply(coefs_rNR[50:B,],2,get_CI,adj = sqrt(m/n)/sqrt(learn^2/( 1-(1-learn)^2 )))

    CI4 = apply(coefs_rqN[50:B,],2,get_CI,adj = sqrt(m/n)/sqrt(learn^2/( 1-(1-learn)^2 )))

    # store estimates
    estimates[i,,1] = est1$par
    estimates[i,,2] = apply(coefs_rNR[50:B,],2,mean)
    estimates[i,,3] = apply(coefs_rqN[50:B,],2,mean)

    reject[i,,1] = 1*(apply(CIs - true2,2,prod)>0)
    reject[i,,2] = 1*(apply(CI1 - true2,2,prod)>0)
    reject[i,,3] = 1*(apply(CI2 - true2,2,prod)>0)
    reject[i,,4] = 1*(apply(CI3 - true2,2,prod)>0)
    reject[i,,5] = 1*(apply(CI4 - true2,2,prod)>0)

    print(i) # iteration number
    save.image(file) # save results

}




