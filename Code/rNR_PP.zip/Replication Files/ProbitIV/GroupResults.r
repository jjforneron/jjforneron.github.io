# Collect the Probit IV results

library(abind)

setwd('/home/jj/BUcluster/rNR/ProbitIV')

ms = c(500,100,50)

out = c()

for (jj in 1:length(ms)) {
    m = ms[jj]
    files = list.files(pattern = paste("ProbitIV",m,'_',sep=""), full.names = TRUE)

    reject_ = c()
    estimates_ = c()

    for (i in files) {
        load(i)
        reject_ = abind(reject_,reject[1:i,,],along=1)
        estimates_ = abind(estimates_,estimates[1:i,,],along=1)
    }

    apply(reject_[,4,],2,mean)
    apply(reject_[,6,],2,mean)
    print(dim(reject_))

    out = rbind(out,c( apply(estimates_[,4,],2,mean),apply(estimates_[,4,],2,sd),apply(reject_[,4,],2,mean) ))
}


library(xtable)

rownames(out) = ms

xtable(out[,c(1:8,10,11)],digits=3)