.libPaths('/usr2/faculty/jjmf/Rpackages') # !!! adjust to match personal environment !!!

library(BLPestimatoR)
library(pracma)

# the following code is adapted from the BLPestimatoR vignette to do bootstrap inference
# and rNR, rqN. See https://cran.r-project.org/web/packages/BLPestimatoR/vignettes/blp_intro.html
# for more details on the package and the example.

set.seed(123) # set the seed
setwd('/usr2/faculty/jjmf/rNR/CleanCodes/BLP') # !!! adjust to match personal environment !!!

nevos_model <- as.formula("share ~  price + productdummy |
    0+ productdummy |
    price + sugar + mushy |
    0+ IV1 + IV2 + IV3 + IV4 + IV5 + IV6 + IV7 + IV8 + IV9 + IV10 + 
    IV11 + IV12 + IV13 + IV14 + IV15 + IV16 + IV17 + IV18 + IV19 + IV20")

# include orig. draws in the product data
productData_cereal$startingGuessesDelta <- c(log(w_guesses_cereal)) 

# renaming constants:
names(originalDraws_cereal)[1] <- "(Intercept)"

# set-up the data for estimation
cereal_data <- BLP_data(
  model = nevos_model,
  market_identifier = "cdid",
  par_delta = "startingGuessesDelta",
  product_identifier = "product_id",
  productData = productData_cereal,
  demographic_draws = demographicData_cereal,
  blp_inner_tol = 1e-12, blp_inner_maxit = 10000,
  integration_draws = originalDraws_cereal,
  integration_weights = rep(1 / 20, 20)
)


# Initial guess for the non-linear coefficients:
theta_guesses_cereal

# We focus on a specific set of coefficients
theta_guesses_cereal[2,3] = NA
theta_guesses_cereal[2,5] = NA
theta_guesses_cereal[,4] = NA


theta_guesses_cereal[theta_guesses_cereal == 0] <- NA
colnames(theta_guesses_cereal) <- c("unobs_sd", "income", "incomesq", "age", "child")
rownames(theta_guesses_cereal) <- c("(Intercept)", "price", "sugar", "mushy")

# correctly named:
theta_guesses_cereal

# BLP estimation
cereal_est <- estimateBLP(
  blp_data = cereal_data,
  par_theta2 = theta_guesses_cereal,
  solver_method = "BFGS", solver_maxit = 5000, solver_reltol = 1e-6,
  standardError = "heteroskedastic",
  extremumCheck = FALSE,
  printLevel = 1
)

# Print results
summary(cereal_est)

gmm <- gmm_obj_wrap(
  blp_data = cereal_data,
  par_theta2 = theta_guesses_cereal,
  printLevel = 0
)

theta_mat = theta_guesses_cereal
loc = which(!is.na(theta_guesses_cereal))
theta2 = cereal_est$theta_rc
theta_mat[loc] = theta2

theta0 = theta_guesses_cereal[loc] # initial value for optimizers

times <- matrix(0,2,4) # store computation times

# ***************************************** 
# *************** Bootstrap *************** 
# ***************************************** 

set.seed(123)
B = 2000 # number of bootstrap draws

# matrix to store bootstrap draws
coefs = matrix(0,B,length(theta2))

# get market identifiers to re-sample at the market level
mkts = unique(cereal_data$parameters$market_id_char_in)
cereal_data_ = cereal_data

times[1,1] <- proc.time()[3]

for (b in 1:B) {
    m = 94
    markets = sample(1:m,m,replace=TRUE) # sample market ids with replacement
    
    # re-sample the data
    inds = c()
    for (j in 1:m) {
        inds = c(inds,which(cereal_data$parameters$market_id_char_in==mkts[markets[j]]))
    }
    cereal_data_$data$X_lin  = cereal_data$data$X_lin[inds,]
    cereal_data_$data$X_exg  = cereal_data$data$X_exg[inds,]
    cereal_data_$data$X_rand = cereal_data$data$X_rand[inds,]
    cereal_data_$data$shares = cereal_data$data$shares[inds]
    cereal_data_$data$Z      = cereal_data$data$Z[inds,]
    cereal_data_$data$delta  = cereal_data$data$delta[inds]

    cereal_data_$integration$drawsRcMktShape = cereal_data$integration$drawsRcMktShape[markets,]
    cereal_data_$integration$drawsDemMktShape = cereal_data$integration$drawsDemMktShape[markets,]

    # BLP estimation on resampled data 
    coefs[b,] = cereal_est <- estimateBLP(
            blp_data = cereal_data_,
            par_theta2 = theta_mat,
            solver_method = "BFGS", solver_maxit = 5000, solver_reltol = 1e-9,
            standardError = "heteroskedastic",
            extremumCheck = FALSE,
            printLevel = 0
            )$theta_rc
    
    # Display outputs
    theta_mat_ = theta_mat
    theta_mat_[loc] = coefs[b,]
    
    gmm <- gmm_obj_wrap(
            blp_data = cereal_data_,
            par_theta2 = theta_mat_,
            printLevel = 1
    )

}

# ********************************************************
# *************** Resampled Newton-Raphson *************** 
# ********************************************************

times[2,1] <- proc.time()[3]

set.seed(123)

# matrix to store rNR draws
coefs_rNR = matrix(0,B,length(theta2))
learn = 0.2 # learning rate used in rNR

# starting value, same as for BLP estimation
coefs_rNR[1,] = theta0

# get market identifiers to re-sample at the market level
mkts = unique(cereal_data$parameters$market_id_char_in)
cereal_data_ = cereal_data

# Store objective value to monitor convergence
objs_b = rep(NA,B)
objs_b[1] = 20


# initialize
b = 1
theta_mat_ = theta_mat
theta_mat_[loc] = coefs_rNR[b,]

gmm <- gmm_obj_wrap(
        blp_data = cereal_data_,
        par_theta2 = theta_mat_,
        printLevel = 1
)


times[1,2] <- proc.time()[3]

# rNR iterations:
b = 2
while (b <= B) {
   
    m = 94
    markets = sample(1:m,m,replace=TRUE) # resample market ids with replacement
    
    # resampled data at the market level
    inds = c()
    for (j in 1:m) {
        inds = c(inds,which(cereal_data$parameters$market_id_char_in==mkts[markets[j]]))
    }
    cereal_data_$data$X_lin  = cereal_data$data$X_lin[inds,]
    cereal_data_$data$X_exg  = cereal_data$data$X_exg[inds,]
    cereal_data_$data$X_rand = cereal_data$data$X_rand[inds,]
    cereal_data_$data$shares = cereal_data$data$shares[inds]
    cereal_data_$data$Z      = cereal_data$data$Z[inds,]
    cereal_data_$data$delta  = cereal_data$data$delta[inds]

    cereal_data_$integration$drawsRcMktShape = cereal_data$integration$drawsRcMktShape[markets,]
    cereal_data_$integration$drawsDemMktShape = cereal_data$integration$drawsDemMktShape[markets,]

    # set-up the objective function with resampled data
    obj_ <- function(theta) {
        theta_mat[loc] = theta
        gmm <- gmm_obj_wrap(
            blp_data = cereal_data_,
            par_theta2 = theta_mat,
            printLevel = 1
        )
        return(gmm$local_min)
    }

    # set-up the analytical gradient with resampled data
    d_obj_ <- function(theta) {
        theta_mat[loc] = theta
        gmm <- gmm_obj_wrap(
            blp_data = cereal_data_,
            par_theta2 = theta_mat,
            printLevel = 0
        )
        return(gmm$gradient)
    }

    # compute resampled gradient, hessian
    G = d_obj_(coefs_rNR[b-1,])
    H = jacobian(d_obj_,coefs_rNR[b-1,])

    # compute update
    sk = - learn*solve(H,G)
    
    # compute the latest draw
    coefs_rNR[b,] = coefs_rNR[b-1,] + sk

    # store objective value
    objs_b[b] = obj_(coefs_rNR[b,])

    # outputs
    theta_mat_ = theta_mat
    theta_mat_[loc] = coefs_rNR[b,]
    
    gmm <- gmm_obj_wrap(
            blp_data = cereal_data_,
            par_theta2 = theta_mat_,
            printLevel = 0
        )

    print(c(objs_b[b],b),digits=2)
    print(coefs_rNR[b,],digits=2)
    print('--------')

    
    # check if everything is going well
    if ( objs_b[b] < 50*median(objs_b[1:(b-1)]) ) {
        b = b + 1 
    } else {
        b = b + 1 
        print('--------')
    }

}
times[2,2] <- proc.time()[3]

# ******************************************************
# *************** Resampled quasi-Newton *************** 
# ******************************************************

set.seed(123)
# matrix to store the rqN draws
coefs_rqNR = matrix(0,B,length(theta2))
learn = 0.2 # learning rate for rqN

# starting value, the same as for BLP estimation
coefs_rqNR[1,] = theta0

# Identity matrix
I = diag(length(theta2))

# set up market ids for resampling
mkts = unique(cereal_data$parameters$market_id_char_in)
cereal_data_ = cereal_data

# we'll store the objectives to monitor convergence
objs_b = rep(NA,B)
objs_b[1] = 20

# Initialize
b = 1

theta_mat_ = theta_mat
theta_mat_[loc] = coefs_rqNR[b,]

gmm <- gmm_obj_wrap(
        blp_data = cereal_data_,
        par_theta2 = theta_mat_,
        printLevel = 1
    )

d_obj <- function(theta) {
        theta_mat[loc] = theta
        gmm <- gmm_obj_wrap(
            blp_data = cereal_data,
            par_theta2 = theta_mat,
            printLevel = 0
        )
        return(gmm$gradient)
}

H = jacobian(d_obj,theta2)

H = diag(diag(H)) # we'll use the diagonal of the hessian as a starting value for the qN hessian approximation

# set-up the least-squares approximation of the hessian matrix
L = 20

Yb = matrix(NA,L,8)
Sb = matrix(NA,L,8)
for (j in 1:L) {
    e = rnorm(8)
    e = e/sqrt(sum(e^2))
    Sb[j,] = e
    Yb[j,] = H%*%Sb[j,]
}

H1 = t(solve(t(Sb)%*%Sb,t(Sb)%*%Yb))
HH = t(H1)%*%H1 # make the matrix symmetric positive definite

# resampled for the next iteration
m = 94
markets = sample(1:m,m,replace=TRUE)

inds = c()
for (j in 1:m) {
    inds = c(inds,which(cereal_data$parameters$market_id_char_in==mkts[markets[j]]))
}
cereal_data_$data$X_lin  = cereal_data$data$X_lin[inds,]
cereal_data_$data$X_exg  = cereal_data$data$X_exg[inds,]
cereal_data_$data$X_rand = cereal_data$data$X_rand[inds,]
cereal_data_$data$shares = cereal_data$data$shares[inds]
cereal_data_$data$Z      = cereal_data$data$Z[inds,]
cereal_data_$data$delta  = cereal_data$data$delta[inds]

cereal_data_$integration$drawsRcMktShape = cereal_data$integration$drawsRcMktShape[markets,]
cereal_data_$integration$drawsDemMktShape = cereal_data$integration$drawsDemMktShape[markets,]


times[1,3] <- proc.time()[3]

# rqN iterations:
b = 2
while (b <= B) {

    # set-up objective and analytical gradient
    obj_ <- function(theta) {
        theta_mat[loc] = theta
        gmm <- gmm_obj_wrap(
            blp_data = cereal_data_,
            par_theta2 = theta_mat,
            printLevel = 1
        )
        return(gmm$local_min)
    }

    d_obj_ <- function(theta) {
        theta_mat[loc] = theta
        gmm <- gmm_obj_wrap(
            blp_data = cereal_data_,
            par_theta2 = theta_mat,
            printLevel = 0
        )
        return(gmm$gradient)
    }
    
    # compute the resampled gradient 
    G  = d_obj_(coefs_rqNR[b-1,])

    # compute the quasi-Newton approximation of the Hessian
    # regularize the inverse if it is ill-conditionned
    # otherwise computes a matrix square-root
    ee = eigen(HH)

    if (rcond(HH)<1e-12) {
        H_ = ee$vectors%*%diag(1/sqrt(ee$values + 1e-12*max(ee$values)))%*%solve(ee$vectors)
    } else {
        H_ = ee$vectors%*%diag(1/sqrt(ee$values))%*%solve(ee$vectors)
    }

    # direction of update
    sk = - learn*H_%*%G

    # latest draw  
    coefs_rqNR[b,] = coefs_rqNR[b-1,] + sk
    
    # update the least-squares interpolation

    # update direction
    sk = sk/sqrt(sum(sk^2))*1e-8

    # re-sample data at the market level
    markets = sample(1:m,m,replace=TRUE)

    inds = c()
    for (j in 1:m) {
        inds = c(inds,which(cereal_data$parameters$market_id_char_in==mkts[markets[j]]))
    }
    cereal_data_$data$X_lin  = cereal_data$data$X_lin[inds,]
    cereal_data_$data$X_exg  = cereal_data$data$X_exg[inds,]
    cereal_data_$data$X_rand = cereal_data$data$X_rand[inds,]
    cereal_data_$data$shares = cereal_data$data$shares[inds]
    cereal_data_$data$Z      = cereal_data$data$Z[inds,]
    cereal_data_$data$delta  = cereal_data$data$delta[inds]

    cereal_data_$integration$drawsRcMktShape = cereal_data$integration$drawsRcMktShape[markets,]
    cereal_data_$integration$drawsDemMktShape = cereal_data$integration$drawsDemMktShape[markets,]

    # compute Hessian-vector product: yk = H x sk
    yk = (d_obj_(coefs_rqNR[b,]+sk) - d_obj_(coefs_rqNR[b,]-sk))/2

    # stack directions and hessian-vector products 
    Sb = rbind(Sb[-1,],c(sk)/sqrt(sum(sk^2)))

    Yb = rbind(Yb[-1,],c(yk)/sqrt(sum(sk^2)))
    H1 = solve(t(Sb)%*%Sb,t(Sb)%*%Yb) # least-squares interpolation
    HH = t(H1)%*%H1 # transform to a symmetric positive definite matrix

    while (rcond(t(Sb)%*%Sb)<1e-12) {
            print('ill-conditionned') # failsafe for singular cases 
            sk = rnorm(length(sk))
            sk = 1e-8*sk/sqrt(sum(sk^2))
            Sb = rbind(Sb[-1,],c(sk)/sqrt(sum(sk^2)))
            yk = (d_obj_(coefs_rqNR[b,]+sk) - d_obj_(coefs_rqNR[b,]-sk))/2
            Yb = rbind(Yb[-1,],c(yk)/sqrt(sum(sk^2)))
            H1 = solve(t(Sb)%*%Sb,t(Sb)%*%Yb)
            HH = t(H1)%*%H1
    }

    # store objective, outputs
    objs_b[b] = obj_(coefs_rqNR[b,])

    theta_mat_ = theta_mat
    theta_mat_[loc] = coefs_rqNR[b,]
    
    gmm <- gmm_obj_wrap(
            blp_data = cereal_data_,
            par_theta2 = theta_mat_,
            printLevel = 0
        )

    print(c(objs_b[b],b),digits=2)
    print(coefs_rqNR[b,],digits=2)
    print('--------')

    
    # check if everything is going well
    if ( objs_b[b] < 50*median(objs_b[1:(b-1)]) ) {
        b = b + 1 
    } else {
        print('skip')
        print('--------')
    }

}
times[2,3] <- proc.time()[3]

set.seed(123)

# *******************************************************
# *************** Davidson-McKinnon (dmk) *************** 
# *******************************************************

# matrix to store the DMK draws
coefs_dmk = matrix(0,B,length(theta2))


mkts = unique(cereal_data$parameters$market_id_char_in)
cereal_data_ = cereal_data
objs_b_dmk = rep(NA,B)
objs_b_dmk[1] = 20

times[1,4] <- proc.time()[3]
b = 1
while (b <= B) {
   
    m = 94
    markets = sample(1:m,m,replace=TRUE)
    
    inds = c()
    for (j in 1:m) {
        inds = c(inds,which(cereal_data$parameters$market_id_char_in==mkts[markets[j]]))
    }
    cereal_data_$data$X_lin  = cereal_data$data$X_lin[inds,]
    cereal_data_$data$X_exg  = cereal_data$data$X_exg[inds,]
    cereal_data_$data$X_rand = cereal_data$data$X_rand[inds,]
    cereal_data_$data$shares = cereal_data$data$shares[inds]
    cereal_data_$data$Z      = cereal_data$data$Z[inds,]
    cereal_data_$data$delta  = cereal_data$data$delta[inds]

    cereal_data_$integration$drawsRcMktShape = cereal_data$integration$drawsRcMktShape[markets,]
    cereal_data_$integration$drawsDemMktShape = cereal_data$integration$drawsDemMktShape[markets,]


    obj_ <- function(theta) {
        theta_mat[loc] = theta
        gmm <- gmm_obj_wrap(
            blp_data = cereal_data_,
            par_theta2 = theta_mat,
            printLevel = 0
        )
        return(gmm$local_min)
    }

    d_obj_ <- function(theta) {
        theta_mat[loc] = theta
        gmm <- gmm_obj_wrap(
            blp_data = cereal_data_,
            par_theta2 = theta_mat,
            printLevel = 0
        )
        return(gmm$gradient)
    }
    G = d_obj_(theta2)
    H = jacobian(d_obj_,theta2)
    sk = - solve(H,G)
        
    coefs_dmk[b,] = theta2 + sk

    objs_b_dmk[b] = obj_(coefs_dmk[b,])

    print(c(objs_b_dmk[b],b),digits=2)
    print(coefs_dmk[b,],digits=2)
    print('--------')

}

times[2,4] <- proc.time()[3]

# stack results into exportable format

results_mean = 
cbind(theta2,
      apply(coefs,2,mean),
      apply(coefs_dmk,2,mean),
      apply(coefs_rNR[10:B,],2,mean),
      apply(coefs_rqNR[10:B,],2,mean))

rownames(results_mean) = names(theta2)
colnames(results_mean) = c('Estimate','Bootstrap','Davidson McKinnon','rNR','rqN')


results_sd  = 
cbind(apply(coefs,2,sd),
      apply(coefs_dmk,2,sd),
      apply(coefs_rNR[10:B,],2,sd)*sqrt( (1-(1-learn)^2)/learn^2 ), 
      apply(coefs_rqNR[10:B,],2,sd)*sqrt( (1-(1-learn)^2)/learn^2))

rownames(results_sd) = names(theta2)
colnames(results_sd) = c('Bootstrap','Davidson McKinnon','rNR','rqN')

print(round(results_mean,3),digits=2)
print(round(results_sd,3),digits=2)

colnames(times) = c('Bootstrap','rNR','rqN','Davidson McKinnon')
print( round(  apply(times,2,diff)/3600 ,2),digits=2 )

save.image('BLP_Results.RData')