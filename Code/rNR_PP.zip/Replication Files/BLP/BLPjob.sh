#!/bin/bash -l 
module load R
module load gcc
module load intel
#$ -l h_rt=160:00:00 
#$ -pe omp 4

echo "=========================================================="
echo "Starting on: $(date)"
echo "Running on)node: $(hostname)"
echo "Current directory: $(pwd)"
echo "Current job ID: $JOB_ID"
echo "Current job name: $JOB_NAME"
echo "Task index number: $SGE_TASK_ID"
echo "=========================================================="


cd /usr2/faculty/jjmf/rNR/CleanCodes/BLP
Rscript /usr2/faculty/jjmf/rNR/CleanCodes/BLP/BLP_Results.R > /usr2/faculty/jjmf/rNR/CleanCodes/BLP/Output/BLP_Results.out
