// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include <iostream>
#include <math.h>

using namespace Rcpp;
using namespace arma;
using namespace std;

// [[Rcpp::export]]
mat sim_panel(colvec params, mat e, mat x) {
    // Simulate a panel with params = ( rho, beta, sigma )
    // y_{it} = rho * y_{it-1} + beta * x_{it} +  sigma * e_{it}
    
    int n = x.n_cols; // cross-sectional dimension
    int T = x.n_rows; // time dimension

    // coefficients rho, beta, log(sigma)
    double rho   = params(0); 
    double beta  = params(1);
    double sigma = exp(params(2)); // transform log(sigma) to sigma

    mat y(T,n);// initialize the matrix y

    // initial value: y_{i1} = x_{i1} * beta + sigma/(1-rho^2) * e_{i1} 
    y.row(0) = sigma*e.row(0)/( 1-pow(rho,2) ) + beta*x.row(0); 

    for (int t=1; t<= T-1; t++) { 
        // for t = 2, ..., T do
        // y_{it} = rho * y_{it-1} + beta * x_{it} +  sigma * e_{it}
        y.row(t) = rho*y.row(t-1) + beta*x.row(t) + sigma*e.row(t);

    }

    return y; // return the matrix y

} 

// [[Rcpp::export]]
vec LSDV(mat y, mat x) {
    // Compute the least-squares dummy variable estimate theta = (rho, beta, sigma)
    // for the linear dynamic panel:
    // y_{it} = rho * y_{it-1} + beta * x_{it} +  sigma * e_{it}

    // the inputs y and x have dimension n * T 

    int n = y.n_cols; // cross-sectional dimension
    int T = y.n_rows; // time dimension

    mat one(T,1); one.ones(); // vector one = (1,...,1)
    mat A(T,T); A.eye();      // identity matrix A = Id
    A = A - one*one.t()/T;    // A = Id - (1,...,1)' (1,...,1)
    mat xd = A*x;             // de-mean the xs
    mat yd = A*y;             // de-mean the ys

    mat y0 = yd.rows(1,T-1);  // compute y0, y1: de-meaned y and its lag, vectorize 
    colvec y0_ = vectorise(y0);
    mat y1 = yd.rows(0,T-2);
    colvec y1_ = vectorise(y1);

    mat x0 = xd.rows(1,T-1); // compute x0: de-meaned x, vectorize
    colvec x0_ = vectorise(x0);

    mat Xmat = join_rows(y1_, x0_); // matrix of regressors: de-meaned x and lagged de-meaned y

    vec coef = solve( Xmat.t()*Xmat, Xmat.t()*y0_ ); // OLS estimates
    vec res  = y0_-Xmat*coef; // residuals

    coef.resize( coef.n_elem + 1 ); 
    coef(coef.n_elem-1) = stddev(res); // standard deviation of the residuals

    return coef;

}