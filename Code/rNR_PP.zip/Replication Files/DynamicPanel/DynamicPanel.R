set.seed(666) # set the seed

library(pracma) # to compute numerical derivatives
library(xtable) # output in latex format

setwd('/home/jj/Dropbox/jjng/Replication Files/DynamicPanel') # set to local environment

# the functions for simulating the dynamic panel and 
# estimating using LSDV are in a DynamicPanel package 
# to be installed locally (R version 4.0.3, compiled in linux)
# to install, run the following:

# install.packages('DynamicPanel_1.0.tar.gz',lib='Pack') 
# don't forget to set lib to local environment
# lib='Pack' points to the folder where the package will be installed.

# load Dynamic Panel functions
library(DynamicPanel,lib = 'Pack') # set lib to local environment

# the package loads the following functions:
#   sim_panel: simulates a dynamic panel model using params = theta, shocks e and covariates x
#   LSDV: computes the LSDV estimates for theta = (rho,beta) in the dynamic panel model

# ************************************************
# Alternatively, the source code can be compiled 
# locally using the appropriate toolchain and
# Rcpp, RcppArmadillo with the commands:
#
# library(Rcpp)
# library(RcppArmadillo)
# sourceCpp('DynPan.cpp')
# ************************************************

options(digits=3)

n = 500 # cross-sectional dimension
T = 5   # time dimension

reps  = 1000 # number of MC replications
B     = 2000 # number of rNR, rqN draws
Bb    = 500  # number of Bootstrap draws

S  = 1   # number of simulated samples
m1 = n   # resampling size m = n
m2 = 100 # resampling size m < n

learn = 0.1 # learning rate for rNR, rqN

b1 = 1 + round(log(0.01)/log(1-learn)) # a rule of thumb to pick the burn-in sample

adj_rnr1 = sqrt(m1/n)*sqrt( (1-(1-learn)^2)/learn^2 ) # adjustment: sqrt( m/(n x phi(gamma)) )
adj_rnr2 = sqrt(m2/n)*sqrt( (1-(1-learn)^2)/learn^2 ) # adjustment: sqrt( m/(n x phi(gamma)) )

adj_oth = sqrt(m2/n) # adjustment for the Bootstrap with m < n

b0  = c(0.6,1,1) # true value of theta = (0.6,1,1) = (rho,beta,sigma)
b0_ = b0; b0_[3] = log(b0[3]) # reparametrize to solve in terms of log(sigma)

init = c(0.0,0,1) # initial value = (0,0,1)
init_ = init; init_[3] = log(init[3])  # initial value = (0,0,0) after reparameterization

print(paste('Dynamic Panel: n = ',n,', T = ',T,', S = ',S,sep='')) # output file

obj_II <- function(bet, e_s, x, S, mom) { # binds the C++ code into an objective function
    # bet = ( rho,beta,log(sigma) )
    # e_s = simulated shocks ~ N(0,1)
    # x   = covariates
    # S   = number of simulated samples
    # mom = sample moments  
    x_s  = kronecker(x,matrix(1,1,S)) # makes S copies of x
    # simulate S panels using theta, x, e_s; compute simulated moments:
    mom_s = LSDV( sim_panel(bet, e_s, x_s), x_s) 
    return( sum( (mom-mom_s)^2 ) )  # || sample - simulated moments ||^2
}

mom_II <- function(bet, e_s, x, S, mom) { # binds the C++ code, returns a vector of simulated moments
    # bet = ( rho,beta,log(sigma) )
    # e_s = simulated shocks ~ N(0,1)
    # x   = covariates
    # S   = number of simulated samples
    # mom = sample moments
    x_s  = kronecker(x,matrix(1,1,S)) # makes S copies of x
    # simulate S panels using theta, x, e_s; compute simulated moments:
    mom_s = LSDV( sim_panel(bet, e_s, x_s), x_s)

    return( mom_s )   # simulated moments
}

# ***********************************************
# ****************** Bootstrap ******************
# ***********************************************

bootstrap <- function( init, B = 1000, m = n, S, y, x, mom ) {
    # init = starting value, should be set to full sample estimates
    # B = number of bootstrap draws
    # m = resampling size
    # S = number of simulated samples
    # y = outcome, x = covariates, mom = sample moments
    Draws = matrix( 0,B,3 ) # matrix to store B draws

    for (b in 1:B) {
        # resample with replacement on the cross-sectional dimension
        ind = sample(1:n,m,replace = TRUE) 
        e_s = matrix( rnorm( m*S*T ), T, m*S ) # simulate new shocks
        mom_b = LSDV( y[,ind], x[,ind]) # compute resampled moments

        opt_b = optim(init, obj_II, method = 'BFGS', 
            e_s = e_s, x = x[,ind], S = S, mom = mom_b, 
            control = list(abstol = 1e-6,maxit = 5000)) # estimate using BFGS

        Draws[b,] = opt_b$par # store estimates

    }

    Draws[,3] = exp(Draws[,3]) # transform from log(sigma) to sigma
    return(Draws)

}

# **************************************************************
# ****************** Resampled Newton-Raphson ******************
# **************************************************************

rnr <- function( init, learn = 0.1, B = 1000, m = n, S, y, x, mom ) {
    # init = starting value, can be set to any value
    # B = number of bootstrap draws
    # m = resampling size
    # S = number of simulated samples
    # y = outcome, x = covariates, mom = sample moments

    Draws1 = matrix( 0,B,3 ) # first chain, used for estimation
    Draws2 = matrix( 0,B,3 ) # second chain, used for inference

    Draws1[1,] = init # initialize
    Draws2[1,] = init # initialize

    for (b in 2:B) { # rNR iterations

        # resample with replacement on the cross-sectional dimension
        ind1 = sample(1:n,m,replace = TRUE) 
        # simulate shocks e_s ~ N(0,1)
        e_s = matrix( rnorm( m*S*T ), T, m*S )
        # compute resampled simulated moments
        mom_b1 = LSDV( y[,ind1], x[,ind1])

        # bind the moment function with the resampled data and simulation draws above
        momb <- function(par) { return(mom_II(par,e_s,x[,ind1],S,mom_b1)) }
        # simulated moments
        mom_s =  momb(Draws1[b-1,])
        # jacobian of simulated moments
        G1 = jacobian(momb,Draws1[b-1,])
        
        # we can then compute the gradient of the objective as: G = t(G1)%*%(mom_s - mom_b1)
        # and the hessian can be approximated by: H = t(G1)%*%G1

        # iterate the first chain
        Draws1[b,] = Draws1[b-1,] - learn*solve(t(G1)%*%G1,t(G1)%*%(mom_s - mom_b1) )
        # iterate the second chain, no additional computation required
        Draws2[b,] = (1-learn)*Draws2[b-1,] - learn*solve(t(G1)%*%G1,t(G1)%*%(mom-mom_b1) )

    }

    Draws1[,3] = exp(Draws1[,3]) # transform from log(sigma) to sigma
    Draws2[,3] = exp(Draws2[,3]) # transform from log(sigma) to sigma
    return( list( Draws1 = Draws1, Draws2 = Draws2 ) ) # return both chains

}

# ************************************************************
# ****************** Resampled quasi-Newton ******************
# ************************************************************

rqn <- function( init, learn = 0.1, B = 1000, m = n, S, y, x, mom ) {
    # init = starting value, can be set to any value
    # B = number of bootstrap draws
    # m = resampling size
    # S = number of simulated samples
    # y = outcome, x = covariates, mom = sample moments

    Draws1 = matrix( 0,B,3 ) # first chain, used for estimation
    Draws2 = matrix( 0,B,3 ) # second chain, used for inference

    Draws1[1,] = init # initialize
    Draws2[1,] = init # initialize

    # Initialize the quasi-Newton approximation of the Hessian
    L = 20

    # simulation draws
    e_s = matrix( rnorm( n*S*T ), T, n*S )
    # bind the moment function with the simulation draws above
    momb <- function(par) { return(mom_II(par,e_s,x,S,mom)) }
    G1  = jacobian( momb, init) # initialize jacobian of simulated moments, can use other matrices

    Yb = matrix(0,L,3) # Jacobian-vector products
    Sb = matrix(0,L,3) # directions

    for (i in 1:L) {   # initialize Sb using random draws and Yb using Yb = G1 x Sb

        ee = rnorm(3)
        ee = ee/sqrt(sum(ee^2))
        Sb[i,] = ee
        Yb[i,] = G1%*%ee

    }

    G1_ = t(Yb)%*%Sb%*%solve(t(Sb)%*%Sb) # compute LS approximation, should be equal to G1

    # resample with replacement on the cross-sectional dimension
    ind1 = sample(1:n,m,replace = TRUE) 
    # simulate shocks e_s ~ N(0,1)
    e_s = matrix( rnorm( m*S*T ), T, m*S )

    # resampled simulated moments
    mom_b1 = LSDV( y[,ind1], x[,ind1])
    # bind the moment function with the simulation draws above
    momb <- function(par) { return(mom_II(par,e_s,x[,ind1],S,mom_b1)) }
    # resampled simulated moments
    mom_s =  momb(init)

    for (b in 2:B) { # rqN iterations

        # we compute the gradient of the objective as: G = t(G1_)%*%(mom_s - mom_b1)
        # and the hessian can be approximated by: H = t(G1_)%*%G1_
        # where G1_ is the quasi-Newton approximation of the jacobian of the sample moments

        # update the first chain
        Draws1[b,] = Draws1[b-1,] - learn*solve(t(G1_)%*%G1_,t(G1_)%*%(mom_s - mom_b1) )
        # update the second chain
        Draws2[b,] = (1-learn)*Draws2[b-1,] - learn*solve(t(G1_)%*%G1_,t(G1_)%*%(mom-mom_b1) )

        ee = Draws1[b,] - Draws1[b-1,] # update direction
        ee = ee/sqrt(sum(ee^2))        # normalize
        Sb = rbind(Sb[-1,],ee)         # stack with previous directions

        # resample with replacement on the cross-sectional dimension
        ind1 = sample(1:n,m,replace = TRUE)
        # simulate shocks e_s ~ N(0,1)
        e_s = matrix( rnorm( m*S*T ), T, m*S )
        # resampled simulated moments
        mom_b1 = LSDV( y[,ind1], x[,ind1])
        # bind the moment function with the simulation draws above
        momb <- function(par) { return(mom_II(par,e_s,x[,ind1],S,mom_b1)) }
        # resampled simulated moments
        mom_s =  momb(Draws1[b,])
        
        # Jacobian-vector product: yy = G1 x ee, G1 is the jacobian of the moments
        yy = c(momb(Draws1[b,] + ee*1e-12) - momb(Draws1[b,] - ee*1e-12))/(2*1e-12)
        Yb = rbind(Yb[-1,],yy) # stack with previous Jacobian-vector products

        # Least-Squares approximation
        G1_ = t(Yb)%*%Sb%*%solve(t(Sb)%*%Sb)

    }

    Draws1[,3] = exp(Draws1[,3]) # transform from log(sigma) to sigma
    Draws2[,3] = exp(Draws2[,3]) # transform from log(sigma) to sigma
    return( list( Draws1 = Draws1, Draws2 = Draws2 ) )

}

reject_b0 = matrix(0,reps,7) # coverage for rho
reject_b1 = matrix(0,reps,7) # coverage for bet
reject_b2 = matrix(0,reps,7) # coverage for sigma

estimates =array(NA,dim=c(reps,3,5)) # estimates

estimates_lsdv =matrix(NA,reps,3) # LSDV estimates

for (j in 1:reps) { # MC replications

    e = matrix( rnorm(n*T), T, n ) # simulate shocks
    x = matrix( rnorm(n*T), T, n ) # simulate covariates
    y = sim_panel(b0_, e, x)       # simulate dynamic panel

    mom = LSDV( y, x) # compute sample moments
    e_s = matrix( rnorm( n*S*T ), T, n*S ) # simulation draws for indirect inference

    estimates_lsdv[j,] = mom # store the LSDV estimates

    opt = optim(init_, obj_II, method = 'BFGS', 
            e_s = e_s, x = x, S = S, mom = mom, 
            control = list(abstol = 1e-6,maxit = 5000)) # indirect inference estimation

    est = opt$par # store the indirect inference estimates 
    est_ = est
    est_[3] = exp(est_[3])

    estimates[j,,1] = est_

    # compute standard errors for the LSDV estimates using the sandwich formula
    # we need to compute them to get the sandwich for the indirect inference estimates
    A = diag(T)-matrix(1,T,1)%*%matrix(1,1,T)/T

    y_ = A%*%y # de-mean y and x
    x_ = A%*%x

    y_0 = y_[2:T,] # lags
    y_1 = y_[1:(T-1),]
    x_0 = x_[2:T,]

    X = array(1, dim=c(T-1,n,2)) # stack in matrix form
    X[,,1] = y_1
    X[,,2] = x_0

    e = y_0 - y_1*mom[1] - x_0*mom[2] # residuals

    S1 = matrix(0,2,2) # different components of the meat (sandwich)
    S2 = matrix(0,2,1)
    S3 = matrix(0,2,2)

    S4 = 0
    S5 = 0
    S6 = matrix(0,2,1)

    e_ = e-mean(e)

    for (i in 1:n) { # HC-robust meat estimate, allows for correlation over t

        vi = t(X[,i,])%*%e[,i]

        S1 = S1 + vi%*%t(vi)/n
        S2 = S2 + vi/n
        S3 = S3 + t(X[,i,])%*%X[,i,]/n

        S4 = S4 + ((e_[,i])%*%e_[,i]/(T-1))/n
        S5 = S5 + ((e_[,i])%*%e_[,i]/(T-1))^2/n

        S6 = S6 + as.numeric((e_[,i])%*%e_[,i]/(T-1))*t(X[,i,])%*%e[,i]/n

    }

    VV = matrix(0,3,3) # Stack all the components into the meat

    VV[1:2,1:2] =  S1-S2%*%t(S2)
    VV[3,3]     =  (S5-S4^2)
    VV[1:2,3]   =  S6 - as.numeric(S4)*S2

    G1 = matrix(0,3,3) # compute the bread for the LSDV estimates
    G1[1:2,1:2] = solve(S3)
    G1[3,3] = 1/(2*sqrt(mom[3]))

    VV = G1%*%VV%*%t(G1)*(1+1/S) # sandwich for the LSDV estimates
    # we can now compute the sandwich for indirect inference

    # simulated moments and their jacobian (bread for indirect inference)
    moms <- function(par) {return(mom_II(par,e_s,x,S,mom))}
    G = jacobian(moms,est)

    ase = sqrt(diag( solve(G,VV)%*%solve(t(G)) )/n) # Sandwich for indirect inference

    Bootm1 = bootstrap( est, Bb, m1, S, y, x, mom ) # Bootstrap with m = n
    Bootm2 = bootstrap( est, Bb, m2, S, y, x, mom ) # Bootstrap with m < n

    Bootm2 = (Bootm2-kronecker(matrix(est_,1,3),matrix(1,Bb,1)))*adj_oth + kronecker(matrix(est_,1,3),matrix(1,Bb,1)) # adjustment for the Bootstrap with m < n

    rnr1 =  rnr( init_, learn, b1 + B, m1, S, y, x, mom ) # rNR with m = n
    rnr2 =  rnr( init_, learn, b1 + B, m2, S, y, x, mom ) # rNR with m < n

    rnr1$Draws1 = rnr1$Draws1[(b1+1):(B+b1),] # discard burn-in
    rnr2$Draws1 = rnr2$Draws1[(b1+1):(B+b1),] # discard burn-in

    rnr1$Draws2 = rnr1$Draws2[(b1+1):(B+b1),] # discard burn-in 
    rnr2$Draws2 = rnr2$Draws2[(b1+1):(B+b1),] # discard burn-in

    est_rnr1 = apply( rnr1$Draws1, 2, mean ) # rNR estimates m = n
    est_rnr2 = apply( rnr2$Draws1, 2, mean ) # rNR estimates m < n

    estimates[j,,2] = est_rnr1 # store estimates
    estimates[j,,3] = est_rnr2

    rqn1 =  rqn( init_, learn, b1 + B, m1, S, y, x, mom ) # rqN with m = n
    rqn2 =  rqn( init_, learn, b1 + B, m2, S, y, x, mom ) # rqN with m < n

    rqn1$Draws1 = rqn1$Draws1[(b1+1):(B+b1),] # discard burn-in
    rqn2$Draws1 = rqn2$Draws1[(b1+1):(B+b1),] # discard burn-in

    rqn1$Draws2 = rqn1$Draws2[(b1+1):(B+b1),] # discard burn-in
    rqn2$Draws2 = rqn2$Draws2[(b1+1):(B+b1),] # discard burn-in

    est_rqn1 = apply( rqn1$Draws1, 2, mean ) # rqN estimates m = n
    est_rqn2 = apply( rqn2$Draws1, 2, mean ) # rqN estimates m = n

    estimates[j,,4] = est_rqn1 # store estimates
    estimates[j,,5] = est_rqn2

    print(rbind(est_,est_rnr1,est_rnr2,est_rqn1,est_rqn2)) # print all the estimates

    se_boot_m1 = apply( Bootm1, 2, sd) # Bootstrap standard errors m = n
    se_boot_m2 = apply( Bootm2, 2, sd) # Bootstrap standard errors m < n

    se_rnrm1 = apply(  adj_rnr1*(rnr1$Draws2) , 2, sd) # rNR standard errors m = n
    se_rnrm2 = apply(  adj_rnr2*(rnr2$Draws2) , 2, sd) # rNR standard errors m < n

    se_rqnm1 = apply(  adj_rnr1*(rqn1$Draws2) , 2, sd) # rqN standard errors m = n 
    se_rqnm2 = apply(  adj_rnr2*(rqn2$Draws2) , 2, sd) # rqN standard errors m < n

    print(rbind(se_boot_m1,se_rnrm1,se_boot_m2,se_rnrm2,se_rqnm1,se_rqnm2)) # print all the standard errors

    q_Bootm1 = apply( Bootm1, 2, quantile, c(0.025,0.975) ) # Bootstrap confidence interval, m = n
    q_Bootm2 = apply( Bootm2, 2, quantile, c(0.025,0.975) ) # Bootstrap confidence interval, m < n

    # rNR confidence interval, m = n
    q_rnrm1 = adj_rnr1*apply( rnr1$Draws2 -  kronecker(matrix(apply(rnr1$Draws2,2,mean),1,3),matrix(1,B,1)) , 2, quantile, c(0.025,0.975) ) + kronecker(matrix(est_rnr1,1,3),matrix(1,2,1)) 

    # rNR confidence interval, m < n
    q_rnrm2 = adj_rnr2*apply( rnr2$Draws2 -  kronecker(matrix(apply(rnr2$Draws2,2,mean),1,3),matrix(1,B,1)) , 2, quantile, c(0.025,0.975) ) + kronecker(matrix(est_rnr2,1,3),matrix(1,2,1))

    # rqN confidence interval, m = n
    q_rqnm1 = adj_rnr1*apply( rqn1$Draws2 -  kronecker(matrix(apply(rqn1$Draws2,2,mean),1,3),matrix(1,B,1)) , 2, quantile, c(0.025,0.975) ) + kronecker(matrix(est_rqn1,1,3),matrix(1,2,1))

    # rqN confidence interval, m < n
    q_rqnm2 = adj_rnr2*apply( rqn2$Draws2 -  kronecker(matrix(apply(rqn2$Draws2,2,mean),1,3),matrix(1,B,1)) , 2, quantile, c(0.025,0.975) ) + kronecker(matrix(est_rqn2,1,3),matrix(1,2,1))
    

    # ************************************************************
    # ******* Compute rejection rates by checking if the   *******
    # ******* coefficients are in the confidence intervals *******
    # ************************************************************

    # 1 = ASE, 2 = Bootstrap (m=n), 3 = Bootstrap (m<n),
    # 4 = rNR (m=n), 5 = rNR (m<n), 6 = rqN (m=n), 7 = rqN (m<n) 

    # rho

    reject_b0[j,1] = 1*( abs( est_[1] - b0[1] )/ase[1] > 1.96 )
    reject_b0[j,2] = 1*( prod(q_Bootm1[,1] - mean(Bootm1[,1]) + est_[1]  -b0[1]) >0 )
    reject_b0[j,3] = 1*( prod(q_Bootm2[,1] - mean(Bootm2[,1]) + est_[1] -b0[1]) >0 )
    
    reject_b0[j,4] = 1*( prod(q_rnrm1[,1]-b0[1]) >0 )
    reject_b0[j,5] = 1*( prod(q_rnrm2[,1]-b0[1]) >0 )

    reject_b0[j,6] = 1*( prod(q_rqnm1[,1]-b0[1]) >0 )
    reject_b0[j,7] = 1*( prod(q_rqnm2[,1]-b0[1]) >0 )

    # beta

    reject_b1[j,1] = 1*( abs( est_[2] - b0[2] )/ase[2] > 1.96 )
    reject_b1[j,2] = 1*( prod(q_Bootm1[,2] - mean(Bootm1[,2]) + est_[2] -b0[2]) >0 )
    reject_b1[j,3] = 1*( prod(q_Bootm2[,2] - mean(Bootm2[,2]) + est_[2] -b0[2]) >0 )

    reject_b1[j,4] = 1*( prod(q_rnrm1[,2]-b0[2]) >0 )
    reject_b1[j,5] = 1*( prod(q_rnrm2[,2]-b0[2]) >0 )

    reject_b1[j,6] = 1*( prod(q_rqnm1[,2]-b0[2]) >0 )
    reject_b1[j,7] = 1*( prod(q_rqnm2[,2]-b0[2]) >0 )

    # sigma

    reject_b2[j,1] = 1*( abs( est_[3] - b0[3] )/ase[3] > 1.96 )
    reject_b2[j,2] = 1*( prod(q_Bootm1[,3] - mean(Bootm1[,3]) + est_[3] -b0[3]) >0 )
    reject_b2[j,3] = 1*( prod(q_Bootm2[,3] - mean(Bootm2[,3]) + est_[3] -b0[3]) >0 )

    reject_b2[j,4] = 1*( prod(q_rnrm1[,3]-b0[3]) >0 )
    reject_b2[j,5] = 1*( prod(q_rnrm2[,3]-b0[3]) >0 )

    reject_b2[j,6] = 1*( prod(q_rqnm1[,3]-b0[3]) >0 )
    reject_b2[j,7] = 1*( prod(q_rqnm2[,3]-b0[3]) >0 )

    print(j) # print some output to see what's going on 
    if (j > 1) {
        print(apply(reject_b0[1:j,],2,mean),digits=3)
        print(apply(reject_b1[1:j,],2,mean),digits=3)
        print(apply(reject_b2[1:j,],2,mean),digits=3)
        print(j)
    }

}

# stack the output into a labeled table, export in latex format 
out = rbind(
    c(apply(estimates[,1,c(1,2,4)],2,mean),apply(estimates[,1,c(1,2,4)],2,sd),apply(reject_b0[,c(1,2,4,6)],2,mean)), 
    c(apply(estimates[,1,c(1,3,5)],2,mean),apply(estimates[,1,c(1,3,5)],2,sd),apply(reject_b0[,c(1,3,5,7)],2,mean)))

colnames(out) = c('II','rNR','rqN','II','rNR','rqN','ase','boot','rnr','rqn')
rownames(out) = c('500','100')


xtable(out,digits=3)

save.image(file=paste('DynPan_',S,'.RData',sep="")) # save the results