#Compute the posterior from an exponential distribution yi ~ E(theta)
#The true theta=1/2
#The moments hat psi are mean(y), a sufficient statistic and var(y)
#If we condition only on mean(y) we get the true posterior which is Gamma(N+1,1/(N mean(y)))
#Since the prior for accept-reject is U[0,inf] (not proper)
#If we only condition on the second moment var(y), we don't get the true posterior
#By putting  W(2,2) ne 0, we allow  the second moment to affect the  solution of the optimisation problem.
#But so long as W(1,1) ne 0,   we still get the true posterior (known analytically in this case)
#This shows that using the volume and the kernel as weights we get the true posterior from the reverse sampler

#Libraries used for matrices, optimization and plots
import numpy as np
import scipy as sp
#import pylab # does not appear to exist for Python 2.7 anymore
from scipy.optimize import minimize_scalar
from scipy.optimize import minimize
from copy import copy
#from ggplot import *
import pandas

#set the seed
sp.random.seed(123)

#Sample of 5 observations
N=5;
theta=0.5;

y=-np.log(1-np.random.uniform(0,1,N))/theta; #Generate data
#Compute moments, weight matrix
mom=np.array([np.mean(y),np.var(y)]);
W=np.diag([1,4]);

#Wrappers for output of the samplers
class RS_JI(object):
    def __init__(self,draws,weights):
        self.draws=draws;
        self.weights=weights;

class RS_OI(object):
    def __init__(self,draws,weights,dists):
        self.draws=draws;
        self.weights=weights;
        self.dists=dists;

class AR(object):
    def __init__(self,draws,dists):
        self.draws=draws;
        self.dists=dists;

def JID(B,mom): #Just-Identified Reverse Sampler
    #Matrix for draws, weights
    draws=np.zeros(B);
    weights=np.zeros(B);
    for b in range(0,int(B)):
        u=np.random.uniform(0,1,N);
        #Generate the uniform draws from which we compute the exponentials (set the seed, then solve)
        #Objective function: for given theta compute yb ~ E(theta) and mean(yb)
        #return the distance between the
        #mean of yb and the data mean(y)

        #Function that computes moments for given value of theta
        #Used to compute arg-minimizer and jacobian
        def moment(theta):
            yb=-np.log(1-u)/theta;
            return np.mean(yb);
        #Set the b-th draw equal to the arg-min of the distance
        #Using the optimize (one dimensional) function with bounds [0,10].
        def obj(theta):
            momb=moment(theta);
            return pow(momb-mom,2);
        #Solve the minimization problem
        draws[b]=minimize_scalar(obj,bounds=(0., 10.), method='bounded').x;
        #Compute the Jacobian using finite differences method
        eps=1e-4;
        Jm=(moment(draws[b]+eps)-moment(draws[b]-eps))/(2*eps)
        #Store weights as the inverse of absolute value of the determinant of the Jacobian
        weights[b]=1/abs(Jm);
    #Return the list of draws and weights using the wrapper
    return RS_JI(draws,weights);

def OID(B,mom,q): #Over-Identified Reverse Sample
    #Matrix of draws, weights, distances
    draws  =np.zeros(int(B/q));
    weights=np.zeros(int(B/q));
    dists  =np.zeros(int(B/q));
    for b in range(0,int(B/q)):
        #Generate the uniform draws to compute the exponential draws, similar to fixing the seed
        u=np.random.uniform(0,1,N);
        #Function that computes moments for given value of theta
        #Used to compute arg-minimizer and jacobian
        def moment(theta):
            yb=-np.log(1-u)/theta;
            return np.array([np.mean(yb),np.var(yb)]);
        #Objective function to be minimized, for given theta, draw yb ~ E(theta) compute
        # moments^b = mean(yb), var(yb)
        # and then return the distance (moments^b-moments)'W(moments^b-moments)
        def obj(theta):
            d=mom-moment(theta);
            return np.dot(np.dot(d.transpose(),W),d);
        #One dimensional optimization problem, bounds set to [0,10]
        opt=minimize_scalar(obj,bounds=(0., 10.), method='bounded');
        draws[b]=opt.x;   #Take the arg-min of the optimization problem
        dists[b]=opt.fun; #Take the value of the objective at the optimum, to be used as the distance
        #Compute the weights using the volume of the Jacobian
        #Alternatively we could use the implicit function theorem but this is much of computationally friendly
        #We know the Jacobian analytically, it is provided in the paper.
        eps=1e-4;
        Jm=(moment(draws[b]+eps)-moment(draws[b]-eps))/(2*eps)
        #Jm=sp.misc.derivative(moment,draws[b]); #Somehow the scipy derivative function does not seem to return correct results
        weights[b]=1/np.sqrt(np.dot(Jm.transpose(),Jm));
    #Keep the q*100% draws associated with the smallest distance
    w=np.percentile(dists,q*100);
    draws_out  =np.zeros(B);
    dists_out  =np.zeros(B);
    weights_out=np.zeros(B);
    b=0;
    k=0;
    while (k<int(B/q)):
        if (dists[k]<=w):
            draws_out[b]  =draws[k];
            dists_out[b]  =dists[k];
            weights_out[b]=weights[k];
            b=b+1;
            k=k+1;
        else:
            k=k+1;
    #Return the list of draws, weights and distances using the wrapper
    return RS_OI(draws_out,weights_out,dists_out);

def AcceptReject(B,mom,q): #ABC accept-reject
    #Since we cannot draw from U[0,inf] we draw from U[0,3] as an approximation
    #We could draw from a U[0,10] or with a larger bound, but the results are nearly identical and it is much
    #more computationally friendly this way.
    draws=np.random.uniform(0,3,int(B/q));
    dists=np.zeros(int(B/q));
    for b in range(0,int(B/q)):
        yb=-np.log(1-np.random.uniform(0,1,N))/draws[b]; #Simulate yb ~ exp(theta^b)
        d=mom-[np.mean(yb),np.var(yb)];                  #Compute moments
        dists[b]=np.dot(np.dot(d.transpose(),W),d);      #Compute the distance (moments^b-moments)'W(moments^b-moments)
    #Keep the closest draws
    w=np.percentile(dists,q*100);
    draws_out=np.zeros(B);
    dists_out=np.zeros(B);
    b=0;
    k=0;
    while (k<int(B/q)):
        if (dists[k]<=w):
            draws_out[b]=draws[k];
            dists_out[b]=dists[k];
            b=b+1;
            k=k+1;
        else:
            k=k+1;
    #Return list of draws and distances using the wrapper
    return AR(draws_out,dists_out);

def resample(sample):
    #Takes a wrapper (draws,weights) and returns an iid sample of draws by sampling with replacement.
    w=sample.weights/np.sum(sample.weights);
    L=sample.draws.size;
    return np.random.choice(sample.draws,L,True,p=w)

def wmean(draws,weights):
    #Takes a pair (draws,weights) and returns the weighted average.
    return np.sum(draws*weights)/np.sum(weights)

#We want 10,000 draws
B=int(1e4);
q=1./50; #We keep 1/50 = 2% closest draws from the reverse sampler (over-identified)

sample0=np.random.gamma(N+1,1/(mom[0]*N),B); #Draw from the true posterior
sample1=JID(B,mom[0]);                       #Reverse sampler, just-identified
sample2=OID(B,mom,q);                        #Reverse sampler, over-identified
sample3=AcceptReject(B,mom,1./1000);         #ABC accept-Reject keep the 1/1000 = 0.1% closest draws

#Vector of posterior means (computed analytically for the true posterior)
output = [(N+1)/(mom[0]*N),wmean(sample1.draws,sample1.weights),wmean(sample2.draws,sample2.weights),np.mean(sample3.draws)]

#Stack the draws together, then print posterior means and plot posterior densities
out=pandas.DataFrame({'True':sample0,'RS-JI':resample(sample1),'RS-OI':resample(sample2),'ABC':sample3.draws})
m=pandas.melt(out)
print output
print np.mean(out)
#print ggplot(m,aes(x='value',colour='variable',fill='variable'))+geom_density(alpha=0.2)
