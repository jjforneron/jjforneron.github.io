import numpy as np
import scipy as sp
from math import sqrt
from math import log
from math import atanh
from math import tanh
from math import exp
from scipy.stats import norm
import numpy.random as rand
from scipy.optimize import fmin
from copy import copy
import time, sys
from numba import jit
import pandas as pd
import argparse

parser = argparse.ArgumentParser(description='Provide a seed')
parser.add_argument('integers', metavar='N', type=int, nargs=1,
                   help='an integer for the seed')

print 'Number of arguments:', len(sys.argv), 'arguments.'
print 'Argument List:', str(sys.argv)

if (len(sys.argv)<=1):
    seed=123
else:
    args = parser.parse_args()
    seed=args.integers[0]*1000
print('Seed used: '+str(seed))
rand.seed(seed)

path='/vega/sscc/work/users/jmf2209/ABC/Deaton/csv/'
filename = path+'Reverse_3_'+str(seed)+'.csv'

@jit()
def Tauchen(model):
    rho  =model['income'][1]
    nY   =model['income'][0]
    m    =model['income'][2]
    mu   =model['param'][3]
    sig  =model['param'][4]
    Z    =np.zeros(nY)
    Zprob=np.zeros((nY,nY))
    a =(1-rho)*mu
    Z[nY-1]=m * sqrt(sig**2 / (1 - rho**2));
    Z[0]  =-Z[nY-1]
    zstep=(Z[nY-1]-Z[0])/(nY-1)
    for i in range(1,nY-1):
        Z[i]=Z[0]+zstep*(i)
    Z=Z+a/(1-rho)
    for j in range(0,nY):
        for k in range(0,nY):
            if (k==0):
                Zprob[j,k]=norm.cdf( (Z[0]-a-rho*Z[j]+zstep/2)/sig )
            elif (k==nY-1):
                Zprob[j,k]=1-norm.cdf( (Z[nY-1]-a-rho*Z[j]-zstep/2)/sig )
            else:
                Zprob[j,k] = norm.cdf( (Z[k]-a-rho*Z[j]+zstep/2)/sig ) - norm.cdf( (Z[k]-a-rho*Z[j]-zstep/2)/sig )
    Y=Z
    Y.shape=(1,nY)
    PI=Zprob
    return {'Y':Y,'PI':PI}

@jit()
def Policy(model,tauchen):
    param  = model['param']
    beta   = param[0];
    R      = param[1];
    gam    = param[2];
    mu     = param[3];
    sig    = param[4];
    income = model['income'];
    nY     = income[0];
    rho    = income[1];
    m      = income[2];
    Y=tauchen['Y']
    PI=tauchen['PI']
    agrid  = model['agrid']
    nA     = agrid[0];
    amin   = agrid[1];
    amax   = agrid[2]*np.max(Y);
    crit   = 1.0e-6;
    crit1  = 1.0e-4;
    maxit  = 100;
    dist   = 1.0;
    count  = 0;
    pen    = -1.0e15;
    A=np.linspace(amin,amax,nA)
    A.shape=(1,nA)
    AA       = A.transpose()*np.ones((1,nA));
    AAP      = AA.transpose();
    V0       = np.zeros((nY,nA));
    V0_T     = np.zeros((nY,nA));
    V1       = np.zeros((nY,nA));
    IAP      = np.zeros((nY,nA)).astype(int);
    ZYT      =np.zeros(nA*nY)
    ZCT      =np.zeros(nA*nY)
    CP       =np.zeros((nY,nA))
    SP       =np.zeros((nY,nA))
    TV0      = np.zeros((nA,nA))
    while (dist >= crit and count < maxit):
        for i in range(0,nY):
            C  = AA + Y[0,i]-AAP/R
            ind=np.where(C<=1e-6)
            C[ind]=1e-16
            UU = (np.power(C,1.-gam)-1.)/(1.-gam)
            UU[ind]=pen
            Pos=C>0
            U  = np.multiply(UU,Pos)+pen*(1.-Pos)
            TV0= np.zeros((nA,nA))
            for j in range(0,nY):
                TV0 = TV0 + np.multiply(PI[i,j],np.ones((1,nA))*V0[j,])
            TMPV = U+beta*TV0
            MM=TMPV.argmax(axis=1)
            TT=TMPV.max(axis=1)
            #print TT
            V1[i,] =TT
            IAP[i,]=MM
        dist1=1.
        while (dist1>=crit1):
            for i in range(0,nY):
                C_T  = A+Y[0,i]-A[0,IAP[i,]]/R
                indT=np.where(C_T==0)
                C_T[indT]=1e-16
                U_T  = (np.power(C_T,1.-gam)-1)/(1.-gam)
                U_T[indT]=pen
                TV_T = np.zeros((1,nA))
                for j in range(0,nY):
                    TV_T =  TV_T+PI[i,j]*V1[j,IAP[i,]]
                V0_T[i,]=U_T+beta*TV_T
            diff=np.abs(V0_T-V1)
            dist1=np.max(diff)
            V1=V0_T
            V0_T=V0_T*0
        diff2=np.abs(V0-V1)
        dist=np.max(diff2)
        V0=V1
        count=count+1
    for i in range(0,nY):
        CP[i,] = Y[0,i] + A - A[0,IAP[i,]]/R;      #consumption policy rule
        SP[i,] = Y[0,i] + A - CP[i,];            #savings policy rule
    for i in range(0,nY):
        for j in range(0,nA):
            ZYT[(i-1)*nA+j]=Y[0,i]+A[0,j]
            ZCT[(i-1)*nA+j]=CP[i,j]
    II=ZYT.argsort()
    ZY=ZYT[II]
    ZC=ZCT[II]
    CP=CP
    SP=SP
    IAP=IAP
    A=A
    return {'CP':CP,'SP':SP,'IAP':IAP,'ZY':ZY,'ZC':ZC,'A':A}

#@jit()
def Simulate(model,tauchen,policy,e):
    T=model['T']
    d=model['d']
    param  = model['param']
    beta   = param[0];
    R      = param[1];
    gam    = param[2];
    mu     = param[3];
    sig    = param[4];
    income = model['income'];
    nY     = income[0];
    rho    = income[1];
    m      = income[2];
    Y=tauchen['Y']
    PI=tauchen['PI']
    agrid  = model['agrid']
    nA     = agrid[0];
    amin   = agrid[1];
    amax = agrid[2]*np.max(Y);
    CP =policy['CP']
    SP =policy['SP']
    IAP=policy['IAP']
    A=policy['A']
    cumpai=np.cumsum(PI,axis=1)
    isimuy=np.zeros(T+d).astype(int)
    isimua=np.zeros(T+d+1).astype(int)
    isimuy[0]=1
    isimua[0]=1
    for i in range(1,T+d):
        for j in range(0,nY):
            if (cumpai[isimuy[i-1],j]>=e[i]):
                isimuy[i]=j;
                break;
    #print isimuy
    simuy=Y[0,isimuy]
    isimuap=np.zeros(T+d).astype(int)
    simuc=np.zeros(T+d)
    for i in range(0,T+d):
        isimuap[i] =IAP[isimuy[i],isimua[i]]
        simuc[i]   =CP[isimuy[i],isimua[i]]
        isimua[i+1]=isimuap[i]
    simua  =A[0,isimua]
    simuap =A[0,isimuap]
    y  =simuy[d:(T+d)]
    c  =simuc[d:(T+d)]
    ap =simuap[d:(T+d)]
    a  =simua[d:(T+d)]
    return {'c':c,'y':y,'ap':ap,'a':a}

def Jacobian(fun,mod,e):
    eps=1e-3
    def grad(x):
        L=x.size
        E=np.eye(L)
        g=np.zeros((10,L))
        for i in range(0,L):
            g[:,i]=(fun(x+eps*E[i,:],mod,e)-fun(x-eps*E[i,:],mod,e))/(2*eps)
        return g
    return grad

def Gradient(fun):
    eps=1e-3
    def grad(x):
        L=x.size
        E=np.eye(L)
        g=np.zeros(L)
        for i in range(0,L):
            g[i]=(fun(x+eps*E[i,:])-fun(x-eps*E[i,:]))/(2*eps)
        return g
    return grad

def Hessian(fun):
    eps=1e-3
    def hess(x):
        L=x.size
        E=np.eye(L)
        h=np.zeros((L,L))
        for i in range(0,L):
            h[:,i]=(Gradient(fun)(x+eps*E[i,:])-Gradient(fun)(x-eps*E[i,:]))/(2*eps)
        return h
    return hess

def SMM(data,x0,model,shocks,S,W):
    T=model['T']
    mod=copy(model)
    mod['count']=0
    #@jit()
    def Moments(dat):
        c=dat['c']
        y=dat['y']
        a=dat['a']
        ybar=np.mean(y[2:T])
        cbar=np.mean(c[2:T])
        abar=np.mean(a[2:T])
        mom=np.zeros((T-2,10))
        mom[:,0]=y[2:T]
        mom[:,1]=(y[2:T]-ybar)**2
        mom[:,2]=(a[2:T]-abar)**2
        mom[:,3]=(c[2:T]-cbar)**2
        mom[:,4]=(c[2:T]-cbar)*(c[1:(T-1)]-cbar)
        mom[:,5]=(a[2:T]-abar)*(a[1:(T-1)]-abar)
        mom[:,6]=(c[2:T]-cbar)*(c[0:(T-2)]-cbar)
        mom[:,7]=(a[2:T]-abar)*(a[0:(T-2)]-abar)
        mom[:,8]=(c[2:T]-cbar)*(y[2:(T)]-ybar)
        mom[:,9]=(a[2:T]-abar)*(y[2:(T)]-ybar)
        return mom
    mom=np.mean(Moments(data),axis=0)
    #@jit()
    def obj(param):
        if (param[0]>1 or param[0]<0 or param[1]<=0 or param[2]<0 or param[4]<=0):
            return float('inf')
        else:
            mod['param']=param
            mod['count']+=1
            tauch=Tauchen(mod)
            pol=Policy(mod,tauch)
            moms=np.zeros(10)
            for s in range(0,S):
                data_s=Simulate(mod,tauch,pol,shocks[:,s])
                moms+=np.mean(Moments(data_s),axis=0)/S
            moms-=mom
            obj = np.dot(np.dot(moms.transpose(),W),moms)
            print(mod['count'], obj, mod['param'])
            return obj
    res=fmin(obj,x0,maxiter=int(1e4),maxfun=int(1e4),xtol=1e-6,retall=True,full_output=True,disp=True)
    #res=fmin_l_bfgs_b(obj,x0,approx_grad=True,maxiter=int(1e4),maxfun=int(1e4),bounds=[(0,1),(0,2),(0,10),(None,None),(0,None)],disp=True)
    moms=np.zeros((10,S))
    mod['param']=res
    tauch=Tauchen(mod)
    pol=Policy(mod,tauch)
    for s in range(0,S):
        data_s=Simulate(mod,tauch,pol,shocks[:,s])
        moms[:,s]=np.mean(Moments(data_s),axis=0)
        V=np.cov(moms)
    W=np.linalg.inv(V)
    res=fmin(obj,res,maxiter=int(1e4),maxfun=int(1e4),xtol=1e-6,retall=True,full_output=True,disp=True)
    return {'res':res,'V':V}

def Weights(data,x,model,shocks,S):
    T=model['T']
    mod=copy(model)
    mod['count']=0
    #@jit()
    def Moments(dat):
        c=dat['c']
        y=dat['y']
        a=dat['a']
        ybar=np.mean(y[2:T])
        cbar=np.mean(c[2:T])
        abar=np.mean(a[2:T])
        mom=np.zeros((T-2,10))
        mom[:,0]=y[2:T]
        mom[:,1]=(y[2:T]-ybar)**2
        mom[:,2]=(a[2:T]-abar)**2
        mom[:,3]=(c[2:T]-cbar)**2
        mom[:,4]=(c[2:T]-cbar)*(c[1:(T-1)]-cbar)
        mom[:,5]=(a[2:T]-abar)*(a[1:(T-1)]-abar)
        mom[:,6]=(c[2:T]-cbar)*(c[0:(T-2)]-cbar)
        mom[:,7]=(a[2:T]-abar)*(a[0:(T-2)]-abar)
        mom[:,8]=(c[2:T]-cbar)*(y[2:(T)]-ybar)
        mom[:,9]=(a[2:T]-abar)*(y[2:(T)]-ybar)
        return mom
    mom=np.mean(Moments(data),axis=0)
    moms=np.zeros((10,S))
    mod['param']=x
    tauch=Tauchen(mod)
    pol=Policy(mod,tauch)
    for s in range(0,S):
        data_s=Simulate(mod,tauch,pol,shocks[:,s])
        moms[:,s]=np.mean(Moments(data_s),axis=0)
        V=np.cov(moms)
    W=np.linalg.inv(V)
    return W


def RS(data,x0,model,B,W,filename):
    T=model['T']
    d=model['d']
    mod=copy(model)
    mod['count']=0
    e=rand.uniform(0,1,T+d)
    #@jit()
    def Moments(dat):
        c=dat['c']
        y=dat['y']
        a=dat['a']
        ybar=np.mean(y[2:T])
        cbar=np.mean(c[2:T])
        abar=np.mean(a[2:T])
        mom=np.zeros((T-2,10))
        mom[:,0]=y[2:T]
        mom[:,1]=(y[2:T]-ybar)**2
        mom[:,2]=(a[2:T]-abar)**2
        mom[:,3]=(c[2:T]-cbar)**2
        mom[:,4]=(c[2:T]-cbar)*(c[1:(T-1)]-cbar)
        mom[:,5]=(a[2:T]-abar)*(a[1:(T-1)]-abar)
        mom[:,6]=(c[2:T]-cbar)*(c[0:(T-2)]-cbar)
        mom[:,7]=(a[2:T]-abar)*(a[0:(T-2)]-abar)
        mom[:,8]=(c[2:T]-cbar)*(y[2:(T)]-ybar)
        mom[:,9]=(a[2:T]-abar)*(y[2:(T)]-ybar)
        return mom
    def Moments_wrapper(param,mod,e):
        mod['param'][2:5]=param
        mod['count']+=1
        tauch=Tauchen(mod)
        pol=Policy(mod,tauch)
        moms=np.zeros(10)
        data_s=Simulate(mod,tauch,pol,e)
        moms=np.mean(Moments(data_s),axis=0)
        return moms
    mom=np.mean(Moments(data),axis=0)
    def obj(param,mod,e):
        if (param[0]>10 or param[0]<0 or param[2]<0):
            return float('inf')
        else:
            mod['param'][2:5]=param
            mod['count']+=1
            tauch=Tauchen(mod)
            pol=Policy(mod,tauch)
            moms=np.zeros(10)
            data_s=Simulate(mod,tauch,pol,e)
            moms=np.mean(Moments(data_s),axis=0)-mom
            obj = np.dot(np.dot(moms.transpose(),W),moms)
            #print mod['count'], obj, mod['param']
            return obj
    draws=np.zeros((B,3))
    dists=np.zeros(B)
    Jacs=np.zeros(B)
    def one_draw(b):
        #rand.seed(b*1000)
        e=rand.uniform(0,1,T+d)
        res=fmin(obj,x0,maxiter=int(1e4),maxfun=int(1e4),xtol=1e-6,args=(mod,e))
        #res=x0
        draws[b,:]=res
        dists[b]=obj(draws[b,:],mod,e)
        mod['agrid'][0]=1000
        J=Jacobian(Moments_wrapper,mod,e)(res)
        mod['count']+=10
        Jacs[b]=sqrt(np.linalg.det(J.transpose().dot(J)))
        while (Jacs[b]<=1e-6 and mod['agrid'][0]<=10000):
            mod['agrid'][0]=mod['agrid'][0]*2
            J=Jacobian(Moments_wrapper,mod,e)(res)
            mod['count']+=10
            Jacs[b]=sqrt(np.linalg.det(J.transpose().dot(J)))
            print mod['agrid'][0], Jacs[b]
    for b in range(0,B):
        one_draw(b)
        mod['agrid'][0]=500
        output=pd.DataFrame(draws,columns=['Gamma','Mu','Sigma'])
        output['dists']=dists
        output['Jacs']=Jacs
        output.to_csv(filename)
        print(b, dists[b], Jacs[b], draws[b,:])
    return {'output':output,'n_calls':mod['count']}

np.set_printoptions(precision=4)

#Set parameters
param=[10./11.,1.05,2.,100,10]
income=[10,0.,3.]
agrid=[500,0,3]
T=400
d=100
#Generate Data
e=np.genfromtxt(path+"shocks.csv", delimiter=',')
model  ={'param':param,'income':income,'agrid':agrid,'T':T,'d':d}
tauchen=Tauchen(model)
policy =Policy(model,tauchen)
data   =Simulate(model,tauchen,policy,e)

#Estimate Parameters
S=50
shocks=rand.uniform(0,1,(T+d,S))
init=np.array([2.4,np.mean(data['y']),np.std(data['y'])])
W=np.eye(10)
print init
print W
B=200
t0=time.time()
reverse=RS(data,init,model,B,W,filename)
t1= time.time()
print t1-t0
reverse['output'].to_csv(filename)
info=np.array([reverse['count'],t1-t0])
np.savetxt(path+'info_3_'+str(seed)+'.csv',info,delimiter=',')
