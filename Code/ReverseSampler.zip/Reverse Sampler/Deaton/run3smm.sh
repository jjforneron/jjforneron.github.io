#!/bin/sh
#hedge.sh
#Torque script to run R program

#Torque directives
#PBS -N JJrev3
#PBS -W group_list=yetisscc
#PBS -l nodes=1,walltime=99:99:99,mem=8500mb
#PBS -M jmf2209@columbia.edu
#PBS -m abe
#PBS -V

#set output and error directories
#PBS -o localhost:/vega/sscc/work/users/jmf2209/ABC/Deaton/eo
#PBS -e localhost:/vega/sscc/work/users/jmf2209/ABC/Deaton/eo

#Command to execute R code
/vega/sscc/tmp1/projects/bigdata/anaconda/bin/python /vega/sscc/work/users/jmf2209/ABC/Deaton/SMM3param.py $seed
