#ggplot for python crashes when plotting the arma posteriors, this code takes the python output
#arma.csv and plots the posteriors in R using ggplot2

setwd("~/Dropbox/abc/jj/Replication Files") #set the proper folder
data=read.csv('arma.csv')

library(ggplot2)
library(gridExtra)

p1<-ggplot(data,aes(x=alpha,colour=Method,fill=Method))+
  geom_density(alpha=0.2)+ylab('Posterior density')+
  ggtitle(expression(alpha))+
  theme(text = element_text(size=16),legend.position="bottom",
        axis.text.x = element_text(face='bold', size=14),
        axis.text.y = element_text(face='bold', size=14),
        strip.text.x = element_text(face="bold",size = 16),
        strip.text.y = element_text(face="bold",size = 16),legend.title=element_blank())

p2<-ggplot(data,aes(x=theta,colour=Method,fill=Method))+
  geom_density(alpha=0.2)+ylab('Posterior density')+
  ggtitle(expression(theta))+
  theme(text = element_text(size=16),legend.position="bottom",
        axis.text.x = element_text(face='bold', size=14),
        axis.text.y = element_text(face='bold', size=14),
        strip.text.x = element_text(face="bold",size = 16),
        strip.text.y = element_text(face="bold",size = 16),legend.title=element_blank())

p3<-ggplot(data,aes(x=sigma,colour=Method,fill=Method))+
  geom_density(alpha=0.2)+ylab('Posterior density')+
  ggtitle(expression(sigma))+
  theme(text = element_text(size=16),legend.position="bottom",
        axis.text.x = element_text(face='bold', size=14),
        axis.text.y = element_text(face='bold', size=14),
        strip.text.x = element_text(face="bold",size = 16),
        strip.text.y = element_text(face="bold",size = 16),legend.title=element_blank())

grid.arrange(p1,p2,p3,ncol=3)