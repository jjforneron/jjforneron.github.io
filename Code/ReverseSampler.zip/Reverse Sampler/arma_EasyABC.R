#Compute the posterior from an ARMA(1,1) model with parameters alpha, theta, sigma
#An AR(p) auxiliary model is used to compute the statistics hat psi to condition on.
#The likelihood based posterior is computed using the Kalman Filter.
#The priors are U[-1,1] for alpha,theta and U[0,inf] for sigma.
set.seed(123)
library(numDeriv) #package to compute numerical derivatives
library(mcmc)     #package to use the MH algorithm
library(expm)     #package to compute matrix square root
library(EasyABC)  #package to run ABC

T=200 #200 observations
n_calls<<-0
sim_model <- function(param,shocks=matrix(rnorm(T+1),T+1,1)) {
  #Simulate and ARMA(1,1) model with paramters param=c(alpha,theta,sigma)
  #And shocks (if not specified use normal distribution)param,shocks=matrix(rnorm(T+1),T+1,1)
  u=rep(0,T+1)
  for (t in 2:(T+1)) {
    u[t]=param[1]*u[t-1]+param[3]*(shocks[t]+param[2]*shocks[t-1,1])
  }
  n_calls<<-n_calls+1
  return(u[2:(T+1)])
}

moments <- function(param) {
  yb=sim_model(param)
  momb=ar(yb,aic=FALSE,order.max=p)  #Compute auxiliary statistics
  momb=c(momb$ar,sd(momb$res,na.rm=TRUE))
  return(momb)
}


#Simulate data from ARMA with parameters=c(0.5,0.5,1)
y=sim_model(c(0.5,0.5,1))
p=4                                  #Order of the AR auxiliary model
mom=ar(y,aic=FALSE,order.max=p)      #Estimate the auxiliary model
mom=c(mom$ar,sd(mom$res,na.rm=TRUE)) #Stack moments into a vector
#Weight matrix: identity (inefficient)
W=diag(p+1)

Accept_Reject <- function(B,q,mom) { #ABC Accept-Reject
  #Draw from the prior, since we cannot draw from U[0,inf] we use U[0,3] instead for sigma
  draws=cbind(runif(B/q,-1,1),runif(B/q,-1,1),runif(B/q,0,3))
  dists=rep(0,B/q)
  for (b in (1:(B/q))) {
    shocks=matrix(rnorm(T+1),T+1,1)    #Draw the epsilon^b
    yb=sim_model(c(draws[b,]),shocks)  #Simulate data yb
    momb=ar(yb,aic=FALSE,order.max=p)  #Compute auxiliary statistics
    momb=c(momb$ar,sd(momb$res,na.rm=TRUE))
    #Compute the distance between data and simulated moments
    dists[b]=t(mom-momb)%*%W%*%(mom-momb)
  }
  #Return draws associated with closest moments
  return(draws[which(dists<=quantile(dists,q)),])
}

OID <- function(B,q,mom) { #Reverse Sampler (over-identified)
  ptm <- proc.time() # Time the code
  #Matrix of draws, distances and jacobians
  draws=matrix(NA,B/q,3)
  noisy=matrix(NA,B/q,3)
  noisym=matrix(NA,B/q,p+1)
  noisyd=rep(0,B/q)
  dists=rep(0,B/q)
  jac=rep(0,B/q)
  for (b in (1:(B/q))) {
    shocks=matrix(rnorm(T+1),T+1,1) #Draws the epsilon^b
    moments <- function(par) {
      #Function that for given (alpha,theta,sigma) computes the moments
      #Simulate yb
      yb=sim_model(c(par),shocks)
      momb=ar(yb,aic=FALSE,order.max=p) #Compute moments
      momb=c(momb$ar,sd(momb$res,na.rm=TRUE))
      return(momb)
    }
    dist <- function(par) { #Compute the distance, to be minimized
      #Since sigma >= 0, we solve for log(sigma), we take the exponential
      #calls the moment function and then returns the distance
      par[3]=exp(par[3])
      momb=moments(par)
      d=mom-momb
      return(t(d)%*%W%*%d)
    }
    #Solve the optimization problem using the optim function
    #Default optimization routine is Nelder-Mead, can be changed to BFGS using method="BFGS"
    #A box-constrained BFGS is also available via method="L-BFGS-B"
    opt=optim(c(0,0,1),method='L-BFGS-B',lower=c(-1,-1,-Inf),upper=c(1,1,Inf),dist,control=list(maxit=1e3))
    #Store minimizer, value of the objective function
    draws[b,]=opt$par
    dists[b]=opt$value
    draws[b,3]=exp(draws[b,3])

    #Compute Jacobian
    Jm=jacobian(moments,draws[b,],method="simple")
    #Store inverse of the volume of the Jacobian
    jac[b]=1/sqrt(det(t(Jm)%*%(Jm)))
     setTxtProgressBar(txtProgressBar(style=3),b/(B/q))
  }
  #Return draws, jacobians and distances
  return(list(draws=draws,jac=jac,dists=dists,time_elapsed=proc.time()-ptm))
}

kernel <- function(u) { #Indicator function
  return(u*1*(u<=1)*(u>=-1))
}

SMD <- function(S,mom) { #Simulated Minimum Distance Estimator, for comparison
  #The structure is similar to the RS
  shocks=array(rnorm(S*(T+1)),dim=c(T+1,S))
  moments <- function(par,s) {
    yb=sim_model(par,matrix(shocks[,s]))
    momb=ar(yb,aic=FALSE,order.max=4)
    momb=c(momb$ar,sd(momb$res,na.rm=TRUE))
    return(momb)
  }
  dist <- function(par) {
    par[3]=exp(par[3])
    momb=rep(0,5)
    for (s in (1:S)) {
      momb=momb+moments(par,s)/S
    }
    return(sum((mom-momb)^2))
  }
  opt=optim(c(0,0,1),dist,control=list(maxit=1e3))
  out=opt$par
  out[3]=exp(out[3])
  return(out)
}

KF <- function(y,alpha,theta,sigma,x0,P0) { #Kalman Filter for the ARMA(1,1)
  #Set y0=0, epsilon0=0
  T=length(y)-1
  P0=diag(c(sigma^2,0))
  x =cbind(x0,matrix(0,2,T))
  x_=cbind(x0,matrix(0,2,T))
  Q=diag(c(sigma,0)^2)
  P =array(0,dim=c(2,2,T+1));P[,,1]=P0
  P_=P
  e=rep(0,T+1)
  K=array(0,dim=c(2,T+1))
  Q=diag(c(sigma,0)^2)
  A=c(1,theta)
  R=1e-20
  Phi=matrix(0,2,2);Phi[2,1]=1;
  loglik=rep(0,T+1)
  for (t in 2:(T+1)) {
    x[,t] =Phi%*%x_[,t-1]
    P[,,t] =Phi%*%P_[,,t-1]%*%t(Phi)+Q
    K[,t] =P[,,t]%*%A%*%solve(t(A)%*%P[,,t]%*%(A)+R)
    x_[,t]=x[,t]+K[,t]*as.numeric(y[t]-alpha*y[t-1]-A%*%x[,t])
    e[t] =y[t]-alpha*y[t-1]-A%*%x[,t]
    P_[,,t]=as.numeric(1-K[,t]%*%A)*P[,,t]
    loglik[t]=0.5*(log(t(A)%*%P[,,t]%*%(A)+R)+e[t]^2/(t(A)%*%P[,,t]%*%(A)+R))
  }
  return(list(x=x,x_=x_,e=e,loglik=loglik))
}

LogLik <- function(par,y) { #Return Log-Likelihood for MLE and MCMC
  return(sum(KF(y,(par[1]),(par[2]),par[3],0,(par[2]))$loglik))
}

MLE <- function(y) { #MLE
  return(optim(c(0,0,1),LogLik,y=y,method="BFGS",control=c(maxit=1e3))$par)
}

MH <- function(B,y) { #MCMC using Kalman Filter to compute the Likelihood
  init=MLE(y)  #Initial value=MLE
  #Standard deviation of the random walk innovation step
  step=solve(sqrtm(hessian(LogLik,init,y=y)))
  log_post <- function(par) { #Log of the posterior function
    if (abs(par[1])>1 || par[3]<0) {return(-Inf)} else {return(-LogLik(par,y))}
  }
  return(z=metrop(log_post,init,B,scale=step)) #Return the output of the MCMC
}

#Number of draws
B=10000
#Number of RS draws to be discarded
q=1/10


#Draw from ABC Accept-Reject, RS and MCMC
Over=OID(B,q,mom)
calls_Over = n_calls
n_calls<<-0
tolerance=0.03#quantile(Over$dists,q)
pacc=0.005
 z=ABC_sequential("Drovandi",moments,prior=list(c("unif",-1,1),c("unif",-1,1),c("unif",0,3)),
 nb_simul=B,summary_stat_target=mom, tolerance_tab=tolerance,progress_bar=TRUE)
 post=z$param

McMc=MH(B+200,y)

#Compute weights
weights=Over$jac*kernel(Over$dists/quantile(Over$dists,q))
weights=weights/sum(weights)

#Draw the posterior densities
library(ggplot2)
library(reshape)
out1 = as.data.frame(cbind(post[,1],Over$draws[which(weights>0),1],McMc$batch[201:(B+200),1]))
colnames(out1)=c('ABC','RS','Likelihood')
m1=melt(out1)
m1$weight=c(rep(1/B,B),weights[which(weights>0)],rep(1/B,B))
p1<-ggplot(m1,aes(x=value,colour=variable,fill=variable,weight=weight))+
  geom_density(alpha=0.2)+
  ggtitle(expression(alpha))+
  theme(text = element_text(size=16),legend.position="bottom",
        axis.text.x = element_text(face='bold', size=14),
        axis.text.y = element_text(face='bold', size=14),
        strip.text.x = element_text(face="bold",size = 16),
        strip.text.y = element_text(face="bold",size = 16))

out2 = as.data.frame(cbind(post[,2],Over$draws[which(weights>0),2],McMc$batch[201:(B+200),2]))
colnames(out2)=c('ABC','RS','Likelihood')
m2=melt(out2)
m2$weight=c(rep(1/B,B),weights[which(weights>0)],rep(1/B,B))
p2<-ggplot(m2,aes(x=value,colour=variable,fill=variable,weight=weight))+
  geom_density(alpha=0.2)+
  ggtitle(expression(theta))+
  theme(text = element_text(size=16),legend.position="bottom",
        axis.text.x = element_text(face='bold', size=14),
        axis.text.y = element_text(face='bold', size=14),
        strip.text.x = element_text(face="bold",size = 16),
        strip.text.y = element_text(face="bold",size = 16))

out3 = as.data.frame(cbind(post[,3],Over$draws[which(weights>0),3],McMc$batch[201:(B+200),3]))
colnames(out3)=c('ABC','RS','Likelihood')
m3=melt(out3)
m3$weight=c(rep(1/B,B),weights[which(weights>0)],rep(1/B,B))
p3<-ggplot(m3,aes(x=value,colour=variable,fill=variable,weight=weight))+
  geom_density(alpha=0.2)+
  ggtitle(expression(sigma))+
  theme(text = element_text(size=16),legend.position="bottom",
        axis.text.x = element_text(face='bold', size=14),
        axis.text.y = element_text(face='bold', size=14),
        strip.text.x = element_text(face="bold",size = 16),
        strip.text.y = element_text(face="bold",size = 16))
library(gridExtra)
grid.arrange(p1,p2,p3,ncol=3)

print(Over$time_elapsed)
print(z$computime)
print(calls_Over)
print(n_calls)
