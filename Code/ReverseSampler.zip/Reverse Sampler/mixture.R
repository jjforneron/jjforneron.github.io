#Solve the mixture example of Sisson, Fan and Tanaka (2007) and Bonassi and West (2015).
#The model is y ~ theta + pN(0,v1) + (1-p)N(0,v2)
#v1 = 1/100, v2 = 1
#We observe one draw from the data: x=0
#The prior is theta ~ U[-10,10]
#The posterior is known analytically:
# theta|x=0 ~ pN(0,v1) + (1-p)N(0,v2) constrained to [-10,10]

library(ggplot2)
library(reshape)
set.seed(123)

#Construct the vector of variances
v=c(1/100,1)
sim_data <- function(theta,normal,coin_flip) { #Simulate data
  return(theta+sqrt(v[coin_flip+1])*normal)
}

#Observed data is x=0
x0=0

SMD <- function(x,S) { #Simulated Minimum Distance Estimator, for comparison
  #Draw the innovations N(0,1), and Bernoulli draws
  normals<- rnorm(S)
  coin_flips <- rbinom(S,1,1/2)
  #Objective function to be minimized (could be solved by hand)
  obj <- function(theta) {
    out=rep(NA,S)
    #Compute many draws ys from: yb ~ theta + pN(0,v1) + (1-p)N(0,v2) 
    out=normals*(sqrt(v[1])*coin_flips+sqrt(v[2])*(1-coin_flips))+theta
    #Compute the difference between average draw and realization
    return((mean(out)-x)^2)
  }
  #Solve the one-dimensional optimization problem using optimize
  #Boundaries for the optimization problem are [-10,10]. 
  return(optimize(obj,c(-10,10))$minimum)
}

ABC_AR <- function(x,B,eps)  { # ABC accept_reject
  thetas=rep(NA,B)
  for (b in 1:B) {
    #Draw theta from the prior U[-10,10]
    theta=runif(1,-10,10)
    #Simulate data from: theta + pN(0,v1)+(1-p)N(0,v2)
    p=rbinom(1,1,1/2)
    data=theta+rnorm(1)*(sqrt(v[1])*p+sqrt(v[2])*(1-p))
    #Repeat until the simulated statistic (y) is epsilon close to the data (x)
    while(abs(data-x)>eps) {
      theta=runif(1,-10,10)
      p=rbinom(1,1,1/2)
      data=theta+rnorm(1)*(sqrt(v[1])*p+sqrt(v[2])*(1-p))
    }
    #Keep the draw
    thetas[b]=theta
  }
  #Return the draws
  return(thetas)
}

RS <- function(x,B) { #Reverse Sampler
  normals<- rnorm(B)  #Draw normals
  coin_flips <- rbinom(B,1,1/2) #Draw latent variable for the mixture
  thetas = x-normals*(sqrt(v[1])*coin_flips+sqrt(v[2])*(1-coin_flips))
  ##The optimization problem can be solve by hand in this case as for computing the mean of a normal.
  #The jacobian is also known analytically, it is constant equal to 1.
  #The prior is uniform on [-10,10] so the weights are 1 in [-10,10] and 0 outside.
  return(list(thetas=thetas,weights=dunif(thetas,-10,10)))
}

SMC <- function(x,B) {
  #Initialization: Generate B draws using ABC Accept-Rject
  t=1 
  init=eps[t]
  weights=matrix(1/B,length(eps),B)
  thetas=matrix(NA,length(eps),B)
  for (b in 1:B) {
    theta=runif(1,-10,10)
    p=rbinom(1,1,1/2)
    data=theta+rnorm(1)*(sqrt(v[1])*p+sqrt(v[2])*(1-p))
    while(abs(data-x)>init) {
      theta=runif(1,-10,10)
      p=rbinom(1,1,1/2)
      data=theta+rnorm(1)*(sqrt(v[1])*p+sqrt(v[2])*(1-p))
    }
    thetas[1,b]=theta
  }
  #SMC part: 
  for (t in 2:length(eps)) {
    #Variance in the transition kernel
    sigma_t=sqrt(sum(weights[t-1,]*thetas[t-1,]^2)-sum(weights[t-1,]*thetas[t-1,])^2)/B^(1/6)
    
    for (b in 1:B) {
      #Draw theta from a multinomial
      theta=thetas[t-1,sample(1:B,1,prob=weights[t-1,])] 
      #Generate the proposal draw by adding gaussian noise
      theta=theta+sigma_t*rnorm(1)
      #Simulate data
      p=rbinom(1,1,1/2)
      data=theta+rnorm(1)*(sqrt(v[1])*p+sqrt(v[2])*(1-p))
      #Repeat the above until we get a statistic close enough to the data
      while(abs(data-x)>eps[t]) {
        theta=thetas[t-1,sample(1:B,1,prob=weights[t-1,])]
        theta=theta+sigma_t*rnorm(1)
        p=rbinom(1,1,1/2)
        data=theta+rnorm(1)*(sqrt(v[1])*p+sqrt(v[2])*(1-p))
      }
      #Keep that draw
      thetas[t,b]=theta
      #Compute the weight using the transition probability (prior is uniform)
      weights[t,b]=dunif(theta,-10,10)/sum(weights[t-1,]*dnorm((theta-thetas[t-1,])/sigma_t))
    }
    #Normalize weights
    weights[t,]=weights[t,]/sum(weights[t,])
  }
  #Return a list with the draws: thetas and the weights: weights.
  return(list(thetas=thetas[t,],weights=weights[t,]))
}

SMC_AW <- function(x,B) { #This is the SMC-AW of Bonassi and West (2015)
  #The code is almost identical to the SMC above except that the weights are computed 
  #taking into account the distance between the draws and the data d(yb,x)
  t=1
  init=eps[t]
  weights=matrix(1/B,length(eps),B)
  thetas=matrix(NA,length(eps),B)
  xs=matrix(NA,length(eps),B)
  for (b in 1:B) {
    theta=runif(1,-10,10)
    p=rbinom(1,1,1/2)
    data=theta+rnorm(1)*(sqrt(v[1])*p+sqrt(v[2])*(1-p))
    while(abs(data-x)>init) {
      theta=runif(1,-10,10)
      p=rbinom(1,1,1/2)
      data=theta+rnorm(1)*(sqrt(v[1])*p+sqrt(v[2])*(1-p))
    }
    thetas[1,b]=theta
    xs[1,b]=data
  }
  for (t in 2:length(eps)) {
    sigma_t=sqrt(sum(weights[t-1,]*thetas[t-1,]^2)-sum(weights[t-1,]*thetas[t-1,])^2)/B^(1/6)
    for (b in 1:B) {
      theta=thetas[t-1,sample(1:B,1,prob=weights[t-1,])]
      theta=theta+sigma_t*rnorm(1)
      p=rbinom(1,1,1/2)
      data=theta+rnorm(1)*(sqrt(v[1])*p+sqrt(v[2])*(1-p))
      while(abs(data-x)>eps[t]) {
        theta=thetas[t-1,sample(1:B,1,prob=weights[t-1,])]
        theta=theta+sigma_t*rnorm(1)
        p=rbinom(1,1,1/2)
        data=theta+rnorm(1)*(sqrt(v[1])*p+sqrt(v[2])*(1-p))
      }
      xs[t,b]=data
      thetas[t,b]=theta
      weights[t,b]=dunif(theta,-10,10)/sum(weights[t-1,]*dnorm((xs[t-1,]-data)/eps[t-1])*dnorm((theta-thetas[t-1,])/sigma_t))
    }
    weights[t,]=weights[t,]/sum(weights[t,])
  }
  return(list(thetas=thetas[t,],weights=weights[t,]))
}

#Number of draws B to be computed
B=5e3
time=matrix(NA,6) #matrix that stores computation times
eps=c(2,1/2,1/40) #epsilon in the notation of Bonassi and West (2015) is delta in our notation
t1=Sys.time()
output=RS(x0,B)$thetas #Reverse Sampler draws

time[1]=as.numeric(Sys.time() - t1)
for (i in 1:length(eps)) { #compute the AR-ABC  for delta=2, 0.5, 0.025
  t1=Sys.time()
  out=ABC_AR(x0,B,eps[i])
  time[i+1]=as.numeric(Sys.time() - t1)
  output=cbind(output,out)
}
t1=Sys.time()
out=SMC(x0,B);time[5]=as.numeric(Sys.time() - t1) #Compute SMC draws
#Resample the draws from a multinomial distribution using the weights as probabilities
out=sample(out$thetas,B,replace=TRUE,prob=out$weights) 
output=cbind(output,out)
t1=Sys.time()
out=SMC_AW(x0,B);time[6]=as.numeric(Sys.time() - t1) #Compute SMC-AW draws
#Resample the draws from a multinomial distribution using the weights as probabilities
out=sample(out$thetas,B,replace=TRUE,prob=out$weights)
output=cbind(output,out)

#Construct the plots for the posterior distributions

output=as.data.frame(output)
colnames(output)=c('RS',paste('AR-ABC - delta = ',eps),'SMC','SMC_AW')
m=melt(output)
ggplot(m,aes(x=value,colour=variable,fill=variable))+
  geom_density(size=1,alpha=0.2)+xlim(-3,3)+
  theme(text = element_text(size=16),legend.position="bottom",
        axis.text.x = element_text(face='bold', size=14),
        axis.text.y = element_text(face='bold', size=14),
        strip.text.x = element_text(face="bold",size = 16),
        strip.text.y = element_text(face="bold",size = 16))

