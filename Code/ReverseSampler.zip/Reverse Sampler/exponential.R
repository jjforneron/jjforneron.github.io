#Compute the posterior from an exponential distribution yi ~ E(theta)
#The true theta=1/2
#The moments hat psi are mean(y), a sufficient statistic and var(y)
#If we condition only on mean(y) we get the true posterior which is Gamma(N+1,1/(N mean(y)))
#Since the prior for accept-reject is U[0,inf] (not proper)
#If we only condition on the second moment var(y), we don't get the true posterior
#By putting  W(2,2) ne 0, we allow  the second moment to affect the  solution of the optimisation problem.
#But so long as W(1,1) ne 0,   we still get the true posterior (known analytically in this case)
#This shows that using the volume and the kernel as weights we get the true posterior from the reverse sampler

library(reshape)
library(ggplot2)
library(numDeriv) #Library used to compute numerical derivatives
set.seed(123)
N=5 #Sample of 5 observations
theta=1/2
y=rexp(N,theta) #Generate data

#Compute moments, weight matrix
mom=c(mean(y),var(y))
W=diag(c(1,4))

JID <- function(B,mom)  {  #Just-Identified Reverse Sampler
  #Matrix for draws, weights
  draws=rep(NA,B)
  weights=rep(NA,B)

  for (b in 1:B) {
    u=runif(N) #Generate the uniform draws from which we compute the exponentials (set the seed, then solve)
    #Objective function: for given theta compute yb ~ E(theta) and mean(yb)
    #return the distance between the
    #mean of yb and the data mean(y)
    obj <- function(theta) {
      yb=qexp(u,theta)
      return((mean(yb)-mom[1])^2)
    }
    #Set the b-th draw equal to the arg-min of the distance
    #Using the optimize (one dimensional) function with bounds [0,10].
    draws[b]=optimize(obj,c(0,10))$minimum #Solve the minimization problem
    #Function which returns the moments, used to compute the Jacobian.
    moment <- function(theta) {
      yb=qexp(u,theta)
      return(mean(yb))
    }
    #The jacobian function from the numDeriv library computes the jacobian, the simple method gives satisfactory results and is
    #much less computationally intensive than the default (adaptative method)
    #weights are set equal to 1/abs(jacobian)
    weights[b]=1/abs(jacobian(moment,draws[b],method="simple")) #Take w(theta) \proto 1/det(jacobian)
  }
  #Return the list of draws and weights
  return(list(lambdas=draws,weights=weights))
}

OID <- function(B,mom)  { #Over-Identified Reverse Sample
  #Matrix of draws, weights, distances and simulated moments
  draws=rep(NA,B)
  weights=rep(NA,B)
  dists=rep(NA,B)
  moments=matrix(NA,B,2)
  moments_=matrix(NA,B,2)
  for (b in 1:B) {
    #Generate the uniform draws to compute the exponential draws, similar to fixing the seed
    u=runif(N)
    #Objective function to be minimized, for given theta, draw yb ~ E(theta) compute
    # moments^b = mean(yb), var(yb) 
    # and then return the distance (moments^b-moments)'W(moments^b-moments)
    obj <- function(theta) {
      yb=qexp(u,theta)
      momb=c(mean(yb),var(yb))
      return(t(mom-momb)%*%W%*%(mom-momb))
    }
    #One dimensional optimization problem, bounds set to [0,10]
    opt=optimize(obj,c(0,10))
    draws[b]=opt$minimum   #Take the arg-min of the optimization problem
    dists[b]=opt$objective #Take the value of the objective at the optimum, to be used as the distance

    #Moment function used to compute the jacobian
    moment <- function(lambda) {
      yb=qexp(u,lambda)
      return(c(mean(yb),var(yb)))
    }

    #Compute the weights using the volume of the Jacobian
    #Alternatively we could use the implicit function theorem but this is much of computationally friendly
    #We know the Jacobian analytically, it is provided in the paper.
    Jm=jacobian(moment,draws[b],method="simple")
    weights[b]=1/sqrt(t(Jm)%*%Jm)
  }
  #Return list of draws, jacobians, diatances, and moments
  return(list(lambdas=draws,weights=weights,dists=dists,
              moments=moments,moments_=moments_))
}

accept_reject <- function(B,mom,q) { #ABC accept-reject
  #Since we cannot draw from U[0,inf] we draw from U[0,3] as an approximation
  #We could draw from a U[0,10] or with a larger bound, but the results are nearly identical and it is much
  #more computationally friendly this way.
  draws=runif(B*q,0,3)
  dists=rep(NA,B*q)
  for (b in 1:(B*q)) {
    yb=qexp(runif(N),draws[b]) #Simulate yb ~ exp(theta^b)
    momb=c(mean(yb),var(yb))   #Compute moments
    dists[b]=t(mom-momb)%*%W%*%(mom-momb) #Compute the distance (moments^b-moments)'W(moments^b-moments)
  }
  select=which(dists<=quantile(dists,1/q)) #Keep the closest draws
  return(list(draws=draws[select],dists=dists[select])) #Return list of draws and distances
}

#We want 10,000 draws
B=1e3
#We keep 1/50 = 2% closest draws from the reverse sampler (over-identified)
q=50
sample0=rgamma(B,shape=N+1,scale=1/(mom[1]*N)) #draw from the true posterior
sample1=JID(B,mom)                #Reverse sampler, just-identified
sample2=OID(B*q,mom)              #Reverse sampler, over-identified
sample3=accept_reject(B,mom,1e3)  #ABC accept-Reject keep the 1/1000 = 0.1% closest draws

kernel <- function(u) {
  return(u*1*(u<=1)*(u>=-1)) #The kernel is the indicator function
}

#Compute the weights by multiplying the jacobian with the kernel
weights=sample2$weights*kernel(sample2$dists/quantile(sample2$dists,1/q))
#Normalize the weights
weights=weights/sum(weights)

#Vector of posterior means, the true posterior mean is known analytically
output=c((N+1)/(mom[1]*N),
         sum(sample1$lambdas*sample1$weights)/sum(sample1$weights),
         sum(sample2$lambdas*weights),mean(sample3$draws))
output=matrix(output,1)
colnames(output)=c('True','RS-JI','RJ-OI','ABC')
print(output)

#Create figure with posterior densities
out=cbind(sample0,sample1$lambdas,sample2$lambdas[which(weights>0)],sample3$draws)
out=as.data.frame(out);colnames(out)=c('True','RS-JI','RS-OI','ABC')
m=melt(out)
m$weights=c(rep(1/B,B),sample1$weights/sum(sample1$weights),weights[which(weights>0)],rep(1/B,B))

ggplot(m,aes(x=value,weights=weights,fill=variable,colour=variable))+geom_density(alpha=0.2)+
  theme(text = element_text(size=16),legend.position="bottom",
        axis.text.x = element_text(face='bold', size=14),
        axis.text.y = element_text(face='bold', size=14),
        strip.text.x = element_text(face="bold",size = 16),
        strip.text.y = element_text(face="bold",size = 16),
        legend.title=element_blank())+ylab('Posterior density')+xlab(expression(theta))