#Compute the posterior from an ARMA(1,1) model with parameters alpha, theta, sigma
#An AR(p) auxiliary model is used to compute the statistics hat psi to condition on.
#The likelihood based posterior is computed using the Kalman Filter.
#The priors are U[-1,1] for alpha,theta and U[0,inf] for sigma.

#Libraries used for matrices, optimization and plots
import numpy as np
import scipy as sp
from scipy.optimize import minimize
from copy import copy
import pandas

#set the seed
sp.random.seed(123)

#Wrappers for output of the samplers, Kalman Filter and MCMC
class ARest(object):
    def __init__(self,coefs,resid,sd):
        self.coefs=coefs;
        self.resid=resid;
        self.sd=sd;

class AR(object):
    def __init__(self,draws,dists):
        self.draws=draws;
        self.dists=dists;

class RS(object):
    def __init__(self,draws,dists,weights):
        self.draws=draws;
        self.dists=dists;
        self.weights=weights;

class Kf(object):
    def __init__(self,x,x_,e,loglik):
        self.x=x;
        self.x_=x_;
        self.e=e;
        self.loglik=loglik;

class mcmc(object):
    def __init__(self,batch,accept):
        self.batch=batch;
        self.accept=accept;

def SimModel(param,shocks):
    #Simulate and ARMA(1,1) model with paramters param=c(alpha,theta,sigma)
    #And shocks
    T=shocks.size-1;
    u=np.zeros(T+1);
    for t in range(1,T+1):
        u[t]=param[0]*u[t-1]+param[2]*(shocks[t]+param[1]*shocks[t-1]);
    return u[1:(T+1)]

def EstimAR(y,p):
    #Estimate auxiliary AR(p) model using OLS - no intercept.
    T=y.size;
    x=y[p:T];
    X=np.zeros((T-p,p));
    for k in range(1,p+1):
        X[:,k-1]=y[(p-k):(T-k)];
    b=np.linalg.solve(np.dot(X.transpose(),X),np.dot(X.transpose(),x));
    resid=x-np.dot(X,b)
    sd=np.std(resid);
    return ARest(b,resid,sd);

def moments(param,shocks,p):
    #Compute Moments directly from the parameters, shocks and lag order p
    y   = SimModel(param,shocks);
    lm  = EstimAR(y,p);
    mom = np.concatenate( (lm.coefs,[lm.sd]));
    return mom;

def AcceptReject(B,mom,q): #ABC Accept-Reject
    #Draw from the prior, since we cannot draw from U[0,inf] we use U[0,3] instead for sigma
    L=int(B/q);
    p=mom.size-1;
    draws=np.array([[np.random.uniform(-1,1,L)],[np.random.uniform(-1,1,L)],[np.random.uniform(0,3,L)]]).transpose();
    dists=np.zeros(L);
    for b in range(0,L):
        #Draw the epsilon^b
        shocks=np.random.normal(0,1,T+1);
        #Compute Moments
        momb=moments(draws[b,:][0],shocks,p);
        #Compute distance
        d=mom-momb;
        dists[b]=np.dot(np.dot(d,W),d);
    #Keep the closest draws
    w=np.percentile(dists,q*100);
    draws_out=np.zeros((B,3),float);
    dists_out=np.zeros(B);
    b=0;
    k=0;
    while (k<L):
        if (dists[k]<=w):
            draws_out[b]=draws[k];
            dists_out[b]=dists[k];
            b=b+1;
            k=k+1;
        else:
            k=k+1;
    #Use wrapper to return draws, distances
    return AR(draws_out,dists_out);

def OID(B,mom,q): #Reverse Sampler (over-identified)
    L=int(B/q);
    p=mom.size-1;
    #Matrix of draws, distances and jacobians
    draws=np.zeros((L,3),float);
    dists=np.zeros(L);
    jac=np.zeros(L);
    for b in range(0,L):
        #Draws the epsilon^b
        shocks=np.random.normal(0,1,T+1);
        #Function that for given (alpha,theta,sigma) computes the moments
        def momentsb(par):
            return moments(par,shocks,p);
        #Compute the distance, to be minimized
        def obj(par):
            #Since sigma >= 0, we solve for log(sigma), we take the exponential
            pars=copy(par);
            pars[2]=np.exp(pars[2]);
            momb=momentsb(pars);
            d=mom-momb;
            return np.dot(np.dot(d,W),d);
        #Solve optimization problem
        #Use L-BFGS-B method for optimization, putting bounds (-1,1) on alpha, theta.
        opt=minimize(obj,np.array([0.0,0.0,0.]),method='L-BFGS-B',bounds=[(-1,1),(-1,1),(-100,100)],options={'maxiter':1000})
        draws[b]=opt.x;                 #Arg-minimizer
        draws[b][2]=np.exp(draws[b][2]);#Take exponential for sigma
        dists[b]=opt.fun;               #Value of the objective
        def jacobian(par): #Computes the jacobian
            eps=1e-4;
            K=par.size;
            out=np.zeros((p+1,K),float)
            for k in range(0,K):
                z=np.zeros(K);
                z[k]=eps;
                out[:,k]=(momentsb(par+z)-momentsb(par-z))/(2*eps);
            return out;
        #Jacobbian
        Jm=jacobian(draws[b]);
        #Inverse of the volume of the Jacobian
        jac[b]=1/np.sqrt(sp.linalg.det(np.dot(Jm.transpose(),Jm)));
    #Keep the closest draws
    w=np.percentile(dists,q*100);
    draws_out=np.zeros((B,3),float);
    dists_out=np.zeros(B);
    jac_out=np.zeros(B);
    b=0;
    k=0;
    while (k<L):
        if (dists[k]<=w):
            draws_out[b]=draws[k];
            dists_out[b]=dists[k];
            jac_out[b]=jac[k];
            b=b+1;
            k=k+1;
        else:
            k=k+1;
    #Use wrapper to return draws, weights, distances
    return RS(draws_out,dists_out,jac_out);

def wmean(sample):
    #Takes a wrapper with (draws,weights) and returns the weighted average.
    dim=sample.draws.shape;
    v=np.zeros(dim[1])
    for k in range(0,dim[1]):
        v[k]=np.sum(sample.draws[:,k]*sample.weights)/np.sum(sample.weights)
    return v

def KF(y,param): #Kalman Filter for ARMA(1,1)
    alpha=param[0];
    theta=param[1];
    sigma=param[2];
    T=y.size-1
    x=np.zeros((T+1,2),float);
    x_=np.zeros((T+1,2),float);
    Q=np.diag([sigma*sigma,0]);
    P=np.zeros((T+1,2,2),float);
    P[0,:,:]=np.diag([sigma*sigma,0]);
    P_=copy(P);
    e=np.zeros(T+1);
    K=np.zeros((2,T+1),float);
    A=np.array([1,theta]);
    R=1e-20;
    Phi=np.zeros((2,2),float);
    Phi[1,0]=1;
    loglik=np.zeros(T+1);
    for t in range(1,T+1):
        x[t,:]=np.dot(Phi,x_[t-1,:]);
        P[t,:,:]=np.dot(np.dot(Phi,P_[t-1,:,:]),Phi.transpose())+Q
        K[:,t]=np.dot(np.dot(P[t,:,:],A),1/(np.dot(np.dot(A.transpose(),P[t,:,:]),A)+R));
        e[t]=y[t]-alpha*y[t-1]-np.dot(A,x[t,:]);
        x_[t,:]=x[t,:]+K[:,t]*(e[t]);
        P_[t,:,:]=(1-np.dot(K[:,t],A))*P[t,:,:];
        loglik[t]=0.5*(np.log(np.dot(np.dot(A.transpose(),P[t,:,:]),A)+R)+e[t]*e[t]/(np.dot(np.dot(A.transpose(),P[t,:,:]),A)+R));
    return Kf(x,x_,e,loglik)

def MLE(y): #Compute MLE using the Kalman Filter for ARMA(1,1)
    def LogLik(par):
        pars=copy(par)
        pars[2]=np.exp(pars[2])
        ss=KF(y,pars);
        return np.sum(ss.loglik)
    opt=minimize(LogLik,np.array([0.0,0.0,0.]),method='L-BFGS-B',bounds=[(-1,1),(-1,1),(-100,100)],options={'maxiter':1000})
    x=opt.x;
    x[2]=np.exp(x[2]);
    return x;

def jacobian(fun,par): #Function used to compute Jacobian
    K=par.size;
    d=fun(par).size;
    eps=1e-8;
    out=np.zeros((d,K));
    for k in range(0,K):
        e=np.zeros(K);
        e[k]=eps;
        out[:,k]=(fun(par+e)-fun(par-e))/(2*eps);
    return out;

def hessian(fun,par): #Function used to compute Hessian
    def jac(par):
        return jacobian(fun,par);
    return jacobian(jac,par);

def MCMC(y,B,burn):  #MCMC
    L=B+burn;
    T=y.size;
    init=MLE(y); #initialize at the MLE
    def LogPost(par):
        if (abs(par[0])>1 or abs(par[1])>1 or par[2]<0):
            return float("-inf");
        else:
            ss=KF(y,par);
            return -np.sum(ss.loglik);
    #use the inverse of the Hessian for the transition kernel
    step=sp.linalg.sqrtm(np.linalg.inv(-hessian(LogPost,init)));
    batch=np.zeros((L,3),float);
    batch[0,:]=init;
    logliks = np.zeros(L);
    logliks[0]=LogPost(init);
    accept=float(L); #No. of accepted draws, count backwards to reduce no. of lines of code
    for b in range(1,L):
        batch[b,:]=batch[b-1,:]+np.dot(step,np.random.normal(0,1,3));
        logliks[b]=LogPost(batch[b,:]);
        if logliks[b]<logliks[b-1]:
            u=np.random.uniform(0,1,1);
            if (np.log(u)>logliks[b]-logliks[b-1]):
                batch[b,:]=batch[b-1,:];
                logliks[b]=logliks[b-1];
                accept-=1;
    #Use wrapper to return output
    return mcmc(batch[burn:L,:],accept/L)

def resample(sample,k): #Resample the k-th column of a matrix of draws with weights
    w=sample.weights/np.sum(sample.weights);
    L=sample.draws.shape[0];
    return np.random.choice(sample.draws[:,k],L,True,p=w)

#T=200 observations
T=200;

#Auxiliary model has 4 lags
p=4;
param=[0.5,0.5,1]; #(alpha,theta,sigma)=(0.5,0.5,1)
y=SimModel(param,np.random.normal(0,1,T+1)); #Simulate data y
W=np.diag(np.ones(p+1),0); #Weighting matrix = diag(1,...,1)
lm=EstimAR(y,p);

#Auxiliary moments hat psi: (hat phi_1,...,hat phi_p,hat sigma u)
mom=np.concatenate((lm.coefs,[lm.sd]))

B=int(1e3) #Number of draws

sample1=OID(B,mom,1./50)            #Reverse Sampler
sample2=AcceptReject(B,mom,1./1000) #ABC Accept Reject
sample3=MCMC(y,B,200)               #MCMC

#Posterior means, stack draws in a table and export draws to file arma.csv
output=np.concatenate((wmean(sample1),np.mean(sample2.draws,axis=0),np.mean(sample3.batch,axis=0)),axis=0)

out0=pandas.DataFrame({'Likelihood':sample3.batch[:,0],'RS':resample(sample1,0),'ABC':sample2.draws[:,0]})
m0=pandas.melt(out0)
m0.columns=['Method','alpha']

#print np.mean(out0)
out1=pandas.DataFrame({'Likelihood':sample3.batch[:,1],'RS':resample(sample1,1),'ABC':sample2.draws[:,1]})
m1=pandas.melt(out1)
m1.columns=['Method','theta']
#print np.mean(out1)
out2=pandas.DataFrame({'Likelihood':sample3.batch[:,2],'RS':resample(sample1,2),'ABC':sample2.draws[:,2]})
m2=pandas.melt(out2)
#print np.mean(out2)
m2.columns=['Method','sigma']

m=copy(m0)
m['theta']=m1['theta']
m['sigma']=m2['sigma']
m.to_csv('arma.csv')
