#!/bin/bash
for i in `seq 1 50`;
do
	echo $i
	qsub runMLE.sh -v seed=$i
done
