library(xtable)
rhos2=c()
betas2=c()
LR2e=c()
LR2v=c()
s2s=c()
jj=1
load(paste("~/yeti/ABC/Panel/New/Output/outputPanelLR",jj,".RData",sep=""))
quantilesb=array(NA,dim=c(50*B,19,3,3))
i=1
BB=0
for (jj in 1:50) {
  load(paste("~/yeti/ABC/Panel/New/Output/outputPanelLR",jj,".RData",sep=""))
  rhos2=rbind(rhos2,rhos)
  betas2=rbind(betas2,betas)
  s2s=rbind(s2s,output[,seq(3,3*9,3)])
  LR2e=rbind(LR2e,LR_Effect)
  LR2v=rbind(LR2v,LR_Variance)
  quantilesb[i:(i+B-1),,,]=quantiles
  i=i+B
  BB=BB+B
}

rhos=rhos2
betas=betas2
LR_Effect=LR2e
colnames(rhos)=c('MLE','GMM','LTE','SLTE','SMD','ABC','Rev Re-W.','Rev','Boot')
colnames(betas)=c('MLE','GMM','LTE','SLTE','SMD','ABC','Rev Re-W.','Rev','Boot')
colnames(LR_Effect)=c('MLE','GMM','LTE','SLTE','SMD','ABC','Rev Re-W.','Rev','Boot')
colnames(LR_Variance)=c('MLE','GMM','LTE','SLTE','SMD','ABC','Rev Re-W.','Rev','Boot')
colnames(LR_Effect)=colnames(rhos)
colnames(s2s)=colnames(rhos)
library(ggplot2)
library(reshape)

m=melt(rhos);target=rho
colnames(m)=c('Estimator','Estimates')
ggplot(m,aes(x=Estimates,colour=Estimator)) +
  geom_density(size=1) + 
  geom_vline(xintercept=target) +
  theme(text = element_text(size=16),legend.position="bottom",
        axis.text.x = element_text(face='bold', size=14),
        axis.text.y = element_text(face='bold', size=14),
        strip.text.x = element_text(face="bold",size = 16),
        strip.text.y = element_text(face="bold",size = 16))

f <- function(x,target) {
  return(c(mean(x),sd(x),mean(x)-target))
}

library(xtable)
table=apply(rhos,2,f,target=rho)
table=as.data.frame(table)
rownames(table)=c('Mean','Std','Bias')
xtable(table[,c(1:7,9)],digits=4)

table=apply(betas,2,f,target=beta)
table=as.data.frame(table)
rownames(table)=c('Mean','Std','Bias')
xtable(table[,c(1:7,9)],digits=4)

table=apply(s2s,2,f,target=s2)
table=as.data.frame(table)
rownames(table)=c('Mean','Std','Bias')
xtable(table[,c(1:7,9)],digits=4)

table=apply(LR_Effect,2,f,target=beta/(1-rho))
table=as.data.frame(table)
rownames(table)=c('Mean','Std','Bias')
xtable(table[,c(1:7,9)],digits=4)


table=apply(LR_Variance,2,f,target=(beta^2+s2)/(1-rho^2))
table=as.data.frame(table)
rownames(table)=c('Mean','Std','Bias')
xtable(table[,c(1:7,9)],digits=4)


quantiles=quantilesb
k=2
m=quantiles[,,1,k]-quantiles[,,2,k]
V=var(m)/BB
sV=sqrtm(cor(m))
zz=rep(0,1e5)
for (b in 1:1e5) {zz[b]=max((sV%*%rnorm(dim(quantiles)[2])))}
q=quantile(zz,0.975)
mo=apply(m,2,mean)
qq=apply(quantiles[,,1,k],2,mean)
# q=-qnorm((1-exp(log(0.95)/19))/2)
matplot(qq,cbind(qq+mo,qq+sqrt(diag(V))*q,qq-sqrt(diag(V))*q),type='l')
lines(seq(-10,10,1),seq(-10,10,1))
dat=as.data.frame(cbind(qq,qq+mo,qq+mo-sqrt(diag(V))*q,qq+mo+sqrt(diag(V))*q))
colnames(dat)=c('ABC','Reversed','Low','Up')
ggplot(dat,aes(x=ABC,y=Reversed))+geom_line(size=1)+
  geom_line(aes(x=ABC,y=ABC),size=0.5,linetype='dashed')+
  geom_ribbon(aes(x=ABC,ymin=Low,ymax=Up),alpha=0.1,fill='blue')+
  theme(text = element_text(size=16),legend.position="bottom",
        axis.text.x = element_text(face='bold', size=14),
        axis.text.y = element_text(face='bold', size=14),
        strip.text.x = element_text(face="bold",size = 16),
        strip.text.y = element_text(face="bold",size = 16))+
  ylab('Reversed Sampler')+xlab('ABC')
print(t(mo)%*%solve(V,mo))