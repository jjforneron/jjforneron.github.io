.libPaths("/vega/sscc/work/users/jmf2209/rpackages")

args=(commandArgs(TRUE))

##args is now a list of character vectors
## First check to see if arguments are passed.
## Then cycle through each element of the list and evaluate the expressions.
if(length(args)==0){
  print("No arguments supplied.")
  ##supply default values
  seed = 123
}else{
  seed=eval(parse(text=args[[1]]))
}
print(seed)
set.seed(seed)

library(Rcpp)
library(inline)
library(RcppArmadillo)
library(mcmc)
library(Matrix)
library(numDeriv)
library(Hmisc)

N=100
T=5

rho =0.6
beta=1
s2  =2
s2_x=1

lT=rep(1,T)
AT=diag(T)-(lT)%*%t(lT)/(T)
A=as.matrix(kronecker(Matrix(diag(N),sparse=TRUE),AT))
y=matrix(NA,T+1,N)
D=diff(diag(T))
H=D%*%t(D)

rcpp_inc <- '
using namespace Rcpp;
using namespace arma;
# include <iostream>
#include <math.h>
'

simpan <- '
vec param = as<vec>(paramin);
mat shocks = as<mat>(shocksin);
mat x = as<mat>(xin);
int N = shocks.n_cols;
int T = shocks.n_rows-1;
mat y = mat(T+1,N, fill::zeros);
int transform = as<int>(transin); 
double rho;
double beta;
double s;
if (transform == 0) {
rho  = param(0);
beta = param(1);
s    = sqrt(param(2));
} 
else {
rho  = tanh(param(0));
beta = param(1);
s    = sqrt(exp(param(2)));
}

y.row(0) = s*shocks.row(0)/(1-rho) + beta*x.row(0);
for (int t =1;t<T+1;t++) {
y.row(t) = rho*y.row(t-1) + s*shocks.row(t) + beta*x.row(t);
}
return(wrap(y));
'

simupanel <- cxxfunction(signature(paramin="numeric", shocksin="numeric",xin="numeric",transin="numeric"), 
                         simpan, plugin='RcppArmadillo', rcpp_inc)


abcsample <- '
int S        = as<int>(Sin);
vec mom      = as<vec>(momin);
vec rho_hat  = vec(2);
rho_hat(0)=mom(0);
rho_hat(1)=mom(1);
double  s    = mom(2);
mat x        = as<mat>(xin);
mat W        = as<mat>(Win);
vec low      = as<vec>(lowin);
vec dif      = as<vec>(difin);
int N        = x.n_cols;
int T        = x.n_rows-1;
mat y        = mat(T+1,N, fill::zeros);
vec y0       = vec(T*N, fill::zeros);
vec y1       = vec(T*N, fill::zeros);
vec x0       = vectorise(x.rows(1,T));
mat X        = mat(T*N,2,fill::zeros);
mat m        = mat(T*N,3, fill::zeros);
mat mm = mat();
mat moment   = mat(S,3);
//mat AT       = speye(T,T)-ones(T)*ones(1,T)/T;
//mat A        = kron(eye(N,N),AT);
mat A = as<mat>(Ain);
X.col(1)=x0;
mat shocks   = mat(T+1,N, fill::zeros);
mat sample   = mat(S,3, fill::zeros);
vec dist     = vec(S, fill::zeros);
double rho;
double beta;
double s2;

for (int i=1; i<S+1;i++) {
rho =dif(0)*as_scalar(randu(1))+low(0);
beta=dif(1)*as_scalar(randu(1))+low(1);
s2  =dif(2)*as_scalar(randu(1))+low(2);
shocks.randn();
y.row(0) = sqrt(s2)*shocks.row(0)/(1-rho) + beta*x.row(0);
for (int t =1;t<T+1;t++) {
y.row(t) = rho*y.row(t-1) + sqrt(s2)*shocks.row(t) + beta*x.row(t);
}
y0=vectorise(y.rows(0,T-1));
y1=vectorise(y.rows(1,T));
X.col(0)=y0;
m.col(0) = A*(y1-X*rho_hat);
m.col(1) = m.col(0);
m.col(2) = (A*(y1-X*rho_hat))%(A*(y1-X*rho_hat))-(1-1/N)*s;
m.cols(0,1) = (A*X)%m.cols(0,1);
mm = mean(m,0);
moment.row(i-1)=mm;
dist(i-1)=as_scalar(mm*solve(W,mm.t()));
sample(i-1,0)=rho;
sample(i-1,1)=beta;
sample(i-1,2)=s2;
}

return Rcpp::List::create(Named("sample") = wrap(sample),
Named("dists") = wrap(dist)  ,
Named("x_")=x0,Named("moms")=moment,
Named("rho_hat")=rho_hat,
Named("s")=s);
'

sample <- cxxfunction(signature(momin="numeric", 
                                xin="numeric",
                                Win="numeric",
                                Sin="numeric",
                                Ain="numeric",
                                lowin="numeric",
                                difin="numeric"), 
                      abcsample, plugin='RcppArmadillo', rcpp_inc)



object <- '
vec param    = as<vec>(paramin);
mat shocks   = as<mat>(shocksin);
vec mom      = as<vec>(momin);
vec rho_hat  = vec(2);
rho_hat(0)=mom(0);
rho_hat(1)=mom(1);
double  s    = mom(2);
mat x        = as<mat>(xin);
mat W        = as<mat>(Win);
int N        = x.n_cols;
int T        = x.n_rows-1;
mat y        = mat(T+1,N, fill::zeros);
vec y0       = vec(T*N, fill::zeros);
vec y1       = vec(T*N, fill::zeros);
vec x0       = as<vec>(x_in);
mat X        = mat(T*N,2,fill::zeros);
mat m        = mat(T*N,3, fill::zeros);
mat mm = mat();
//mat AT       = speye(T,T)-ones(T)*ones(1,T)/T;
//mat A        = kron(eye(N,N),AT);
mat A = as<mat>(Ain);
X.col(1)=x0;
double rho = tanh(param(0));
double beta= param(1);
double s2  = exp(param(2));

y.row(0) = sqrt(s2)*shocks.row(0)/(1-rho) + beta*x.row(0);
for (int t =1;t<T+1;t++) {
y.row(t) = rho*y.row(t-1) + sqrt(s2)*shocks.row(t) + beta*x.row(t);
}
y0=vectorise(y.rows(0,T-1));
y1=vectorise(y.rows(1,T));
X.col(0)=y0;
m.col(0) = A*(y1-X*rho_hat);
m.col(1) = m.col(0);
m.col(2) = (A*(y1-X*rho_hat))%(A*(y1-X*rho_hat))-(1-1/N)*s;
m.cols(0,1) = (A*X)%m.cols(0,1);
mm = mean(m,0);
double dist=as_scalar(mm*solve(W,mm.t()));
return wrap(dist);
'
ObjRev <- cxxfunction(signature(paramin="numeric",
                                shocksin="numeric",
                                momin="numeric", 
                                xin="numeric",
                                x_in="numeric",
                                Win="numeric",
                                Ain="numeric"), 
                      object, plugin='RcppArmadillo', rcpp_inc)


S_logpost <- '
vec param    = as<vec>(paramin);
NumericVector vecArray(shocksin);
IntegerVector arrayDims = vecArray.attr("dim");
cube shocks(vecArray.begin(), arrayDims[0], arrayDims[1], arrayDims[2], false);
//mat shocks   = as<mat>(shocksin);
vec mom      = as<vec>(momin);
vec rho_hat  = vec(2);
rho_hat(0)=mom(0);
rho_hat(1)=mom(1);
double  S    = as<double>(Sin);
double  s    = mom(2);
mat x        = as<mat>(xin);
mat W        = as<mat>(Win);
int N        = x.n_cols;
int T        = x.n_rows-1;
mat y        = mat(T+1,N, fill::zeros);
vec y0       = vec(T*N, fill::zeros);
vec y1       = vec(T*N, fill::zeros);
vec x0       = as<vec>(x_in);
mat X        = mat(T*N,2,fill::zeros);
mat m        = mat(T*N,3, fill::zeros);
mat mm = mat();
//mat AT       = speye(T,T)-ones(T)*ones(1,T)/T;
//mat A        = kron(eye(N,N),AT);
mat A = as<mat>(Ain);
X.col(1)=x0;
double rho = param(0);
double beta= param(1);
double s2  = param(2);
double dist=0;
mat sho;
for (int i=0;i<S;i++) {
sho=shocks.slice(i);
y.row(0) = sqrt(s2)*sho.row(0)/(1-rho) + beta*x.row(0);
for (int t =1;t<T+1;t++) {
y.row(t) = rho*y.row(t-1) + sqrt(s2)*sho.row(t) + beta*x.row(t);
}
y0=vectorise(y.rows(0,T-1));
y1=vectorise(y.rows(1,T));
X.col(0)=y0;
m.col(0) = A*(y1-X*rho_hat);
m.col(1) = m.col(0);
m.col(2) = (A*(y1-X*rho_hat))%(A*(y1-X*rho_hat))-(1-1/N)*s;
m.cols(0,1) = (A*X)%m.cols(0,1);
mm = mean(m,0);
dist=dist+as_scalar(mm*solve(W,mm.t()));
}

return wrap(-N*T/2*dist/S);
'
slogpost <- cxxfunction(signature(paramin="numeric",
                                shocksin="numeric",
                                momin="numeric", 
                                xin="numeric",
                                x_in="numeric",
                                Win="numeric",
                                Ain="numeric",
                                Sin="numeric"), 
                      S_logpost, plugin='RcppArmadillo', rcpp_inc)

ABC_MCMC <- '
vec mom      = as<vec>(momin);
vec rho_hat  = vec(2);
rho_hat(0)   = mom(0);
rho_hat(1)   = mom(1);
double  s    = mom(2);
double  S    = as<double>(Sin);
double  eps  = as<double>(epsin);
int slice    = as<int>(slicein);
mat x        = as<mat>(xin);
mat W        = as<mat>(Win);
int N        = x.n_cols;
int T        = x.n_rows-1;
mat y        = mat(T+1,N, fill::zeros);
vec y0       = vec(T*N, fill::zeros);
vec y1       = vec(T*N, fill::zeros);
vec x0       = as<vec>(x_in);
mat X        = mat(T*N,2,fill::zeros);
mat m        = mat(T*N,3, fill::zeros);
mat shocks   = mat(T+1,N);
mat mm = mat();
mat scale    = as<mat>(scalein);
vec init     = as<vec>(initin);
mat draws    = mat(S,3);
draws.row(0) = init.t();
mat A = as<mat>(Ain);
rowvec innov = rowvec(3);
X.col(1)=x0;
double rho;
double beta;
double s2;
double dist;
double accept=0;
rowvec temp  = rowvec(3);
rowvec temp2 = rowvec(3);
int k=1;
int i=1;
temp =draws.row(0);
temp2=draws.row(0);
while (i<S) {
if (k==slice) {
k=1;
i=i+1;
draws.row(i-1)=temp2;
temp=init.t();
}
k=k+1;
innov.randn();
temp2=temp+innov*scale;
if (abs(temp2(0))>1 || temp2(2)<0) {
temp2=temp;
}
else {
rho =temp2(0);
beta=temp2(1);
s2  =temp2(2);
shocks.randn();
y.row(0) = sqrt(s2)*shocks.row(0)/(1-rho) + beta*x.row(0);
for (int t =1;t<T+1;t++) {
y.row(t) = rho*y.row(t-1) + sqrt(s2)*shocks(t) + beta*x.row(t);
}
y0=vectorise(y.rows(0,T-1));
y1=vectorise(y.rows(1,T));
X.col(0)=y0;
m.fill(0);
m.col(0) = A*(y1-X*rho_hat);
m.col(1) = m.col(0);
m.col(2) = (A*(y1-X*rho_hat))%(A*(y1-X*rho_hat))-(1-1/N)*s;
m.cols(0,1) = (A*X)%m.cols(0,1);
mm = mean(m,0);
dist=as_scalar(mm*solve(W,mm.t()));
if (dist <= eps) {
accept=accept+1;
temp=temp2;
} 
else {
temp2=temp;
}
}
}

return Rcpp::List::create(Named("draws") = wrap(draws),
Named("accept") = wrap(accept/S/slice));
'
abcmcmc <- cxxfunction(signature(initin="numeric",
                                 momin="numeric", 
                                 xin="numeric",
                                 x_in="numeric",
                                 Sin="numeric",
                                 epsin="numeric",
                                 Win="numeric",
                                 Ain="numeric",
                                 scalein="numeric",
                                 slicein="numeric"), 
                       ABC_MCMC, plugin='RcppArmadillo', rcpp_inc)


sqrtm <- function(A) {
  A=eigen(A)
  return(A$vector%*%diag(sqrt(A$values))%*%t(A$vector))
}

Simu_Panel <- function(param,shocks,x,transform=FALSE) {
  if (transform==FALSE) {
    rho =param[1]
    beta=param[2]
    s2  =param[3]
  } else {
    rho =tanh(param[1])
    beta=param[2]
    s2  =exp(param[3])
  }
  y=matrix(NA,dim(shocks)[1],N)
  y[1,]=shocks[1,]/(1-rho)*sqrt(s2) + beta*x[1,]
  for (t in 2:dim(shocks)[1]) {
    y[t,]=rho*y[t-1,] + beta*x[t,] + sqrt(s2)*shocks[t,]
  }
  return(y)
}

estim_MLE <- function(y,x) {
  y_1 = c(y[1:T,])
  x_  = c(x[2:(T+1),])
  X=cbind(y_1,x_)
  y_  = c(y[2:(T+1),])
  rho_hat = as.vector(solve(t(X)%*%A%*%X,t(X)%*%A%*%y_))
  m1=t(A%*%X)%*%(A%*%y_)/N
  m2=t(A%*%X)%*%(A%*%X)/N
  m=as.matrix((A%*%X)*matrix(rep(as.vector(A%*%y_-A%*%X%*%rho_hat),2),N*T,2))
  m=cbind(m,as.vector(A%*%y_-A%*%X%*%rho_hat)^2)
  W=var(m)
  return(list(coef=rho_hat,W=W,s=mean(as.vector(A%*%y_-A%*%X%*%rho_hat)^2)/(1-1/N)))
}

ABC_Sample <- function(mom,x,q,S,W,low,dif) {
  B=ceiling(S/q)
  z=sample(mom,x,W,B,A,low,dif)
  qs=quantile(z$dists,q)
  w=which(z$dists<=qs)
  return(list(sample=z$sample[w,],dists=z$dists[w,],moments=z$moms[w,]))
}

Rev_Sample <- function(mom,x,S,W,init) {
  shocks=array(rnorm(N*(T+1)*S),c(T+1,N,S))
  x_  = c(x[2:(T+1),])
  objective <- function(param,passe) {
    b=passe$b
    mom=passe$mom
    rho_hat=mom[1:2]
    s2hat  =mom[3]
    dist=ObjRev(param,shocks[,,b],mom,x,x_,W,A)
    return(dist)
  }
  init[1]=atanh(mom[1])
  init[3]=log(mom[3])
  one_draw <- function(b,mom,init) {
    passe=list(b=b,mom=mom)
    z=optim(init,objective,gr=NULL,passe=passe,method="BFGS")
    out=z$par
    out[1]=tanh(out[1]);out[3]=exp(out[3])
    return(out)
  }
  draws = sapply(1:S,one_draw,mom=mom,init=init)
  weights=matrix(NA,S)
  for (s in 1:S) {
    zi=draws[,s];zi[1]=atanh(zi[1]);zi[3]=log(zi[3])
    weights[s]=abs(det(jacobian(one_draw,mom,method="simple",b=s,init=zi)))
  }
  return(list(draws=draws,weights=weights))
}

estim_SMD <- function(mom,x,S,W) {
  shocks=array(rnorm(N*(T+1)*S),c(T+1,N,S))
  x_  = c(x[2:(T+1),])
  objective <- function(param,mom) {
    rho_hat=mom[1:2]
    s2hat  =mom[3]
    moms=mom*0    
    for (s in 1:S) {
      ys   =simupanel(param,shocks[,,s],x,1)
      y_1 = c(ys[1:T,])
      X=cbind(y_1,x_)
      y_  = c(ys[2:(T+1),])
      m=as.matrix((A%*%X)*matrix(rep(as.vector(A%*%y_-A%*%X%*%rho_hat),2),N*T,2))
      m=cbind(m,as.vector(A%*%y_-A%*%X%*%rho_hat)^2-s2hat*(1-1/N))
      moms=moms+apply(m,2,mean)/S
    }
    dists=t(moms)%*%solve(W,moms)
    return(dists)
  }
  init=mom;init[1]=atanh(mom[1])
  init[3]=log(mom[3])
  estim <- function(init) {
    z=optim(init,objective,gr=NULL,mom=mom,method="BFGS")
    out=z$par
    out[1]=tanh(out[1]);out[3]=exp(out[3])
    return(out)
  }
  return(estim(init))
}

estim_LTE <- function(y,x,W) {
  y_1 = c(y[1:T,])
  x_  = c(x[2:(T+1),])
  X=cbind(y_1,x_)
  y_  = c(y[2:(T+1),])
  AX=as.matrix(A%*%X)
  Ay=as.vector(A%*%y_)
  logpost <- function(param) {
    if (abs(param[1])>1 || param[3]==0) {
      return(-Inf)
    } else {
      m=AX*matrix(rep(Ay-AX%*%param[1:2],2),N*T,2)
      m=cbind(m,(Ay-AX%*%param[1:2])^2-param[3]*(1-1/N))
      m=apply(m,2,mean)
      return(-(N*T)/2*t(m)%*%solve(W,m))
    }
  }
  scale=sqrtm(2*solve(W)/(N*T))
  z=metrop(logpost,mom,200+2e3,scale=scale)
  return(z$batch[200:(200+2e3),])
}

estim_SLTE <- function(mom,x,S,W,init) {
  x_=c(x[2:(T+1),])
  shocks=array(rnorm(N*S*(T+1)),dim=c(T+1,N,S))
  logpost <- function(param) {
    if (abs(param[1])>1 || param[3]<0) {
      return(-Inf)
    } else {
      return(slogpost(param,shocks,mom,x,x_,W,A,S))
    }
  }
  s=mom[3]
  X=A%*%cbind(c(y[1:T,]),x_)
  scale=diag(sqrt(c(diag(s*solve(t(X)%*%X)),2*s^2/(N*T))))
  z=metrop(logpost,init,1e3+2e2,scale=scale)
  return(z$batch[2e2:(1e3+2e2),])
}
B=20
output     =matrix(NA,B,3*8)
LR_Effect  =matrix(NA,B,1*8)
LR_Variance=matrix(NA,B,1*8)
quants     =seq(0.05,0.95,0.05);l=length(quants)
quantiles =array(NA,dim=c(B,l,3,3))

scale=diag(c(0.03,0.07,0.1))
slice=1e5

q=1/400
S1=20
S2=2e2

t1=Sys.time()
print(t1)
for (b in 1:B) {
  x=matrix(rnorm(N*(T+1)),T+1,N)
  shocks=matrix(rnorm(N*(T+1)),T+1,N)
  y=Simu_Panel(c(rho,beta,s2),shocks,x)
  MLE=estim_MLE(y,x)
  mom=c(MLE$coef,MLE$s)
  W=MLE$W
  x_=c(x[2:(T+1),])
  SMD= estim_SMD(mom,x,S1,W)
  init=SMD
  
  Rev=Rev_Sample(mom,x,S2,W,init)
  

  z=abcmcmc(init,mom,x,x_,S2,0.001,W,A,scale,slice);plot.ts(z$draws);z$accept
  ABC=z$draws
#   ABC=ABC_Sample(mom,x,q,S2,W,low,dif)
  LTE = estim_LTE(y,x,W)
  SLTE= estim_SLTE(mom,x,S1,W,init)
  output[b,]=c(mom,mom,apply(LTE,2,mean),apply(SLTE,2,mean),SMD,apply(ABC,2,mean),
               apply(t(Rev$draw),2,wtd.mean,weights=Rev$weights),
               apply(t(Rev$draw),2,mean))
  quantiles[b,,1,]=apply(ABC,2,quantile,probs=quants)
  quantiles[b,,2,]=apply(t(Rev$draw),2,wtd.quantile,probs=quants,weights=Rev$weights)
  quantiles[b,,3,]=apply(t(Rev$draw),2,quantile,probs=quants)
  LR_Effect[b,]=c(mom[2]/(1-mom[1]),mom[2]/(1-mom[1]),mean(LTE[,2]/(1-LTE[,1])),
                  mean(SLTE[,2]/(1-SLTE[,1])),
                  SMD[2]/(1-SMD[1]),
                  mean(ABC[,2]/(1-ABC[,1])),
                  wtd.mean(Rev$draw[2,]/(1-Rev$draw[1,]),weights=Rev$weights),
                  mean(Rev$draw[2,]/(1-Rev$draw[1,])))
  LR_Variance[b,]=c((mom[2]^2+mom[3])/(1-mom[1]^2),(mom[2]^2+mom[3])/(1-mom[1]^2),
                    mean((LTE[,2]^2+LTE[,3])/(1-LTE[,1]^2)),
                    mean((SLTE[,2]^2+SLTE[,3])/(1-SLTE[,1]^2)),
                    (SMD[2]^2+SMD[3])/(1-SMD[1]^2),
                    mean((ABC[,2]^2+ABC[,3])/(1-ABC[,1]^2)),
                    wtd.mean((Rev$draw[2,]^2+Rev$draw[3,])/(1-Rev$draw[1,]^2),weights=Rev$weights),
                    mean((Rev$draw[2,]^2+Rev$draw[3,])/(1-Rev$draw[1,]^2)))
  print(output[b,])
  print(b/B*100)
}

t2=Sys.time()
print(t2-t1)

output=as.data.frame(output)
rhos  =output[,seq(1,3*8,3)]
betas =output[,seq(2,3*8,3)]
sigmas=output[,seq(3,3*8,3)]
colnames(rhos)=c('MLE','GMM','LTE','SLTE','SMD','ABC','Rev Re-W.','Rev')
colnames(betas)=c('MLE','GMM','LTE','SLTE','SMD','ABC','Rev Re-W.','Rev')
LR_Effect=as.data.frame(LR_Effect)
LR_Variance=as.data.frame(LR_Variance)
colnames(LR_Effect)=c('MLE','GMM','LTE','SLTE','SMD','ABC','Rev Re-W.','Rev')
colnames(LR_Variance)=c('MLE','GMM','LTE','SLTE','SMD','ABC','Rev Re-W.','Rev')

save(list = ls(all = TRUE),file=paste('/vega/sscc/work/users/jmf2209/ABC/Panel/New/Output/outputPanelLR',seed,'.RData',sep=""))

# 
# k=1;
# limx=c(min(quantile(ABC$sample[,k],quants[1]),wtd.quantile(Rev$draw[k,],Rev$weights,quants[1])))
# limy=c(max(quantile(ABC$sample[,k],quants[l]),wtd.quantile(Rev$draw[k,],Rev$weights,quants[l])))
# plot(quantile(ABC$sample[,k],quants),wtd.quantile(Rev$draw[k,],Rev$weights,quants),
#      xlim=c(limx,limy),ylim=c(limx,limy))
# lines(seq(-10,10,1),seq(-10,10,1))
# rbind(quantile(ABC$sample[,k],quants),
#       wtd.quantile(Rev$draw[k,],Rev$weights,quants),
#       quantile(Rev$draw[k,],quants))
# t2-t1