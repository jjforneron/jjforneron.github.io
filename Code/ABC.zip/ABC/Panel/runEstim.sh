#!/bin/sh
#hedge.sh
#Torque script to run R program

#Torque directives
#PBS -N JJ
#PBS -W group_list=yetisscc
#PBS -l nodes=1,walltime=99:55:00,mem=1500mb
#PBS -M jmf2209@columbia.edu
#PBS -m abe
#PBS -V

#set output and error directories
#PBS -o localhost:/udirs/sscc/jmf2209/work/NearExo/
#PBS -e localhost:/udirs/sscc/jmf2209/work/NearExo/

#Command to execute R code
R CMD BATCH --no-save  '--args seed='$seed /vega/sscc/work/users/jmf2209/ABC/Panel/New/DynamicPanel_Table3.R /vega/sscc/work/users/jmf2209/ABC/Panel/New/Output/JJ$seed.routput
