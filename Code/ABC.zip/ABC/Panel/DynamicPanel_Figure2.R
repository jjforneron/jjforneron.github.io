set.seed(123)

library(Rcpp)
library(inline)
library(RcppArmadillo)
library(mcmc)
library(Matrix)
library(numDeriv)
library(Hmisc)

N=100
T=5

rho =0.6
beta=1
s2  =2
s2_x=1

lT=rep(1,T)
AT=diag(T)-(lT)%*%t(lT)/(T)
A=as.matrix(kronecker(Matrix(diag(N),sparse=TRUE),AT))
y=matrix(NA,T+1,N)
D=diff(diag(T))
H=D%*%t(D)

rcpp_inc <- '
using namespace Rcpp;
using namespace arma;
# include <iostream>
#include <math.h>
'

simpan <- '
vec param = as<vec>(paramin);
mat shocks = as<mat>(shocksin);
mat x = as<mat>(xin);
int N = shocks.n_cols;
int T = shocks.n_rows-1;
mat y = mat(T+1,N, fill::zeros);
int transform = as<int>(transin);
double rho;
double beta;
double s;
if (transform == 0) {
rho  = param(0);
beta = param(1);
s    = sqrt(param(2));
}
else {
rho  = tanh(param(0));
beta = param(1);
s    = sqrt(exp(param(2)));
}

y.row(0) = s*shocks.row(0)/(1-rho) + beta*x.row(0);
for (int t =1;t<T+1;t++) {
y.row(t) = rho*y.row(t-1) + s*shocks.row(t) + beta*x.row(t);
}
return(wrap(y));
'

simupanel <- cxxfunction(signature(paramin="numeric", shocksin="numeric",xin="numeric",transin="numeric"),
                         simpan, plugin='RcppArmadillo', rcpp_inc)


sqrtm <- function(A) {
  A=eigen(A)
  return(A$vector%*%diag(sqrt(A$values))%*%t(A$vector))
}

Simu_Panel <- function(param,shocks,x,transform=FALSE) {
  if (transform==FALSE) {
    rho =param[1]
    beta=param[2]
    s2  =param[3]
  } else {
    rho =tanh(param[1])
    beta=param[2]
    s2  =exp(param[3])
  }
  y=matrix(NA,dim(shocks)[1],N)
  y[1,]=shocks[1,]/(1-rho)*sqrt(s2) + beta*x[1,]
  for (t in 2:dim(shocks)[1]) {
    y[t,]=rho*y[t-1,] + beta*x[t,] + sqrt(s2)*shocks[t,]
  }
  return(y)
}

estim_MLE <- function(y,x) {
  y_1 = c(y[1:T,])
  x_  = c(x[2:(T+1),])
  X=cbind(y_1,x_)
  y_  = c(y[2:(T+1),])
  rho_hat = as.vector(solve(t(X)%*%A%*%X,t(X)%*%A%*%y_))
  m1=t(A%*%X)%*%(A%*%y_)/N
  m2=t(A%*%X)%*%(A%*%X)/N
  m=as.matrix((A%*%X)*matrix(rep(as.vector(A%*%y_-A%*%X%*%rho_hat),2),N*T,2))
  m=cbind(m,as.vector(A%*%y_-A%*%X%*%rho_hat)^2)
  W=var(m)
  return(list(coef=rho_hat,W=W,s=mean(as.vector(A%*%y_-A%*%X%*%rho_hat)^2)/(1-1/T)))
}


Rev_Sample <- function(mom,x,S,W,initi) {
  shocks=array(rnorm(N*(T+1)*S),c(T+1,N,S))
  x_  = c(x[2:(T+1),])
  objective <- function(param,passe) {
    b=passe$b
    mom=passe$mom
    rho_hat=mom[1:2]
    s2hat  =mom[3]
    ys   =simupanel(param,shocks[,,b],x,1)
    y_1 = c(ys[1:T,])
    X=cbind(y_1,x_)
    y_  = c(ys[2:(T+1),])
    m=as.matrix((A%*%X)*matrix(rep(as.vector(A%*%y_-A%*%X%*%rho_hat),2),N*T,2))
    m=cbind(m,as.vector(A%*%y_-A%*%X%*%rho_hat)^2-s2hat*(1-1/(T+1)))
    moms=apply(m,2,mean)
    dists=t(moms)%*%solve(W,moms)
    return(dists)
  }
  moment <- function(param,passe) {
    b=passe$b
    mom=passe$mom
    rho_hat=mom[1:2]
    s2hat  =mom[3]
    ys   =simupanel(param,shocks[,,b],x,0)
    y_1 = c(ys[1:T,])
    X=cbind(y_1,x_)
    y_  = c(ys[2:(T+1),])
    m=as.matrix((A%*%X)*matrix(rep(as.vector(A%*%y_-A%*%X%*%rho_hat),2),N*T,2))
    m=cbind(m,as.vector(A%*%y_-A%*%X%*%rho_hat)^2-s2hat*(1-1/(T+1)))
    moms=apply(m,2,mean)
    return(moms)
  }
  init[1]=atanh(mom[1])
  init[3]=log(mom[3])
pb <- txtProgressBar(style=3)
  one_draw <- function(b,mom,init) {
    passe=list(b=b,mom=mom)
    z=optim(init,objective,gr=NULL,passe=passe,method="BFGS",control=c(maxit=1e4))
    out=z$par
    out[1]=tanh(out[1]);out[3]=exp(out[3]);setTxtProgressBar(pb, b/S)
    return(out)
  }
  draws = sapply(1:S,one_draw,mom=mom,init=init)
  weights=matrix(NA,S)

  for (s in 1:S) {
    zi=draws[,s];#zi[1]=atanh(zi[1]);zi[3]=log(zi[3])
    passe=list(b=s,mom=mom,init=zi)
    weights[s]=1/abs(det(jacobian(moment,zi,method="simple",passe=passe)))
  }
  return(list(draws=t(draws),weights=weights))
}

estim_SMD <- function(mom,x,S,W) {
  shocks=array(rnorm(N*(T+1)*S),c(T+1,N,S))
  x_  = c(x[2:(T+1),])
  objective <- function(param,mom) {
    rho_hat=mom[1:2]
    s2hat  =mom[3]
    moms=mom*0
    for (s in 1:S) {
      ys   =simupanel(param,shocks[,,s],x,1)
      y_1 = c(ys[1:T,])
      X=cbind(y_1,x_)
      y_  = c(ys[2:(T+1),])
      m=as.matrix((A%*%X)*matrix(rep(as.vector(A%*%y_-A%*%X%*%rho_hat),2),N*T,2))
      m=cbind(m,as.vector(A%*%y_-A%*%X%*%rho_hat)^2-s2hat*(1-1/T))
      moms=moms+apply(m,2,mean)/S
    }
    dists=t(moms)%*%solve(W,moms)
    return(dists)
  }
  init=mom;init[1]=atanh(mom[1])
  init[3]=log(mom[3])
  estim <- function(init) {
    z=optim(init,objective,gr=NULL,mom=mom,method="BFGS")
    out=z$par
    out[1]=tanh(out[1]);out[3]=exp(out[3])
    return(out)
  }
  par=estim(init)
  simu_estim <- function(s,param) {
    ys   =simupanel(param,shocks[,,s],x,0)
    m=estim_MLE(ys,x)
    return(c(m$coef,m$s))
  }
  average_simu <- function(param) {
    return(apply(sapply(seq(1,S,1),simu_estim,param=param),1,mean))
  }
  return(list(par=par,jac=jacobian(average_simu,par,method='simple')))
}

estim_Bootstrap <- function(mom,x,S) {
  shocks=array(rnorm(N*(T+1)*S),c(T+1,N,S))
  x_  = c(x[2:(T+1),])
  rho_hat=mom[1:2]
  s2hat  =mom[3]
  moms=mom*0
  for (s in 1:S) {
    ys   =y=Simu_Panel(c(rho,beta,s2),shocks[,,s],x)
    MLEs=estim_MLE(ys,x)
    moms=moms+c(MLEs$coef,MLEs$s)/S
  }
  return(2*mom-moms)
}

estim_LTE <- function(y,x,W) {
  y_1 = c(y[1:T,])
  x_  = c(x[2:(T+1),])
  X=cbind(y_1,x_)
  y_  = c(y[2:(T+1),])
  AX=as.matrix(A%*%X)
  Ay=as.vector(A%*%y_)
  logpost <- function(param) {
    if (abs(param[1])>1 || param[3]==0) {
      return(-Inf)
    } else {
      m=AX*matrix(rep(Ay-AX%*%param[1:2],2),N*T,2)
      m=cbind(m,(Ay-AX%*%param[1:2])^2-param[3]*(1-1/T))
      m=apply(m,2,mean)
      return(-(N*T)/2*t(m)%*%solve(W,m))
    }
  }
  scale=sqrtm(2*solve(W)/(N*T))
  z=metrop(logpost,mom,200+2e3,scale=scale)
  return(z$batch[200:(200+2e3),])
}

estim_SLTE <- function(mom,x,S,W,init) {
  rho_hat=mom[1:2]
  s2hat=mom[3]
  x_=c(x[2:(T+1),])
  shocks=array(rnorm(N*S*(T+1)),dim=c(T+1,N,S))
  logpost <- function(param) {
    if (abs(param[1])>1 || param[3]<0) {
      return(-Inf)
    } else {
      moms=mom*0
      for (s in 1:S) {
        ys   =simupanel(param,shocks[,,s],x,0)
        y_1 = c(ys[1:T,])
        X=cbind(y_1,x_)
        y_  = c(ys[2:(T+1),])
        m=as.matrix((A%*%X)*matrix(rep(as.vector(A%*%y_-A%*%X%*%rho_hat),2),N*T,2))
        m=cbind(m,as.vector(A%*%y_-A%*%X%*%rho_hat)^2-s2hat*(1-1/T))
        moms=moms+apply(m,2,mean)/S
      }
      dists=t(moms)%*%solve(W,moms)
      return(-N*T/2*dists)
    }
  }
  s=mom[3]
  X=A%*%cbind(c(y[1:T,]),x_)
  scale=diag(sqrt(c(diag(s*solve(t(X)%*%X)),2*s^2/(N*T))))
  z=metrop(logpost,init,2e3+2e2,scale=scale,nspac=50)
  return(z$batch[2e2:(2e3+2e2-1),])
}


ABC_MCMC <- function(init,mom,x,x_,B,delta,W,A,scale,slice) {
  rho_hat=mom[1:2]
  s2hat=mom[3]
  accept=0
  output=matrix(NA,S2,3)
  for (b in 1:B) {
    prev_draw=init;
    curr_draw=init;
    for (s in 1:slice) {
      curr_draw=prev_draw + scale%*%rnorm(3)
      if (abs(curr_draw[1])>1 || curr_draw[3]<0){
        curr_draw=prev_draw 
      } else {
        shocks=matrix(rnorm(N*(T+1)),T+1,N)
        ys   =simupanel(curr_draw,shocks,x,0)
        y_1 = c(ys[1:T,])
        X=cbind(y_1,x_)
        y_  = c(ys[2:(T+1),])
        m=as.matrix((A%*%X)*matrix(rep(as.vector(A%*%y_-A%*%X%*%rho_hat),2),N*T,2))
        m=cbind(m,as.vector(A%*%y_-A%*%X%*%rho_hat)^2-s2hat*(1-1/(T+1)))
        moms=apply(m,2,mean)
        dists=t(moms)%*%solve(W,moms)
        if (dists>delta) {
          curr_draw=prev_draw
        } else {
          accept=accept+1
          prev_draw=curr_draw
        }
      }
    }
    output[b,]=curr_draw
  }
  return(list(draws=output,accept=accept/(B*slice)))
}


S1=10
S2=1e5

Omega=matrix(-1/(T+1),T,T)
Omega=Omega+diag(T)
Om=solve(Omega)
O=Om
for (i in 2:N) {
  O=bdiag(O,Om)
}
estim_BC <- function(y,x,mom) {
  y_1 = c(y[1:T,])
  x_  = c(x[2:(T+1),])
  X=A%*%cbind(y_1,x_)
  y_  = A%*%c(y[2:(T+1),])
  logpost <- function(theta) {
    if (abs(theta[1])>1) {
      return(-Inf)
    } else {
      e=y_-X%*%theta[1:2]
      return(as.numeric(-N*T/2*log(theta[3])-0.5/theta[3]*t(e)%*%O%*%e))
    }
  }
  init=optim(mom,logpost,method="L-BFGS-B",
             lower=c(-1,-Inf,0),
             upper=c(1,Inf,Inf),
             control=list(fnscale=-1),
             hessian = TRUE)
  scale=sqrtm(-solve(init$hessian)/2)
  z=metrop(logpost,init$par,1e3+S2-1,scale=scale)
  return(z$batch[1e3:(1e3+S2-1),])
}

x=matrix(rnorm(N*(T+1)),T+1,N)
shocks=matrix(rnorm(N*(T+1)),T+1,N)
y=Simu_Panel(c(rho,beta,s2),shocks,x)
MLE=estim_MLE(y,x)
mom=c(MLE$coef,MLE$s)
W=MLE$W
x_=c(x[2:(T+1),])
SMD= estim_SMD(mom,x,S1,W)
init=SMD$par
moments <- function(par) {
  y_1 = c(y[1:T,])
  x_  = c(x[2:(T+1),])
  X=cbind(y_1,x_)
  y_  = c(y[2:(T+1),])
  m=as.matrix((A%*%X)*matrix(rep(as.vector(A%*%y_-A%*%X%*%par[1:2]),2),N*T,2))
  m=cbind(m,as.vector(A%*%y_-A%*%X%*%par[1:2])^2-par[3]/(1-1/T))
  mm=apply(m,2,mean)
  return(mm)
}

S=sqrtm(solve(jacobian(moments,mom),W)%*%solve(t(jacobian(moments,mom)))/(N*T))
S=solve(SMD$jac)%*%S

# Boot=estim_Bootstrap(mom,x,1e2)
Rev=Rev_Sample(mom,x,S2,W,init)
SLTE= estim_SLTE(mom,x,25,W,init)
BC=estim_BC(y,x,mom)
IE=t(init+S%*%matrix(rnorm(3*S2),3,S2))

library(ggplot2)
library(reshape)
param=c(rho,beta,s2)
# zz=1
# out=cbind(Rev$draws[,zz],BC[,zz],IE[,zz])
# out=as.data.frame(out);colnames(out)=c('RBC','BC','SMD')
# m=melt(out)
# m$weights=c(Rev$weights/sum(Rev$weights),rep(1/S2,2*S2))
# ggplot(m,aes(x=value,colour=variable,fill=variable,weight=weights))+geom_density(alpha=0.2)+
#   theme(text = element_text(size=16),legend.position="bottom",
#         axis.text.x = element_text(face='bold', size=14),
#         axis.text.y = element_text(face='bold', size=14),
#         strip.text.x = element_text(face="bold",size = 16),
#         strip.text.y = element_text(face="bold",size = 16))+xlab('Posterior for rho')+
#   geom_vline(xintercept=param[zz])
# 
# out=cbind(SLTE[,zz],BC[,zz])
# out=as.data.frame(out);colnames(out)=c('SLT','BC')
# m=melt(out)
# ggplot(m,aes(x=value,colour=variable,fill=variable))+geom_density(alpha=0.2)+
#   theme(text = element_text(size=16),legend.position="bottom",
#         axis.text.x = element_text(face='bold', size=14),
#         axis.text.y = element_text(face='bold', size=14),
#         strip.text.x = element_text(face="bold",size = 16),
#         strip.text.y = element_text(face="bold",size = 16))+xlab('Posterior for rho')+
#   geom_vline(xintercept=param[zz])

zz=1
out=cbind(Rev$draws[,zz],SLTE[,zz],BC[,zz],IE[,zz])
out=as.data.frame(out);colnames(out)=c('RS','SLT','BC','SMD')
m=melt(out)
m$weights=c(Rev$weights/sum(Rev$weights),rep(1/S2,3*S2))
p1 <- ggplot(m,aes(x=value))+
scale_fill_grey(start=0,end=.9)+
xlab(expression(rho))+
ylab('Posterior Density')+
geom_density(aes(fill=variable,linetype=variable),alpha=0.2,adjust=4)+
  theme(text = element_text(size=16),legend.position=c(0.9,0.9),
        legend.title=element_blank())+ #xlim(0,1)+#ylim(0,0.61)+
        scale_fill_grey(start = 0, end = .9)+
  geom_text(aes(label="Bayesian", x=0.33, y=7.7), size=4)+
  geom_segment(aes(x=0.33, xend=0.38, y=7.5, yend=7.5),arrow = arrow(length = unit(0.2, "cm")))+
  geom_text(aes(label="RS", x=0.5, y=10.2), size=4)+
  geom_segment(aes(x=0.5, xend=0.584, y=10, yend=10),arrow = arrow(length = unit(0.2, "cm")))+
  geom_vline(xintercept=param[zz])+
  geom_text(aes(label="SMD", x=0.5, y=8.95), size=4)+
  geom_segment(aes(x=0.5, xend=0.635, y=8.75, yend=8.75),arrow = arrow(length = unit(0.2, "cm")))+
  geom_vline(xintercept=param[zz])+
  geom_text(aes(label="SLT", x=0.5, y=7.7), size=4)+
  geom_segment(aes(x=0.5, xend=0.565, y=7.5, yend=7.5),arrow = arrow(length = unit(0.2, "cm")))+
  geom_vline(xintercept=param[zz],linetype="longdash")

ggsave('~/Dropbox/abc/jj/Fall 2014/Bayesian Likelihood Panel/Posterior_Rho.png',p1,height=7,width=10)
setwd("~/Dropbox/abc/jj/Fall 2014/Bayesian Likelihood Panel/")
save.image("draws.RData")

g=rep(0,3)
g[1]=init[2]/(1-init[1])^2
g[2]=1/(1-init[1])

sd_delta=sqrt((t(g)%*%S)%*%t(t(g)%*%S))
mu=init[2]/(1-init[1])

out=cbind(Rev$draws[,2]/(1-Rev$draws[,1]),SLTE[,2]/(1-SLTE[,1]),
          BC[,2]/(1-BC[,1]),mu+sd_delta*rnorm(S2))
out=as.data.frame(out);colnames(out)=c('RS','SLT','BC','SMD')
m=melt(out)
m$weights=c(Rev$weights/sum(Rev$weights),rep(1/S2,3*S2))
ggplot(m,aes(x=value,colour=variable,fill=variable))+geom_density(alpha=0.2)+
  theme(text = element_text(size=16),legend.position="bottom",
        axis.text.x = element_text(face='bold', size=14),
        axis.text.y = element_text(face='bold', size=14),
        strip.text.x = element_text(face="bold",size = 16),
        strip.text.y = element_text(face="bold",size = 16))+xlab('Posterior for the long-run multiplier')+
  geom_vline(xintercept=param[2]/(1-param[1]))
